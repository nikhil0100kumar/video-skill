#!/bin/sh
# Entregas a partir do master do OpenMotion: Reels (crf 18) e WhatsApp (< 10 MB, 720p, dois passes).
# Uso: encode-deliveries.sh <master.mp4> [alvo-whatsapp-em-MB]
set -eu
M=${1:?master}; ALVO=${2:-9.5}
B=${M%.mp4}
W=$(ffprobe -v error -select_streams v:0 -show_entries stream=width -of csv=p=0 "$M")
H=$(ffprobe -v error -select_streams v:0 -show_entries stream=height -of csv=p=0 "$M")
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$M")
ffmpeg -v error -y -i "$M" -c:v libx264 -preset slow -crf 18 -pix_fmt yuv420p -profile:v high \
  -movflags +faststart -c:a aac -b:a 192k "$B-reels.mp4"
# WhatsApp: 720 no lado menor; o grão é o que mais pesa, então um denoise leve antes.
if [ "$W" -lt "$H" ]; then S=720:-2; else S=-2:720; fi
VF="scale=$S:flags=lanczos,hqdn3d=1.5:1.5:4:4"
AK=96
VK=$(python3 -c "print(int($ALVO*8*1024*0.97/$DUR - $AK))")
T=$(mktemp -d)
ffmpeg -v error -y -i "$M" -vf "$VF" -c:v libx264 -preset slow -b:v ${VK}k -pass 1 -passlogfile "$T/p" -an -f mp4 /dev/null
ffmpeg -v error -y -i "$M" -vf "$VF" -c:v libx264 -preset slow -b:v ${VK}k -maxrate $((VK*3/2))k -bufsize $((VK*2))k \
  -pass 2 -passlogfile "$T/p" -pix_fmt yuv420p -profile:v high -movflags +faststart -c:a aac -b:a ${AK}k "$B-whatsapp.mp4"
rm -rf "$T"
ls -l "$B-reels.mp4" "$B-whatsapp.mp4"
