#!/bin/sh
# Revisão: ffprobe, 1 quadro por segundo, folha de contato e loudness.
# Uso: qa-frames.sh <filme.mp4> [pasta-dos-quadros]
set -eu
V=${1:?filme}; F=${2:-$(dirname "$V")/frames}
mkdir -p "$F"
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate,pix_fmt:format=duration -of compact "$V"
ffmpeg -v error -y -i "$V" -vf fps=1 "$F/t%02d.png"
# folha de contato (ImageMagick): 6 colunas, miniaturas com o segundo escrito
montage "$F"/t*.png -resize 216x -tile 6x -geometry +4+4 -background '#111' -fill white -pointsize 18 \
  -label '%t' "$F/_contato.jpg" 2>/dev/null && echo "folha de contato: $F/_contato.jpg"
ffmpeg -nostats -i "$V" -af ebur128=peak=true -f null - 2>&1 | grep -A20 Summary | grep -E 'I:|Peak:|LRA:'
echo "Agora olhe TODOS os quadros em $F (e os instantes de transição: ffmpeg -ss <t> -i $V -frames:v 1 x.png)."
