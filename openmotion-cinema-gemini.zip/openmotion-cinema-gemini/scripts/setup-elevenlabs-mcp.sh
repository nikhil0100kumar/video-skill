#!/bin/sh
# Instala o MCP oficial da ElevenLabs num venv e registra no Antigravity CLI (agy) como "elevenlabs".
# Uso: setup-elevenlabs-mcp.sh <pasta-de-saida-dos-audios>
# A chave vem de ELEVENLABS_API_KEY no ambiente na hora de rodar, ou do comando em KEY_CMD
# (ex.: KEY_CMD="vault get global ELEVENLABS_API_KEY"). Ela nunca é gravada no wrapper.
set -eu
OUT=${1:?pasta de saída, ex.: ~/projetos/filme/out/elevenlabs}
mkdir -p "$OUT"
D=${ELEVENLABS_MCP_HOME:-$HOME/.local/share/elevenlabs-mcp}
[ -x "$D/bin/elevenlabs-mcp" ] || { python3 -m venv "$D" && "$D/bin/pip" install -q elevenlabs-mcp; }
KEY_CMD=${KEY_CMD:-}
cat > "$D/run.sh" <<RUN
#!/bin/sh
if [ -z "\${ELEVENLABS_API_KEY:-}" ] && [ -n "$KEY_CMD" ]; then ELEVENLABS_API_KEY=\$($KEY_CMD); fi
export ELEVENLABS_API_KEY
export ELEVENLABS_MCP_BASE_PATH="$OUT" ELEVENLABS_MODEL_ID=eleven_v4 ELEVENLABS_MCP_OUTPUT_MODE=files
exec "$D/bin/elevenlabs-mcp" "\$@"
RUN
chmod 700 "$D/run.sh"
agy mcp remove elevenlabs >/dev/null 2>&1 || true
agy mcp add elevenlabs "$D/run.sh"
agy mcp list
