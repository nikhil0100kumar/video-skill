#!/bin/sh
# Roda o Gemini 4 Neon (Antigravity CLI) em headless executando um briefing dentro do clone do OpenMotion.
# Uso: run-gemini.sh <pasta-do-projeto> [BRIEF.md] [modelo] [nome-do-log]
#   pasta-do-projeto: contém openmotion/ (clone), BRIEF.md, assets/, ref/, out/
#   modelo: gemini-4-neon-xhigh (filme principal) | gemini-4-neon-high (ajustes rápidos)
# A chave da ElevenLabs tem de estar no ambiente (export ELEVENLABS_API_KEY=… ou rode via "vault exec global --").
# Leva 30–90 min. Rode em segundo plano e acompanhe out/<log>.log; não mate por demora.
set -eu
P=$(cd "${1:?pasta do projeto}" && pwd)
BRIEF=${2:-BRIEF.md}
MODEL=${3:-gemini-4-neon-xhigh}
NAME=${4:-agy-$(date +%H%M%S)}
mkdir -p "$P/out"
cd "$P/openmotion"
agy -p "Leia $P/$BRIEF e execute tudo o que ele pede, do começo ao fim, sem parar para perguntar. O vídeo é feito com o OpenMotion deste repositório (nexu-io/openmotion), pelo fluxo nativo dele." \
  --model "$MODEL" --dangerously-skip-permissions --add-dir "$P" --print-timeout 0 \
  --log-file "$P/out/$NAME.log" > "$P/out/$NAME-output.txt" 2>&1
echo "exit $? — resposta final em $P/out/$NAME-output.txt"
