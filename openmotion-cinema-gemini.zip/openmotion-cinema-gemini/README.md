# openmotion-cinema-gemini

Skill para o agente no seu harness de preferência (T3 Code, OpenCode, DeepSeek Harness ou outro) fazer filmes de produto premium no
[OpenMotion](https://github.com/nexu-io/openmotion) com o Gemini 4 Neon executando e a ElevenLabs no som.
Nasceu do filme de 30 s do DougBot (9:16) e guarda todas as técnicas dele.

## Instalar
Use o seu harness de preferência (T3 Code, OpenCode, DeepSeek Harness ou outro): solte o .zip numa conversa e peça
"instala essa skill". O agente coloca no lugar certo. Se o harness não tiver skills, aponte para `SKILL.md`.

## Conteúdo
- `SKILL.md` — o fluxo completo e as técnicas.
- `references/` — estrutura de 7 atos, modelo de briefing, motor 3D de cinema (código), som ElevenLabs,
  checklist de revisão.
- `scripts/` — instalar o MCP da ElevenLabs no agy, rodar o Gemini em headless, revisar quadros, gerar as
  entregas (Reels e WhatsApp < 10 MB).
- `examples/` — o projeto real do DougBot: motor Three.js completo, index com o mix, composições, `Motion.md` e o
  briefing usado.
