---
name: openmotion-cinema-gemini
description: Filme de produto premium (9:16 ou 16:9, 15–30 s) feito no OpenMotion (nexu-io/openmotion) com o Gemini 4 Neon executando pelo Antigravity CLI (agy). Logo e objetos em 3D de verdade (Three.js físico), UI real do produto dentro de lâminas de vidro e celular 3D, câmera e profundidade de campo, pós de cinema em GLSL, lettering cinético na fala, narração ElevenLabs v4 com pronúncia conferida, trilha e SFX gerados pelo MCP da ElevenLabs e entregas para Reels e WhatsApp. Use quando pedirem vídeo de lançamento, filme de marca, reel de produto, "motion premium", "logo em 3D", "vídeo no estilo dessa referência" com OpenMotion ou Gemini.
---

# OpenMotion Cinema com Gemini 4 Neon

Receita completa de um filme de produto com cara de Cinema 4D/Octane, feito por agente.
Divisão de papéis:

- **Você (o agente que lê esta skill, no seu harness: T3 Code, OpenCode, DeepSeek Harness ou outro)** é o diretor: analisa a referência, escreve o briefing, gera e confere a
  voz, roda o Gemini, revisa quadro a quadro, manda correções e faz as entregas.
- **Gemini 4 Neon via `agy`** é o estúdio: monta o projeto no OpenMotion (HyperFrames + `Motion.md` + skills
  `openmotion`, `openmotion-director`, `openmotion-production`, `openmotion-media`), escreve o motor 3D, mixa e
  exporta pelo render nativo.
- **ElevenLabs** é o som: narração `eleven_v4` (API) e trilha + SFX pelo MCP `elevenlabs` ligado ao agy.

Regra de ouro do dono desta receita: **nada pode ter cara de elemento HTML.** Se alguém pausar o vídeo em
qualquer quadro, tem de parecer um filme renderizado, não uma página web.

## 0. Pré-requisitos (uma vez por máquina)

1. **OpenMotion do código-fonte**: `git clone https://github.com/nexu-io/openmotion && cd openmotion && npm ci && npm run build:studio`.
   Precisa de Node ≥ 22.18, Chrome/Chromium e ffmpeg/ffprobe. Escolha um `MOTION_DATA_DIR` (workspace) e use
   sempre o mesmo.
2. **Antigravity CLI (`agy`) logado** (`~/.gemini/antigravity-cli/antigravity-oauth-token`) e modelo fixado:
   `~/.gemini/antigravity-cli/settings.json` → `{"auth":{"type":"oauth-personal"},"model":"gemini-4-neon-high"}`.
   Para o filme principal use `gemini-4-neon-xhigh` na linha de comando (mais raciocínio, vale o tempo).
3. **MCP da ElevenLabs no agy**: `scripts/setup-elevenlabs-mcp.sh` (instala `elevenlabs-mcp`, cria o wrapper que
   lê a chave do ambiente/cofre e roda `agy mcp add elevenlabs …`). Confira com `agy mcp list`.
4. Chave `ELEVENLABS_API_KEY` disponível só dentro de comandos (cofre/`vault exec`, nunca impressa nem gravada
   no projeto).

## 1. Fluxo (siga na ordem)

### 1.1 Referência: assistir antes de planejar
Se houver vídeo de referência (reel do Instagram, comercial):
```bash
yt-dlp -o ref/ref.mp4 "<url>"
ffmpeg -i ref/ref.mp4 -vf fps=2 ref/frames/f%03d.jpg      # olhar TODOS os quadros
ffmpeg -i ref/ref.mp4 -vn -ac 1 -ar 16000 ref/a.mp3        # transcrever com scribe_v1 → ref/stt.json
```
Descreva a referência **ato por ato com tempos** (o que entra, cor de fundo, tipo de movimento, transição, onde
cai a fala). Recrie a LINGUAGEM (estrutura, ritmo, estética, tipos de movimento), nunca a marca, as cores ou o
conteúdo dela. Ver `references/estrutura-7-atos.md` (a estrutura que funcionou para 30 s vertical).

### 1.2 Material da marca
- **Logo oficial**: pergunte ou confira qual é. O arquivo "padrão" do repositório pode não ser a logo real
  (no caso DougBot o repo tinha a cabeça de frente; a oficial era o ícone do app com a cabeça espiando).
  Guarde um print da logo oficial como `assets/LOGO-OFICIAL-referencia.jpg` e mova as versões erradas para
  `assets/_NAO-USAR-…/`. Vetores em camadas (fundo, figura, silhueta) facilitam a extrusão 3D.
- **UI real**: prints do produto em alta (celular 780×1688 casa perfeito com 9:16; web 1600×1000). Dados
  fictícios. A interface nunca é redesenhada em HTML: é imagem real, recortada em pedaços.
- Cores exatas da marca em hex, e as proibidas (ex.: "nada de verde-oliva").

### 1.3 Narração (você gera e confere antes do Gemini)
`references/audio-elevenlabs.md` tem tudo. Resumo:
- `POST /v1/text-to-speech/{voice}/with-timestamps`, `model_id: "eleven_v4"`, pt-BR.
- **Pronúncia**: escreva o nome foneticamente SÓ no texto enviado à API ("DouguiBot", "douguibot ponto app"),
  mantendo a grafia real na tela. Confira com `speech-to-text` `scribe_v1` — mas saiba que o STT normaliza
  nomes de marca ("Dougbot"), então ele prova ritmo e palavras, não a pronúncia: o humano ouve os trechos do
  nome e aprova.
- Os timestamps por caractere viram a tabela de sincronia dos atos (cada palavra-chave na tela cai na fala).

### 1.4 Briefing para o Gemini
Copie `references/brief-template.md` para `BRIEF.md` do projeto e preencha. As seções que fazem a diferença:
referência ato a ato, formato e área segura, UI real em 3D, câmera e montagem, lettering, narração com
pronúncia, trilha e SFX pelo MCP (proibido usar as músicas/efeitos que vêm no OpenMotion), entrega com QA, e
**"NADA COM CARA DE HTML"** (copie inteira; é o que separa o resultado premium do genérico).

### 1.5 Rodar o Gemini 4 Neon
```bash
scripts/run-gemini.sh <pasta-do-projeto> BRIEF.md gemini-4-neon-xhigh <nome-do-log>
```
Roda em headless (`agy -p … --dangerously-skip-permissions --add-dir … --print-timeout 0 --log-file …`),
dentro do clone do OpenMotion, com a chave da ElevenLabs no ambiente. Leva de 30 a 90 min por rodada. Rode em
segundo plano e acompanhe pelo log; não mate o processo por demora.

O Gemini deve usar o fluxo nativo: `openmotion_create_project` → `openmotion_import_assets` (voz, trilha, SFX,
recortes de UI, fontes) → composições HyperFrames + `Motion.md` → `openmotion_edit_project` →
`openmotion_export_request` + `verifyExport` e o lint (`scripts/lint-project.mjs`). Nada de Remotion, Blender
ou ffmpeg montando o filme por fora.

### 1.6 Revisão de diretor (você, não o Gemini)
```bash
scripts/qa-frames.sh out/filme.mp4 out/frames      # 1 quadro/s + folha de contato + loudness
```
Olhe TODOS os quadros, com a logo oficial do lado. Checklist em `references/qa-checklist.md`. Problemas típicos
que só a revisão pega: texto atrás da logo, palavra quebrando em duas linhas num cartão, ato escuro escuro
demais e pequeno, logo grande com frase minúscula no fechamento, logo errada, verde lavado, texturas pretas,
quadro vazio entre atos, objeto passando por cima de um cartão.

Cada rodada de correção = nova seção no fim do `BRIEF.md` ("CORREÇÃO OBRIGATÓRIA (rodada N)": continue no
MESMO projeto, mantenha o que está bom, liste o que mudar com tempos) e rode o Gemini de novo.

### 1.7 Entregas
```bash
scripts/encode-deliveries.sh out/filme.mp4          # master + Reels (crf 18) + WhatsApp (< 10 MB, 720p)
```
O master do OpenMotion sai enorme (~200 MB/30 s por causa do grão por quadro). Reels: H.264 crf 18. WhatsApp:
720×1280, dois passes calculados para caber em 9,5 MB, denoise leve antes (o grão é o que mais pesa), AAC 96k.

## 2. As técnicas visuais (o que torna premium)

Detalhes e código em `references/motor-3d-cinema.md`; exemplo real completo em
`examples/doug3d-engine.example.js` (o motor do filme DougBot, ~3.600 linhas).

1. **Um palco WebGL mestre** (`layer-3d-hero`, 0–30 s) desenhando tudo em 3D, mais camadas finas por cima:
   tipografia por ato, primeiro plano desfocado (DOF) e o acabamento de lente (grão + poeira) no topo.
2. **Determinístico e "seekável"**: o motor expõe `draw(t)` e cada composição liga uma timeline GSAP pausada
   que só chama `engine.draw(state.t)`. Nada de `requestAnimationFrame`, `Date.now()` ou `Math.random()` sem
   semente: o render quadro a quadro tem de bater com o preview.
3. **Materiais físicos**: `MeshPhysicalMaterial` com clearcoat, transmissão/espessura no vidro, bisel de
   verdade (`ExtrudeGeometry` com `bevelSegments` 10–12), `ACESFilmicToneMapping`, sRGB.
4. **Luz de estúdio feita à mão**: HDRI pintado em canvas (softboxes brancos em cima e nas laterais, faixa
   neon da cor da marca embaixo/de lado) passado no `PMREMGenerator`. **Black-carding**: um retângulo quase
   preto atrás da câmera no HDRI mantém pretos piano e a cor da marca saturada (sem isso, tudo fica leitoso e
   o verde vira oliva).
5. **Logo em 3D fiel**: squircle de iOS como superelipse (`|x|^4.6 + |y|^4.6 = 1`), placa espessa com degradê
   da marca, figura extrudada recortada analiticamente pela borda da placa. Confira lado a lado com o print.
6. **UI real em lâminas de vidro**: o print vira textura de uma lâmina extrudada e biselada (frente emissiva
   para ficar legível, borda acrílica iluminada na cor da marca, brilho especular que corre na diagonal, aura
   aditiva atrás). Partes recortadas do print (mensagens, botão "Aprovar", linhas de agentes) flutuam em Z na
   frente da lâmina = parallax. Ocupe 80–86% da largura no vertical.
7. **Celular 3D modelado** (chassi metálico, botões laterais, tela OLED com scroll do print real, reflexo
   correndo no vidro) para o ato de "use no celular".
8. **Texturas de prints (NPOT)**: copie o `<img>` já decodificado para um `CanvasTexture` com `LinearFilter`
   e `generateMipmaps = false`, e sincronize a cada `draw` até carregar. Sem isso os prints saem pretos no
   render.
9. **Pós de cinema em GLSL** (3 passes): bloom que só extrai realces e a cor da marca (limiares diferentes
   por ambiente de luz), aberração cromática radial (zero no centro), motion blur radial de obturador só nas
   transições, curva S leve, vinheta, grão determinístico por quadro.
10. **Três mundos de luz** (claro → escuro com brilho da marca nas bordas → cor da marca cheia → claro) com
    um fundo ciclorama em shader e transições por movimento: whip com motion blur, zoom-through, mergulho,
    inundação radial da cor da marca, cortina.
11. **Profundidade de campo**: objetos da marca passando muito desfocados nos cantos em primeiro plano (canvas
    próprio com `filter: blur(10px)`), fundo desfocado, foco puxado para o que importa.
12. **Lettering**: família display de qualidade (Inter Display/Geist), 1–3 palavras por vez sincronizadas com
    os timestamps, entrada por máscara/blur/tracking, palavra-chave na cor da marca, rabisco de pincel desenhado
    (`stroke-dashoffset`), círculo feito à mão em volta de "tudo isso". Grão e poeira passam por cima do texto
    para ele "estar na mesma lente" do 3D.

## 3. Som

- Trilha: MCP `create_composition_plan` → `compose_music`, 30 s exatos, instrumental, seções casando com os
  atos (claro animado → escuro grave e tenso → cor eufórico → resolução). Gere 2–3 e escolha medindo energia.
- SFX: `text_to_sound_effects`, um por evento visual (whoosh do whip, swoosh de cartão, pop de mensagem,
  clique do botão, tique de progresso, riser antes do ato escuro, impacto grave no corte, shimmer da logo,
  digitação da URL, ding do check). Prompts curtos e específicos.
- Mix no próprio OpenMotion (`<audio class="clip">` com `data-volume`, `data-fade-*`, `data-automation` para
  ducking da trilha e `data-fx-chain` na voz). Alvo ~-14 LUFS, true peak < -1 dBFS.
  Detalhes e valores que funcionaram: `references/audio-elevenlabs.md`.

## 4. Erros que já custaram rodadas (não repita)

- Usar a logo "do repositório" sem confirmar a oficial.
- Deixar o Gemini recriar a UI em HTML/CSS: cartões com borda de 1 px, `box-shadow`, `backdrop-filter`.
- HDRI sem black-carding (preto acinzentado, cor da marca lavada) e reflexo colorido tingindo objetos pretos.
- Prints como textura direta (NPOT/assíncrono) → lâminas pretas.
- Texto e logo no mesmo lugar; rótulos que quebram em duas linhas; pílula/contador cobrindo título da UI.
- Ato escuro com UI pequena: aproxime a câmera e dê luz de recorte e emissivo na tela.
- Confiar no STT para provar pronúncia de marca.
- Entregar sem olhar os quadros: o relatório do Gemini sempre diz que está perfeito.
