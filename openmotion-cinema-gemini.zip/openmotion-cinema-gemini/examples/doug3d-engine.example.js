/* ============================================================================
 * DougBot Cinema4D / Octane-Grade 3D WebGL Engine (1080x1920 · 30 fps · 30.0 s)
 * Deterministic, seekable Three.js PBR renderer with custom GLSL cinema post:
 *   - Studio PMREM softbox HDRI lighting (Light Studio + Obsidian Dark Studio)
 *   - Exact Official 3D DougBot App Icon (beveled #9CFA05 glass-enamel squircle
 *     + clipped flush 3D extruded glossy #09090A tilted peeking head & white pill eyes)
 *   - Act 1: 3D inline Official Icon, 3D faceted green cursor, 3D refractive glass X/+ orbs
 *   - Act 2: Official 3D App Icon hero reveal + subtle 3D beveled glass squircle grid
 *   - Act 3: 5 sculpted 3D frosted-ceramic single-line module slabs + 3D cursor + 3D orbital hub
 *   - Act 4: Bright, close-up 3D beveled dark-glass slabs mapping REAL cropped DougBot UI
 *            screenshots with floating Z-parallax message/agent layers, live 3D Aprovar tap,
 *            and 3D glowing workflow rail
 *   - Act 5: Radiant #9CFA05 studio + 5 refractive 3D glass icon cubes + 3D titanium smartphone
 *            with real scrolling DougBot chat & floating 3D obsidian-glass headline bar
 *   - Act 6: Official 3D Icon + 4 sculpted 3D glossy spheres + 3D morphing #9CFA05 medallion
 *            with extruded 3D glossy obsidian symbols (Nodes -> Bolt -> Checkmark)
 *   - Act 7: Balanced closing lockup — 3D sculpted frosted-ceramic URL capsule with embedded
 *            mini 3D Official Icon + live typing "dougbot.app" + medium-hero Official 3D Icon
 *   - Multi-pass GLSL Cinema Post-Processing: Soft Octane Bloom + Radial Chromatic Aberration
 *     + Shutter Motion Blur on transitions + Filmic Vignette + Deterministic Cinema Film Grain
 *   - Exports:
 *       window.DougBotCinema3D(canvas)   — Unified Master 3D WebGL Cinema Stage
 *       window.DougBotFg3D(canvas)       — Blurred FG DOF Glossy Obsidian Tilted Doug Heads
 *       window.DougBotFilmFinish(canvas) — Unified Top-Most Lens Grain & Subtle Light Dust
 * ============================================================================ */
(function () {
  const WIDTH = 1080;
  const HEIGHT = 1920;
  const CAM_FOV = 34;
  const CAM_Z = 600;
  // Exact frustum at z=0: visH = 2*600*tan(17deg) = 366.877, visW = 206.368
  const PX_PER_UNIT = HEIGHT / (2 * CAM_Z * Math.tan((CAM_FOV * Math.PI) / 360)); // ~5.2333

  const ASSETS = {
    uiChannelFull: 'assets/imported/2920a49f-e5b4-4228-bff4-fda9be0a3fe4.png',
    uiChShell: 'assets/imported/5b05e03c-f222-4da7-a82f-95086d108060.png',
    uiChM1: 'assets/imported/38ec80c5-bf67-4495-bd43-fbb42ce3c5cf.png',
    uiChM2: 'assets/imported/6ccc7226-fdc4-4f00-be26-6ae893268579.png',
    uiChM3: 'assets/imported/ea54bf91-576d-4f08-9022-089f5e563028.png',
    uiChM4: 'assets/imported/2b71eda4-a3d2-4bb9-ab37-2a46f2537d43.png',
    uiPortalMain: 'assets/imported/e0ef7307-610b-43dd-854d-f269b9649881.png',
    uiPortalBtn: 'assets/imported/2f42144c-7b5c-4b89-88fd-776f4fb7db6b.png',
    uiTeamMain: 'assets/imported/7215e96a-36bd-47fd-8fc9-b90a2c19df84.png',
    uiTeamDoug: 'assets/imported/f0ff79ca-28fd-4d3a-bb5f-88b8197db460.png',
    uiTeamCortes: 'assets/imported/177449f5-4a08-4463-bcbb-5050f28f286e.png',
    uiTeamMark: 'assets/imported/bb489eca-d6d6-4e4c-a84b-d8ddaa05f849.png',
    uiTeamRosa: 'assets/imported/b82d3919-c976-43da-8a60-b37f72b29bb2.png',
    uiTeamSony: 'assets/imported/6fa241c3-2335-4085-8265-a7d6300688b5.png',
  };

  /* ---- Deterministic Math & Cinema Easing Helpers ---- */
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const seg = (t, a, b) => clamp((t - a) / (b - a), 0, 1);
  const smooth = t => {
    const c = clamp(t, 0, 1);
    return c * c * (3 - 2 * c);
  };
  const easeOutCubic = t => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
  const easeInCubic = t => Math.pow(clamp(t, 0, 1), 3);
  const easeInOutCubic = t => {
    const c = clamp(t, 0, 1);
    return c < 0.5 ? 4 * c * c * c : 1 - Math.pow(-2 * c + 2, 3) / 2;
  };
  const easeOutQuint = t => 1 - Math.pow(1 - clamp(t, 0, 1), 5);
  const easeOutBack = (t, s) => {
    const c = clamp(t, 0, 1);
    const c1 = s !== undefined ? s : 1.55;
    const c3 = c1 + 1;
    return 1 + c3 * Math.pow(c - 1, 3) + c1 * Math.pow(c - 1, 2);
  };
  const pulse = (t, a, peak, b) => {
    if (t <= a || t >= b) return 0;
    return t < peak ? smooth((t - a) / (peak - a)) : 1 - smooth((t - peak) / (b - peak));
  };

  function screenToWorld(sx, sy) {
    return { x: (sx - WIDTH * 0.5) / PX_PER_UNIT, y: (HEIGHT * 0.5 - sy) / PX_PER_UNIT };
  }

  /* ---- Shape & UV Geometry Helpers ---- */
  function createSquircleShape(halfSize, power, segs) {
    const n = power || 4.6;
    const count = segs || 128;
    const shape = new THREE.Shape();
    for (let i = 0; i <= count; i++) {
      const a = (i / count) * Math.PI * 2;
      const ca = Math.cos(a);
      const sa = Math.sin(a);
      const x = Math.sign(ca) * Math.pow(Math.abs(ca), 2 / n) * halfSize;
      const y = Math.sign(sa) * Math.pow(Math.abs(sa), 2 / n) * halfSize;
      if (i === 0) shape.moveTo(x, y);
      else shape.lineTo(x, y);
    }
    shape.closePath();
    return shape;
  }

  function createRoundedRectShape(w, h, r) {
    const hw = w * 0.5;
    const hh = h * 0.5;
    const cr = Math.min(r, hw, hh);
    const s = new THREE.Shape();
    s.moveTo(-hw + cr, -hh);
    s.lineTo(hw - cr, -hh);
    s.quadraticCurveTo(hw, -hh, hw, -hh + cr);
    s.lineTo(hw, hh - cr);
    s.quadraticCurveTo(hw, hh, hw - cr, hh);
    s.lineTo(-hw + cr, hh);
    s.quadraticCurveTo(-hw, hh, -hw, hh - cr);
    s.lineTo(-hw, -hh + cr);
    s.quadraticCurveTo(-hw, -hh, -hw + cr, -hh);
    s.closePath();
    return s;
  }

  function createPillShape(w, h) {
    const r = Math.min(w, h) * 0.5;
    const hw = w * 0.5;
    const hh = h * 0.5;
    const s = new THREE.Shape();
    if (w >= h) {
      s.moveTo(-hw + r, -hh);
      s.lineTo(hw - r, -hh);
      s.absarc(hw - r, 0, r, -Math.PI / 2, Math.PI / 2, false);
      s.lineTo(-hw + r, hh);
      s.absarc(-hw + r, 0, r, Math.PI / 2, (Math.PI * 3) / 2, false);
    } else {
      s.moveTo(-hw, -hh + r);
      s.absarc(0, -hh + r, r, Math.PI, Math.PI * 2, false);
      s.lineTo(hw, hh - r);
      s.absarc(0, hh - r, r, 0, Math.PI, false);
    }
    s.closePath();
    return s;
  }

  function normalizeExtrudeUVs(geo, w, h, insetU, insetV) {
    const pos = geo.attributes.position;
    const uv = geo.attributes.uv;
    const iu = insetU || 0;
    const iv = insetV || 0;
    for (let i = 0; i < pos.count; i++) {
      const u = clamp((pos.getX(i) + w * 0.5) / w, 0, 1);
      const v = clamp((pos.getY(i) + h * 0.5) / h, 0, 1);
      uv.setXY(i, lerp(iu, 1 - iu, u), lerp(iv, 1 - iv, v));
    }
    uv.needsUpdate = true;
  }

  function createSoftShadowPlane(w, h, opacity, colorHex) {
    const c = document.createElement('canvas');
    c.width = 256;
    c.height = 256;
    const ctx = c.getContext('2d');
    const rgb = colorHex === 'lime' ? '88, 175, 0' : '12, 16, 22';
    const g = ctx.createRadialGradient(128, 128, 6, 128, 128, 126);
    g.addColorStop(0, 'rgba(' + rgb + ', 0.42)');
    g.addColorStop(0.42, 'rgba(' + rgb + ', 0.18)');
    g.addColorStop(0.75, 'rgba(' + rgb + ', 0.04)');
    g.addColorStop(1, 'rgba(' + rgb + ', 0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 256, 256);
    const tex = new THREE.CanvasTexture(c);
    tex.encoding = THREE.sRGBEncoding;
    const mat = new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      opacity: opacity !== undefined ? opacity : 0.45,
      depthWrite: false,
    });
    return new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
  }

  /* ---- Studio Softbox HDRI Environment Maps (Light & Obsidian Dark) ---- */
  function createStudioEnvMap(renderer, mode) {
    const c = document.createElement('canvas');
    c.width = 1024;
    c.height = 512;
    const ctx = c.getContext('2d');

    if (mode === 'light') {
      // Apple/Octane "black-carded" studio HDRI:
      // Bright crisp softboxes at overhead & side bevel angles, deep dark negative-fill
      // directly behind camera so glossy #09090A obsidian stays jet-black & #9CFA05 stays
      // vibrantly saturated (ZERO milky/washed-out wash across flat front faces!).
      const bg = ctx.createLinearGradient(0, 0, 0, 512);
      bg.addColorStop(0.0, '#F6F8FB');
      bg.addColorStop(0.24, '#C8D0DA');
      bg.addColorStop(0.45, '#1A1E24');
      bg.addColorStop(0.62, '#14171C');
      bg.addColorStop(0.84, '#B2BAC4');
      bg.addColorStop(1.0, '#DDE2E8');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, 1024, 512);

      // High-intensity pure-white overhead softbox strip (sculpts topete & bevel rims)
      const top = ctx.createLinearGradient(0, 6, 0, 118);
      top.addColorStop(0, 'rgba(255,255,255,1.0)');
      top.addColorStop(0.55, 'rgba(255,255,255,0.92)');
      top.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = top;
      ctx.fillRect(110, 6, 804, 112);

      // Crisp left & right vertical studio strip softboxes (sculpts 3D rounded edges)
      const leftCard = ctx.createLinearGradient(28, 0, 195, 0);
      leftCard.addColorStop(0, 'rgba(255,255,255,0)');
      leftCard.addColorStop(0.5, 'rgba(255,255,255,0.95)');
      leftCard.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = leftCard;
      ctx.fillRect(28, 65, 167, 320);

      const rightCard = ctx.createLinearGradient(828, 0, 995, 0);
      rightCard.addColorStop(0, 'rgba(255,255,255,0)');
      rightCard.addColorStop(0.5, 'rgba(255,255,255,0.92)');
      rightCard.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = rightCard;
      ctx.fillRect(828, 65, 167, 320);

      // Deep negative-fill flag right behind camera center (keeps jet-black #09090A pure!)
      ctx.fillStyle = 'rgba(6, 7, 9, 0.94)';
      ctx.fillRect(250, 165, 524, 175);

      // Delicate narrow electric #9CFA05 lower edge bounce
      const rim = ctx.createLinearGradient(0, 464, 0, 512);
      rim.addColorStop(0, 'rgba(156,250,5,0)');
      rim.addColorStop(0.65, 'rgba(156,250,5,0.48)');
      rim.addColorStop(1, 'rgba(196,255,96,0.78)');
      ctx.fillStyle = rim;
      ctx.fillRect(180, 464, 664, 48);
    } else {
      // Dramatic Obsidian Dark Studio with pure white softbox + electric #9CFA05 edge tubes
      ctx.fillStyle = '#090B09';
      ctx.fillRect(0, 0, 1024, 512);

      // Overhead crisp white softbox
      const top = ctx.createLinearGradient(0, 14, 0, 130);
      top.addColorStop(0, 'rgba(255,255,255,1.0)');
      top.addColorStop(0.45, 'rgba(245,255,235,0.75)');
      top.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = top;
      ctx.fillRect(130, 14, 764, 116);

      // Crisp left white rim tube
      const lRim = ctx.createLinearGradient(55, 0, 210, 0);
      lRim.addColorStop(0, 'rgba(255,255,255,0)');
      lRim.addColorStop(0.5, 'rgba(248,255,244,0.88)');
      lRim.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = lRim;
      ctx.fillRect(55, 70, 155, 340);

      // Electric #9CFA05 neon right tube
      const rRim = ctx.createLinearGradient(810, 0, 970, 0);
      rRim.addColorStop(0, 'rgba(156,250,5,0)');
      rRim.addColorStop(0.5, 'rgba(176,255,46,0.98)');
      rRim.addColorStop(1, 'rgba(156,250,5,0)');
      ctx.fillStyle = rRim;
      ctx.fillRect(810, 70, 160, 360);

      // Lower #9CFA05 floor bounce
      const bot = ctx.createLinearGradient(0, 420, 0, 512);
      bot.addColorStop(0, 'rgba(156,250,5,0)');
      bot.addColorStop(0.6, 'rgba(156,250,5,0.52)');
      bot.addColorStop(1, 'rgba(210,255,120,0.88)');
      ctx.fillStyle = bot;
      ctx.fillRect(0, 420, 1024, 92);
    }

    const tex = new THREE.CanvasTexture(c);
    tex.mapping = THREE.EquirectangularReflectionMapping;
    tex.encoding = THREE.sRGBEncoding;
    const pmrem = new THREE.PMREMGenerator(renderer);
    pmrem.compileEquirectangularShader();
    const rt = pmrem.fromEquirectangular(tex);
    tex.dispose();
    pmrem.dispose();
    return rt.texture;
  }

  /* ============================================================================
   * EXACT OFFICIAL 3D DOUGBOT APP ICON BUILDER
   * Faithfully matches assets/LOGO-OFICIAL-referencia.jpg & doug-official-icon.svg:
   *  - Thick beveled iOS squircle (#E2FF98 -> #CEFF63 -> #9CFA05 -> #72D400)
   *  - Clipped flush 3D extruded glossy pitch-black (#09090A) Doug head peeking
   *    from bottom-right corner at exact -18 deg tilt, wave quiff on top,
   *    two crisp white tilted pill eyes, zero mouth!
   * ============================================================================ */
  function buildRawHeadPath120() {
    const p = new THREE.Path();
    p.moveTo(24, 74);
    p.bezierCurveTo(24, 92, 34, 102, 52, 102);
    p.lineTo(68, 102);
    p.bezierCurveTo(86, 102, 96, 92, 96, 74);
    p.lineTo(96, 52);
    p.bezierCurveTo(96, 34, 86, 21.5, 70, 21);
    p.bezierCurveTo(59, 20.6, 50.5, 24.2, 45.6, 30.2);
    p.bezierCurveTo(43.2, 33.2, 44.6, 37.6, 48.6, 37.8);
    p.bezierCurveTo(51.2, 37.9, 52.9, 36.7, 54.5, 36.3);
    p.bezierCurveTo(56.1, 35.9, 56.9, 36.9, 56.4, 38.4);
    p.bezierCurveTo(55, 42, 50.4, 44.1, 43.6, 44.9);
    p.bezierCurveTo(31.8, 46.6, 24, 54.5, 24, 66);
    p.closePath();
    return p;
  }

  function svg120ToIconLocal(x, y) {
    // Exact transform from assets/doug-official-icon.svg:
    // translate(655.36, 696.32) rotate(-18) scale(11.093) translate(-60, -60)
    // -> translate(-10.8, -12.57) scale(1.18)
    const x1 = x * 1.18 - 10.8;
    const y1 = y * 1.18 - 12.57;
    const dx = (x1 - 60) * 11.093;
    const dy = (y1 - 60) * 11.093;
    const ang = (-18 * Math.PI) / 180;
    const ca = Math.cos(ang);
    const sa = Math.sin(ang);
    const sx = 655.36 + dx * ca - dy * sa;
    const sy = 696.32 + dx * sa + dy * ca;
    // Map 1024x1024 SVG (y-down) -> [-50, 50] 3D icon space (y-up)
    return {
      x: (sx / 1024 - 0.5) * 100,
      y: (0.5 - sy / 1024) * 100,
    };
  }

  function buildClippedPeekingHeadShape(clipHalfSize, squirclePower) {
    const R = clipHalfSize;
    const N = squirclePower || 4.6;
    const inside = pt =>
      Math.pow(Math.abs(pt.x) / R, N) + Math.pow(Math.abs(pt.y) / R, N) <= 1.0;

    // Sample head path densely in SVG 120x120 coords and map into icon [-50, 50]
    const rawPts = buildRawHeadPath120().getPoints(56);
    const pts = rawPts.map(v => svg120ToIconLocal(v.x, v.y));
    const len = pts.length;

    // Bisection helper to find exact crossing on squircle curve
    function bisect(a, b) {
      let p0 = { x: a.x, y: a.y };
      let p1 = { x: b.x, y: b.y };
      const in0 = inside(p0);
      for (let k = 0; k < 22; k++) {
        const mid = { x: (p0.x + p1.x) * 0.5, y: (p0.y + p1.y) * 0.5 };
        if (inside(mid) === in0) p0 = mid;
        else p1 = mid;
      }
      return { x: (p0.x + p1.x) * 0.5, y: (p0.y + p1.y) * 0.5 };
    }

    // Find start of the contiguous inside arc (transition outside -> inside)
    let enterIdx = -1;
    for (let i = 0; i < len; i++) {
      const prev = pts[(i - 1 + len) % len];
      const curr = pts[i];
      if (!inside(prev) && inside(curr)) {
        enterIdx = i;
        break;
      }
    }

    const poly = [];
    if (enterIdx === -1) {
      // Fallback: keep all points clamped inside squircle
      pts.forEach(p => poly.push(p));
    } else {
      const enterPt = bisect(pts[(enterIdx - 1 + len) % len], pts[enterIdx]);
      poly.push(enterPt);
      let exitPt = enterPt;
      for (let step = 0; step < len; step++) {
        const idx = (enterIdx + step) % len;
        const nextIdx = (idx + 1) % len;
        const curr = pts[idx];
        const next = pts[nextIdx];
        poly.push(curr);
        if (!inside(next)) {
          exitPt = bisect(curr, next);
          poly.push(exitPt);
          break;
        }
      }

      // Close along the squircle perimeter from exitPt to enterPt via bottom-right corner!
      // Convert to superellipse parameter angle theta = atan2(sign(y)|y/R|^(N/2), sign(x)|x/R|^(N/2))
      function ptToTheta(p) {
        const cx = Math.sign(p.x) * Math.pow(Math.min(1, Math.abs(p.x) / R), N * 0.5);
        const cy = Math.sign(p.y) * Math.pow(Math.min(1, Math.abs(p.y) / R), N * 0.5);
        return Math.atan2(cy, cx);
      }

      const thStart = ptToTheta(exitPt);
      let thEnd = ptToTheta(enterPt);
      // Determine short arc direction passing through bottom-right quadrant (-pi/4)
      // Check signed delta clockwise vs counterclockwise
      let dCW = thEnd - thStart;
      while (dCW > 0) dCW -= Math.PI * 2;
      let dCCW = thEnd - thStart;
      while (dCCW < 0) dCCW += Math.PI * 2;
      // Pick whichever arc passes closer to angle -PI/4 (bottom-right corner!)
      const midCW = thStart + dCW * 0.5;
      const midCCW = thStart + dCCW * 0.5;
      const distAngle = (a, b) => Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b)));
      const dTheta = distAngle(midCW, -Math.PI * 0.25) < distAngle(midCCW, -Math.PI * 0.25) ? dCW : dCCW;

      const arcSteps = 44;
      for (let k = 1; k < arcSteps; k++) {
        const th = thStart + (dTheta * k) / arcSteps;
        const ca = Math.cos(th);
        const sa = Math.sin(th);
        poly.push({
          x: Math.sign(ca) * Math.pow(Math.abs(ca), 2 / N) * R,
          y: Math.sign(sa) * Math.pow(Math.abs(sa), 2 / N) * R,
        });
      }
    }

    const shape = new THREE.Shape();
    poly.forEach((p, idx) => {
      if (idx === 0) shape.moveTo(p.x, p.y);
      else shape.lineTo(p.x, p.y);
    });
    shape.closePath();
    return shape;
  }

  function createOfficialGreenPlateTexture() {
    const c = document.createElement('canvas');
    c.width = 1024;
    c.height = 1024;
    const ctx = c.getContext('2d');

    // Rich vibrant official DougBot green matching LOGO-OFICIAL-referencia.jpg
    // (bright #DCFF7A top-left highlight -> saturated #9CFA05 electric lime -> deep #6CE000 bottom-left, ZERO washed-out pastel!)
    const g = ctx.createLinearGradient(80, 0, 320, 1024);
    g.addColorStop(0.0, '#D4FF68');
    g.addColorStop(0.28, '#B2FF28');
    g.addColorStop(0.62, '#9CFA05');
    g.addColorStop(1.0, '#6AD600');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 1024, 1024);

    // Focused top-left glass catchlight (matching LOGO-OFICIAL-referencia.jpg's bright top-left edge)
    const gl = ctx.createRadialGradient(340, -60, 10, 340, -60, 520);
    gl.addColorStop(0, 'rgba(255,255,255,0.34)');
    gl.addColorStop(0.45, 'rgba(232,255,165,0.12)');
    gl.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gl;
    ctx.fillRect(0, 0, 1024, 1024);

    // Subtle rich bottom lime depth (pure vibrant lime, never olive!)
    const gd = ctx.createRadialGradient(420, 1160, 30, 420, 1160, 540);
    gd.addColorStop(0, 'rgba(64, 164, 0, 0.36)');
    gd.addColorStop(1, 'rgba(64, 164, 0, 0)');
    ctx.fillStyle = gd;
    ctx.fillRect(0, 0, 1024, 1024);

    // Subtle soft ambient occlusion shadow cast on green plate beneath the 3D peeking black head
    ctx.save();
    ctx.filter = 'blur(34px)';
    ctx.fillStyle = 'rgba(26, 54, 0, 0.30)';
    ctx.translate(650, 745);
    ctx.rotate((-18 * Math.PI) / 180);
    ctx.scale(11.093, 11.093);
    ctx.translate(-60, -60);
    ctx.translate(-10.8, -12.57);
    ctx.scale(1.18, 1.18);
    ctx.beginPath();
    ctx.moveTo(24, 74);
    ctx.bezierCurveTo(24, 92, 34, 102, 52, 102);
    ctx.lineTo(68, 102);
    ctx.bezierCurveTo(86, 102, 96, 92, 96, 74);
    ctx.lineTo(96, 52);
    ctx.bezierCurveTo(96, 34, 86, 21.5, 70, 21);
    ctx.bezierCurveTo(59, 20.6, 50.5, 24.2, 45.6, 30.2);
    ctx.bezierCurveTo(43.2, 33.2, 44.6, 37.6, 48.6, 37.8);
    ctx.bezierCurveTo(51.2, 37.9, 52.9, 36.7, 54.5, 36.3);
    ctx.bezierCurveTo(56.1, 35.9, 56.9, 36.9, 56.4, 38.4);
    ctx.bezierCurveTo(55, 42, 50.4, 44.1, 43.6, 44.9);
    ctx.bezierCurveTo(31.8, 46.6, 24, 54.5, 24, 66);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    const tex = new THREE.CanvasTexture(c);
    tex.encoding = THREE.sRGBEncoding;
    tex.anisotropy = 8;
    return tex;
  }

  // Shared cached geometries & textures for Official 3D App Icon (reused across Acts 1, 2, 3, 6, 7!)
  function createOfficialIconAssets() {
    const plateTex = createOfficialGreenPlateTexture();

    // 1. Thick beveled green glass-enamel squircle plate (100x100 footprint)
    const plateShape = createSquircleShape(46.6, 4.6, 128);
    const plateGeo = new THREE.ExtrudeGeometry(plateShape, {
      depth: 11.5,
      bevelEnabled: true,
      bevelThickness: 3.8,
      bevelSize: 3.4,
      bevelSegments: 18,
      curveSegments: 64,
    });
    plateGeo.translate(0, 0, -5.75);
    plateGeo.computeVertexNormals();
    normalizeExtrudeUVs(plateGeo, 100, 100, 0, 0);

    const plateFrontMat = new THREE.MeshPhysicalMaterial({
      map: plateTex,
      emissiveMap: plateTex,
      emissive: new THREE.Color('#9CFA05'),
      emissiveIntensity: 0.22,
      roughness: 0.16,
      metalness: 0.0,
      clearcoat: 0.95,
      clearcoatRoughness: 0.06,
      reflectivity: 0.72,
      envMapIntensity: 0.65,
    });
    const plateSideMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#86E800'),
      emissive: new THREE.Color('#68C800'),
      emissiveIntensity: 0.28,
      roughness: 0.10,
      metalness: 0.04,
      clearcoat: 1.0,
      clearcoatRoughness: 0.04,
      reflectivity: 0.92,
      envMapIntensity: 1.15,
    });

    // 2. Clipped flush 3D extruded glossy pitch-black (#09090A) peeking head
    const headShape = buildClippedPeekingHeadShape(47.4, 4.6);
    const headGeo = new THREE.ExtrudeGeometry(headShape, {
      depth: 4.8,
      bevelEnabled: true,
      bevelThickness: 3.2,
      bevelSize: 1.6,
      bevelSegments: 14,
      curveSegments: 48,
    });
    headGeo.computeVertexNormals();

    const headMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#040405'),
      roughness: 0.14,
      metalness: 0.02,
      clearcoat: 1.0,
      clearcoatRoughness: 0.045,
      reflectivity: 0.85,
      envMapIntensity: 0.85,
    });

    // 3. Two crisp tilted luminous-white 3D pill eyes (exact transformed coordinates)
    const eyeScale = (1.18 * 11.093 * 100) / 1024; // 1.27828
    const eyeShape = createPillShape(11.0 * eyeScale, 20.8 * eyeScale);
    const eyeGeo = new THREE.ExtrudeGeometry(eyeShape, {
      depth: 1.6,
      bevelEnabled: true,
      bevelThickness: 0.75,
      bevelSize: 0.35,
      bevelSegments: 8,
      curveSegments: 32,
    });
    eyeGeo.computeVertexNormals();

    const eyeMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#FFFFFF'),
      emissive: new THREE.Color('#FFFFFF'),
      emissiveIntensity: 1.05,
      roughness: 0.06,
      metalness: 0.0,
    });

    const leftEyePos = svg120ToIconLocal(46.6, 69.6);
    const rightEyePos = svg120ToIconLocal(73.2, 69.6);
    // In SVG y-down: -18deg - 5deg = -23deg CCW => in Three.js y-up: +23deg!
    const eyeAngleZ = (23 * Math.PI) / 180;

    return {
      spawn(withShadow) {
        const group = new THREE.Group();
        const plate = new THREE.Mesh(plateGeo, [plateFrontMat, plateSideMat]);
        group.add(plate);

        const head = new THREE.Mesh(headGeo, headMat);
        // Seat head seamlessly on front cap of green plate (z = 5.75 + 3.8 = 9.55)
        head.position.z = 8.4;
        group.add(head);

        const eyeZ = 8.4 + 4.8 + 3.2 - 0.55;
        const le = new THREE.Mesh(eyeGeo, eyeMat);
        le.position.set(leftEyePos.x, leftEyePos.y, eyeZ);
        le.rotation.z = eyeAngleZ;
        group.add(le);

        const re = new THREE.Mesh(eyeGeo, eyeMat);
        re.position.set(rightEyePos.x, rightEyePos.y, eyeZ);
        re.rotation.z = eyeAngleZ;
        group.add(re);

        if (withShadow) {
          const sh = createSoftShadowPlane(142, 42, 0.36, 'dark');
          sh.position.set(0, -64, -14);
          group.add(sh);
          const limeGlow = createSoftShadowPlane(156, 156, 0.24, 'lime');
          limeGlow.position.set(0, -4, -18);
          group.add(limeGlow);
        }
        return group;
      },
    };
  }

  /* ---- Pure 3D Tilted Glossy Pitch-Black Doug Head (ONLY for Blurred FG DOF!) ---- */
  function createStandaloneTiltedDougHead() {
    const raw = buildRawHeadPath120();
    const pts = raw.getPoints(48);
    const shape = new THREE.Shape();
    pts.forEach((p, idx) => {
      const x = p.x - 60;
      const y = -(p.y - 61.5);
      if (idx === 0) shape.moveTo(x, y);
      else shape.lineTo(x, y);
    });
    shape.closePath();

    const headGeo = new THREE.ExtrudeGeometry(shape, {
      depth: 18,
      bevelEnabled: true,
      bevelThickness: 6.5,
      bevelSize: 2.6,
      bevelSegments: 16,
      curveSegments: 48,
    });
    headGeo.translate(0, 0, -9);
    headGeo.computeVertexNormals();

    // Pure deep glossy obsidian black (#060607) — ZERO olive tint!
    const headMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#050506'),
      roughness: 0.08,
      metalness: 0.05,
      clearcoat: 1.0,
      clearcoatRoughness: 0.03,
      reflectivity: 1.0,
      envMapIntensity: 0.72,
    });

    const eyeGeo = new THREE.ExtrudeGeometry(createPillShape(11.0, 20.8), {
      depth: 2.0,
      bevelEnabled: true,
      bevelThickness: 0.8,
      bevelSize: 0.4,
      bevelSegments: 8,
      curveSegments: 28,
    });
    eyeGeo.computeVertexNormals();

    const eyeMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#FFFFFF'),
      emissive: new THREE.Color('#FFFFFF'),
      emissiveIntensity: 1.4,
      roughness: 0.05,
    });

    const group = new THREE.Group();
    group.add(new THREE.Mesh(headGeo, headMat));

    const eyeZ = 9 + 6.5 - 0.5;
    const eyeTilt = (5 * Math.PI) / 180;
    const le = new THREE.Mesh(eyeGeo, eyeMat);
    le.position.set(46.6 - 60, -(69.6 - 61.5), eyeZ);
    le.rotation.z = eyeTilt;
    group.add(le);

    const re = new THREE.Mesh(eyeGeo, eyeMat);
    re.position.set(73.2 - 60, -(69.6 - 61.5), eyeZ);
    re.rotation.z = eyeTilt;
    group.add(re);

    // Official -18 deg tilted pose!
    const holder = new THREE.Group();
    group.rotation.z = (18 * Math.PI) / 180;
    holder.add(group);
    return holder;
  }

  /* ---- 3D Vector Icon Drawing Helper (for 3D Ceramic Module Slabs & Glass Tiles) ---- */
  function drawCrispModuleIcon(ctx, kind, cx, cy, size, strokeColor) {
    ctx.save();
    ctx.translate(cx, cy);
    const s = size / 36;
    ctx.scale(s, s);
    ctx.translate(-18, -18);
    ctx.strokeStyle = strokeColor;
    ctx.fillStyle = strokeColor;
    ctx.lineWidth = 2.6;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (kind === 'chat') {
      ctx.beginPath();
      ctx.moveTo(10.5, 6);
      ctx.lineTo(25.5, 6);
      ctx.quadraticCurveTo(30, 6, 30, 10.5);
      ctx.lineTo(30, 21);
      ctx.quadraticCurveTo(30, 25.5, 25.5, 25.5);
      ctx.lineTo(15, 25.5);
      ctx.lineTo(8.5, 30.5);
      ctx.lineTo(8.5, 25.5);
      ctx.quadraticCurveTo(6, 25.5, 6, 21);
      ctx.lineTo(6, 10.5);
      ctx.quadraticCurveTo(6, 6, 10.5, 6);
      ctx.closePath();
      ctx.stroke();
      [13.5, 18, 22.5].forEach(x => {
        ctx.beginPath();
        ctx.arc(x, 15.8, 1.8, 0, Math.PI * 2);
        ctx.fill();
      });
    } else if (kind === 'agents') {
      ctx.beginPath();
      ctx.roundRect(7, 10, 22, 18, 6);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(18, 5.5);
      ctx.lineTo(18, 10);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(18, 4.5, 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.roundRect(12.8, 15.8, 3.2, 6.4, 1.6);
      ctx.roundRect(20.0, 15.8, 3.2, 6.4, 1.6);
      ctx.fill();
    } else if (kind === 'tasks') {
      ctx.beginPath();
      ctx.roundRect(7, 6, 22, 24, 5);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(12.2, 14.2);
      ctx.lineTo(15.0, 17.0);
      ctx.lineTo(20.0, 11.8);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(22.6, 14.5);
      ctx.lineTo(25.0, 14.5);
      ctx.moveTo(12.4, 22.2);
      ctx.lineTo(24.6, 22.2);
      ctx.stroke();
    } else if (kind === 'approvals') {
      ctx.beginPath();
      ctx.moveTo(18, 5);
      ctx.lineTo(29, 9.5);
      ctx.lineTo(29, 17.5);
      ctx.bezierCurveTo(29, 24.4, 24.2, 29.8, 18, 31.5);
      ctx.bezierCurveTo(11.8, 29.8, 7, 24.4, 7, 17.5);
      ctx.lineTo(7, 9.5);
      ctx.closePath();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(13, 18.2);
      ctx.lineTo(16.6, 21.8);
      ctx.lineTo(23.6, 14.6);
      ctx.stroke();
    } else if (kind === 'routines') {
      ctx.beginPath();
      ctx.arc(18, 18, 11.5, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(18, 11.2);
      ctx.lineTo(18, 18);
      ctx.lineTo(22.8, 21.2);
      ctx.stroke();
    }
    ctx.restore();
  }

  /* ---- 3D Frosted Ceramic Module Slab Texture (SINGLE LINE, ZERO HTML BADGES!) ---- */
  function createModuleSlabTexture(kind, label) {
    const c = document.createElement('canvas');
    c.width = 1024;
    c.height = 256;
    const ctx = c.getContext('2d');

    function paint() {
      ctx.clearRect(0, 0, 1024, 256);
      // Warm-white satin ceramic studio base
      const g = ctx.createLinearGradient(0, 0, 1024, 256);
      g.addColorStop(0, '#FFFFFF');
      g.addColorStop(0.55, '#F6F8FB');
      g.addColorStop(1, '#E8EDF3');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 1024, 256);

      // Subtle glossy highlight strip along top
      const hi = ctx.createLinearGradient(0, 0, 0, 90);
      hi.addColorStop(0, 'rgba(255,255,255,0.95)');
      hi.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = hi;
      ctx.fillRect(0, 0, 1024, 90);

      // Crisp obsidian #09090A squircle icon socket with radiant #9CFA05 vector icon (ZERO olive!)
      ctx.save();
      ctx.shadowColor = 'rgba(10, 12, 16, 0.16)';
      ctx.shadowBlur = 18;
      ctx.shadowOffsetY = 8;
      ctx.fillStyle = '#09090A';
      ctx.beginPath();
      ctx.roundRect(62, 54, 148, 148, 42);
      ctx.fill();
      ctx.restore();

      // Subtle inner specular highlight on black socket
      const sk = ctx.createLinearGradient(62, 54, 62, 202);
      sk.addColorStop(0, 'rgba(255,255,255,0.16)');
      sk.addColorStop(0.45, 'rgba(255,255,255,0)');
      sk.addColorStop(1, 'rgba(156,250,5,0.12)');
      ctx.fillStyle = sk;
      ctx.beginPath();
      ctx.roundRect(62, 54, 148, 148, 42);
      ctx.fill();

      drawCrispModuleIcon(ctx, kind, 136, 128, 86, '#9CFA05');

      // Single-line crisp Inter typography in pure #09090A (NEVER wraps!)
      ctx.fillStyle = '#09090A';
      ctx.font = '600 88px Inter, sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, 256, 132);
    }

    paint();
    const tex = new THREE.CanvasTexture(c);
    tex.encoding = THREE.sRGBEncoding;
    tex.anisotropy = 8;
    tex.__repaint = () => {
      paint();
      tex.needsUpdate = true;
    };
    return tex;
  }

  /* ---- 3D Frosted Glass Orbit / Floating Icon Tile Texture ---- */
  function createIconTileTexture(kind, darkOnGreen) {
    const c = document.createElement('canvas');
    c.width = 512;
    c.height = 512;
    const ctx = c.getContext('2d');
    ctx.clearRect(0, 0, 512, 512);

    if (darkOnGreen) {
      // Clear refractive crystal glass face over brand green (Act 5A)
      const g = ctx.createLinearGradient(0, 0, 512, 512);
      g.addColorStop(0, 'rgba(255, 255, 255, 0.52)');
      g.addColorStop(0.5, 'rgba(225, 255, 165, 0.24)');
      g.addColorStop(1, 'rgba(255, 255, 255, 0.34)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 512, 512);
      drawCrispModuleIcon(ctx, kind, 256, 256, 230, '#09090A');
    } else {
      // Satin white ceramic tile with obsidian socket + #9CFA05 icon (Act 3B Orbit)
      const g = ctx.createLinearGradient(0, 0, 512, 512);
      g.addColorStop(0, '#FFFFFF');
      g.addColorStop(0.6, '#F4F7FA');
      g.addColorStop(1, '#E6EBF1');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 512, 512);

      ctx.fillStyle = '#09090A';
      ctx.beginPath();
      ctx.roundRect(108, 108, 296, 296, 82);
      ctx.fill();
      drawCrispModuleIcon(ctx, kind, 256, 256, 178, '#9CFA05');
    }
    const tex = new THREE.CanvasTexture(c);
    tex.encoding = THREE.sRGBEncoding;
    tex.anisotropy = 8;
    return tex;
  }

  /* ---- 3D Refractive Frosted Glass Orb ("X" or "+") for Act 1B ---- */
  function createGlassSymbolOrb3D(symbol, radius) {
    const group = new THREE.Group();

    // Thick beveled crystal glass medallion disc
    const discShape = new THREE.Shape();
    discShape.absarc(0, 0, radius - 2.4, 0, Math.PI * 2, false);
    const discGeo = new THREE.ExtrudeGeometry(discShape, {
      depth: 7.5,
      bevelEnabled: true,
      bevelThickness: 3.4,
      bevelSize: 2.4,
      bevelSegments: 16,
      curveSegments: 64,
    });
    discGeo.translate(0, 0, -3.75);
    discGeo.computeVertexNormals();

    const glassMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#F6F9FC'),
      roughness: 0.10,
      metalness: 0.02,
      transmission: 0.64,
      thickness: 14,
      ior: 1.48,
      transparent: true,
      opacity: 0.90,
      clearcoat: 1.0,
      clearcoatRoughness: 0.04,
      reflectivity: 1.0,
      envMapIntensity: 1.45,
    });
    group.add(new THREE.Mesh(discGeo, glassMat));

    // Crisp extruded 3D white ceramic symbol bar inside the crystal orb
    const barW = radius * 0.96;
    const barH = radius * 0.21;
    const barGeo = new THREE.ExtrudeGeometry(createPillShape(barW, barH), {
      depth: 3.6,
      bevelEnabled: true,
      bevelThickness: 1.1,
      bevelSize: 0.6,
      bevelSegments: 8,
      curveSegments: 24,
    });
    barGeo.translate(0, 0, -1.8);
    barGeo.computeVertexNormals();

    const symMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#FFFFFF'),
      emissive: new THREE.Color('#FFFFFF'),
      emissiveIntensity: 0.32,
      roughness: 0.14,
      metalness: 0.0,
      clearcoat: 1.0,
      clearcoatRoughness: 0.06,
    });

    const symGroup = new THREE.Group();
    const b1 = new THREE.Mesh(barGeo, symMat);
    const b2 = new THREE.Mesh(barGeo, symMat);
    b2.rotation.z = Math.PI * 0.5;
    symGroup.add(b1);
    symGroup.add(b2);
    symGroup.rotation.z = symbol === 'x' ? Math.PI * 0.25 : 0;
    symGroup.position.z = 5.4;
    group.add(symGroup);

    // Subtle specular outer glass ring
    const ringGeo = new THREE.TorusGeometry(radius - 0.6, 0.95, 16, 72);
    const ringMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#FFFFFF'),
      roughness: 0.05,
      metalness: 0.25,
      clearcoat: 1.0,
      transparent: true,
      opacity: 0.82,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.z = 2.0;
    group.add(ring);

    return group;
  }

  /* ---- 3D Sculpted Faceted Cursor Pointer ---- */
  function createCursor3D(isLime) {
    const s = new THREE.Shape();
    s.moveTo(0, 0);
    s.lineTo(13, -7);
    s.lineTo(7.4, -9.2);
    s.lineTo(5.2, -15.5);
    s.closePath();

    const geo = new THREE.ExtrudeGeometry(s, {
      depth: 2.2,
      bevelEnabled: true,
      bevelThickness: 1.0,
      bevelSize: 0.55,
      bevelSegments: 8,
    });
    geo.computeVertexNormals();

    const mat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(isLime ? '#9CFA05' : '#FFFFFF'),
      emissive: new THREE.Color(isLime ? '#7AE000' : '#FFFFFF'),
      emissiveIntensity: isLime ? 0.36 : 0.30,
      roughness: 0.14,
      metalness: 0.02,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
      envMapIntensity: 0.95,
    });
    const mesh = new THREE.Mesh(geo, mat);
    const g = new THREE.Group();
    g.add(mesh);
    return g;
  }

  /* ---- 3D Real-UI Beveled Dark Glass Slab ---- */
  function createRealUISlab3D(tex, w, h, radius, edgeLimeStrength) {
    const group = new THREE.Group();
    const shape = createRoundedRectShape(w - 2.4, h - 2.4, radius - 1.2);
    const geo = new THREE.ExtrudeGeometry(shape, {
      depth: 6.2,
      bevelEnabled: true,
      bevelThickness: 2.4,
      bevelSize: 1.4,
      bevelSegments: 12,
      curveSegments: 32,
    });
    geo.translate(0, 0, -3.1);
    geo.computeVertexNormals();
    normalizeExtrudeUVs(geo, w, h, 0, 0);

    // Bright OLED-emissive real UI front material (vivid unclipped highlights + razor-sharp mobile legibility!)
    const frontMat = new THREE.MeshPhysicalMaterial({
      map: tex,
      emissiveMap: tex,
      emissive: new THREE.Color('#FFFFFF'),
      emissiveIntensity: 0.56,
      roughness: 0.18,
      metalness: 0.0,
      clearcoat: 0.9,
      clearcoatRoughness: 0.08,
      envMapIntensity: 0.72,
    });

    // Edge-lit acrylic glass bevel catching bright #9CFA05 neon + white studio highlights
    const sideMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#242D20'),
      emissive: new THREE.Color('#9CFA05'),
      emissiveIntensity: edgeLimeStrength !== undefined ? edgeLimeStrength : 0.48,
      roughness: 0.08,
      metalness: 0.35,
      clearcoat: 1.0,
      clearcoatRoughness: 0.03,
      envMapIntensity: 1.5,
    });

    const slab = new THREE.Mesh(geo, [frontMat, sideMat]);
    group.add(slab);

    // Subtle crisp glass rim highlight wireframe bezel
    const rimShape = createRoundedRectShape(w + 0.6, h + 0.6, radius + 0.4);
    const hole = createRoundedRectShape(w - 1.8, h - 1.8, radius - 0.8);
    rimShape.holes.push(hole);
    const rimGeo = new THREE.ShapeGeometry(rimShape, 32);
    const rimMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#C4FF5C'),
      transparent: true,
      opacity: 0.55,
    });
    const rim = new THREE.Mesh(rimGeo, rimMat);
    rim.position.z = 5.65;
    group.add(rim);

    // Animated specular glass sheen plane (subtle diagonal reflection sweeping across screen!)
    const sheenCanvas = document.createElement('canvas');
    sheenCanvas.width = 512;
    sheenCanvas.height = 512;
    const sctx = sheenCanvas.getContext('2d');
    const sg = sctx.createLinearGradient(0, 0, 512, 260);
    sg.addColorStop(0.28, 'rgba(255,255,255,0)');
    sg.addColorStop(0.47, 'rgba(255,255,255,0.22)');
    sg.addColorStop(0.52, 'rgba(210,255,130,0.16)');
    sg.addColorStop(0.68, 'rgba(255,255,255,0)');
    sctx.fillStyle = sg;
    sctx.fillRect(0, 0, 512, 512);
    const sheenTex = new THREE.CanvasTexture(sheenCanvas);
    sheenTex.encoding = THREE.sRGBEncoding;
    sheenTex.wrapS = THREE.ClampToEdgeWrapping;
    sheenTex.wrapT = THREE.ClampToEdgeWrapping;

    const sheenPlane = new THREE.Mesh(
      new THREE.ShapeGeometry(createRoundedRectShape(w - 2.6, h - 2.6, radius - 1.4), 24),
      new THREE.MeshBasicMaterial({
        map: sheenTex,
        transparent: true,
        opacity: 0.75,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    normalizeExtrudeUVs(sheenPlane.geometry, w - 2.6, h - 2.6, 0, 0);
    sheenPlane.position.z = 5.72;
    group.add(sheenPlane);

    // Soft volumetric lime backlight aura behind the dark UI slab (eliminates murky dark-mode look!)
    const glow = createSoftShadowPlane(w * 1.48, h * 1.25, 0.34, 'lime');
    glow.material.blending = THREE.AdditiveBlending;
    glow.position.z = -18;
    group.add(glow);

    return { group, frontMat, sideMat, sheenTex, glow };
  }

  /* ---- 3D Floating Real Cropped UI Blade (for Parallax Messages / Rows / Aprovar Button!) ---- */
  function createFloatingUILayer(tex, w, h, radius, insetU, insetV, isButton) {
    const group = new THREE.Group();
    const shape = createRoundedRectShape(w, h, radius);
    const geo = new THREE.ExtrudeGeometry(shape, {
      depth: isButton ? 4.2 : 2.0,
      bevelEnabled: true,
      bevelThickness: isButton ? 1.4 : 0.7,
      bevelSize: isButton ? 0.8 : 0.4,
      bevelSegments: 8,
      curveSegments: 24,
    });
    geo.translate(0, 0, isButton ? -2.1 : -1.0);
    geo.computeVertexNormals();
    normalizeExtrudeUVs(geo, w, h, insetU || 0, insetV || 0);

    const frontMat = new THREE.MeshPhysicalMaterial({
      map: tex,
      emissiveMap: tex,
      emissive: new THREE.Color('#FFFFFF'),
      emissiveIntensity: isButton ? 0.36 : 0.60,
      roughness: 0.16,
      metalness: 0.0,
      clearcoat: 0.85,
      clearcoatRoughness: 0.07,
      transparent: !isButton,
      opacity: 1,
      envMapIntensity: 0.62,
    });
    const sideMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(isButton ? '#9CFA05' : '#161A16'),
      emissive: new THREE.Color(isButton ? '#7BE400' : '#1F2B16'),
      emissiveIntensity: isButton ? 0.48 : 0.14,
      roughness: 0.12,
      clearcoat: 1.0,
    });
    const mesh = new THREE.Mesh(geo, [frontMat, sideMat]);
    group.add(mesh);

    // Subtle soft drop shadow cast onto parent glass slab behind it
    const sh = createSoftShadowPlane(w * 1.14, h * 1.38, 0.55, 'dark');
    sh.position.set(0, -2.5, isButton ? -4.2 : -2.6);
    group.add(sh);

    return { group, mesh, frontMat, sideMat };
  }

  /* ---- 3D "✓ Aprovado" Confirmation Texture ---- */
  function createApprovedButtonTexture() {
    const c = document.createElement('canvas');
    c.width = 768;
    c.height = 144;
    const ctx = c.getContext('2d');
    function paint() {
      ctx.fillStyle = '#0B0D0A';
      ctx.fillRect(0, 0, 768, 144);
      ctx.strokeStyle = '#9CFA05';
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.roundRect(10, 10, 748, 124, 62);
      ctx.stroke();

      // Checkmark + "Aprovado"
      ctx.strokeStyle = '#9CFA05';
      ctx.lineWidth = 9;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(222, 74);
      ctx.lineTo(242, 94);
      ctx.lineTo(278, 52);
      ctx.stroke();

      ctx.fillStyle = '#9CFA05';
      ctx.font = '800 56px Inter, sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText('Aprovado', 302, 74);
    }
    paint();
    const tex = new THREE.CanvasTexture(c);
    tex.encoding = THREE.sRGBEncoding;
    tex.__repaint = () => {
      paint();
      tex.needsUpdate = true;
    };
    return tex;
  }

  /* ---- 3D Telemetry Counter Pill (Beat 4D) ---- */
  function createLiveCounterPill3D() {
    const c = document.createElement('canvas');
    c.width = 512;
    c.height = 144;
    const ctx = c.getContext('2d');
    let lastKey = '';
    const tex = new THREE.CanvasTexture(c);
    tex.encoding = THREE.sRGBEncoding;

    function update(ag, active) {
      const key = ag + '|' + active;
      if (key === lastKey) return;
      lastKey = key;
      const g = ctx.createLinearGradient(0, 0, 512, 144);
      g.addColorStop(0, '#121512');
      g.addColorStop(1, '#090A09');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 512, 144);
      ctx.strokeStyle = '#9CFA05';
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.roundRect(8, 8, 496, 128, 64);
      ctx.stroke();

      ctx.fillStyle = '#9CFA05';
      ctx.font = '800 40px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(ag + ' agentes · ' + active + ' ativos', 256, 74);
      tex.needsUpdate = true;
    }
    update(11, 4);

    const w = 78;
    const h = 21;
    const geo = new THREE.ExtrudeGeometry(createPillShape(w, h), {
      depth: 3.6,
      bevelEnabled: true,
      bevelThickness: 1.2,
      bevelSize: 0.7,
      bevelSegments: 10,
      curveSegments: 32,
    });
    geo.translate(0, 0, -1.8);
    geo.computeVertexNormals();
    normalizeExtrudeUVs(geo, w, h, 0, 0);

    const fMat = new THREE.MeshPhysicalMaterial({
      map: tex,
      emissiveMap: tex,
      emissive: new THREE.Color('#FFFFFF'),
      emissiveIntensity: 0.62,
      roughness: 0.14,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
    });
    const sMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#9CFA05'),
      emissive: new THREE.Color('#70C800'),
      emissiveIntensity: 0.45,
      roughness: 0.08,
      clearcoat: 1.0,
    });
    const mesh = new THREE.Mesh(geo, [fMat, sMat]);
    return {
      mesh,
      update,
      forceRepaint() {
        lastKey = '';
      },
    };
  }

  /* ---- 3D Workflow Numbered Disc (Beat 4C) ---- */
  function createWorkflowNode3D(numStr, titleStr) {
    const group = new THREE.Group();

    const c = document.createElement('canvas');
    c.width = 256;
    c.height = 256;
    const ctx = c.getContext('2d');
    function paintNum() {
      const g = ctx.createRadialGradient(90, 74, 8, 128, 128, 130);
      g.addColorStop(0, '#E2FF98');
      g.addColorStop(0.55, '#9CFA05');
      g.addColorStop(1, '#6AC800');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 256, 256);
      ctx.fillStyle = '#09090A';
      ctx.font = '800 124px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(numStr, 128, 134);
    }
    paintNum();
    const numTex = new THREE.CanvasTexture(c);
    numTex.encoding = THREE.sRGBEncoding;
    numTex.__repaint = () => {
      paintNum();
      numTex.needsUpdate = true;
    };

    const r = 13.5;
    const s = new THREE.Shape();
    s.absarc(0, 0, r - 1.4, 0, Math.PI * 2, false);
    const geo = new THREE.ExtrudeGeometry(s, {
      depth: 5.2,
      bevelEnabled: true,
      bevelThickness: 2.4,
      bevelSize: 1.4,
      bevelSegments: 14,
      curveSegments: 48,
    });
    geo.translate(0, 0, -2.6);
    geo.computeVertexNormals();
    normalizeExtrudeUVs(geo, r * 2, r * 2, 0, 0);

    const fMat = new THREE.MeshPhysicalMaterial({
      map: numTex,
      emissiveMap: numTex,
      emissive: new THREE.Color('#9CFA05'),
      emissiveIntensity: 0.14,
      roughness: 0.14,
      clearcoat: 1.0,
      clearcoatRoughness: 0.04,
      envMapIntensity: 0.85,
    });
    const sMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#8CE800'),
      emissive: new THREE.Color('#64C400'),
      emissiveIntensity: 0.28,
      roughness: 0.08,
      clearcoat: 1.0,
    });
    group.add(new THREE.Mesh(geo, [fMat, sMat]));

    // Subtle lime bloom halo behind disc
    const aura = createSoftShadowPlane(44, 44, 0.55, 'lime');
    aura.material.blending = THREE.AdditiveBlending;
    aura.position.z = -6;
    group.add(aura);

    // Crisp label plane below node in 3D space
    const lc = document.createElement('canvas');
    lc.width = 512;
    lc.height = 144;
    const lctx = lc.getContext('2d');
    function paintLbl() {
      lctx.clearRect(0, 0, 512, 144);
      lctx.fillStyle = '#FFFFFF';
      lctx.font = '700 54px Inter, sans-serif';
      lctx.textAlign = 'center';
      lctx.textBaseline = 'middle';
      lctx.fillText(titleStr, 256, 72);
    }
    paintLbl();
    const lTex = new THREE.CanvasTexture(lc);
    lTex.encoding = THREE.sRGBEncoding;
    lTex.__repaint = () => {
      paintLbl();
      lTex.needsUpdate = true;
    };
    const lMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(54, 15.2),
      new THREE.MeshBasicMaterial({ map: lTex, transparent: true, depthWrite: false })
    );
    lMesh.position.set(0, -24, 1);
    group.add(lMesh);

    return { group, repainters: [numTex.__repaint, lTex.__repaint] };
  }

  /* ---- TRUE 3D MODELED TITANIUM SMARTPHONE (Act 5B) ---- */
  function createSmartphone3D(screenTex) {
    const group = new THREE.Group();
    const W = 122;
    const H = 250;
    const R = 16;

    // 1. Machined dark anodized titanium metallic chassis
    const bodyShape = createRoundedRectShape(W - 3.6, H - 3.6, R - 1.8);
    const bodyGeo = new THREE.ExtrudeGeometry(bodyShape, {
      depth: 8.6,
      bevelEnabled: true,
      bevelThickness: 2.8,
      bevelSize: 1.8,
      bevelSegments: 14,
      curveSegments: 36,
    });
    bodyGeo.translate(0, 0, -4.3);
    bodyGeo.computeVertexNormals();

    const titaniumMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#1B1E1B'),
      metalness: 0.88,
      roughness: 0.22,
      clearcoat: 0.85,
      clearcoatRoughness: 0.08,
      envMapIntensity: 1.65,
    });
    group.add(new THREE.Mesh(bodyGeo, titaniumMat));

    // Metallic machined side buttons (Power on right, Volume up/down on left)
    const btnGeo = new THREE.BoxGeometry(2.2, 20, 3.0);
    const pwrBtn = new THREE.Mesh(btnGeo, titaniumMat);
    pwrBtn.position.set(W * 0.5 + 0.6, 36, 0);
    group.add(pwrBtn);

    const volUp = new THREE.Mesh(new THREE.BoxGeometry(2.2, 15, 3.0), titaniumMat);
    volUp.position.set(-W * 0.5 - 0.6, 48, 0);
    group.add(volUp);

    const volDn = new THREE.Mesh(new THREE.BoxGeometry(2.2, 15, 3.0), titaniumMat);
    volDn.position.set(-W * 0.5 - 0.6, 26, 0);
    group.add(volDn);

    // 2. Recessed bright OLED real DougBot screen plane (UV scrollable!)
    const sw = W - 8.4;
    const sh = H - 8.4;
    const scrShape = createRoundedRectShape(sw, sh, R - 3.4);
    const scrGeo = new THREE.ShapeGeometry(scrShape, 32);
    // Keep vertical UV window showing ~88% of screenshot so it scrolls cleanly!
    const pos = scrGeo.attributes.position;
    const uv = scrGeo.attributes.uv;
    for (let i = 0; i < pos.count; i++) {
      const u = clamp((pos.getX(i) + sw * 0.5) / sw, 0, 1);
      const v = clamp((pos.getY(i) + sh * 0.5) / sh, 0, 1);
      uv.setXY(i, u, v);
    }
    uv.needsUpdate = true;

    const scrMat = new THREE.MeshPhysicalMaterial({
      map: screenTex,
      emissiveMap: screenTex,
      emissive: new THREE.Color('#FFFFFF'),
      emissiveIntensity: 0.82,
      roughness: 0.10,
      metalness: 0.0,
      clearcoat: 0.95,
      clearcoatRoughness: 0.04,
      envMapIntensity: 0.85,
    });
    const scrMesh = new THREE.Mesh(scrGeo, scrMat);
    scrMesh.position.z = 7.22;
    group.add(scrMesh);

    // Sleek minimal earpiece micro-slit in the top metallic bezel (never covers "# Café Aurora" header!)
    const islGeo = new THREE.ShapeGeometry(createPillShape(18, 2.2), 16);
    const isl = new THREE.Mesh(islGeo, new THREE.MeshBasicMaterial({ color: '#0A0B0A' }));
    isl.position.set(0, H * 0.5 - 2.3, 7.35);
    group.add(isl);

    // Diagonal glossy glass reflection sweeping across phone screen
    const gc = document.createElement('canvas');
    gc.width = 512;
    gc.height = 512;
    const gctx = gc.getContext('2d');
    const gg = gctx.createLinearGradient(0, 0, 512, 220);
    gg.addColorStop(0.32, 'rgba(255,255,255,0)');
    gg.addColorStop(0.48, 'rgba(255,255,255,0.28)');
    gg.addColorStop(0.55, 'rgba(210,255,140,0.16)');
    gg.addColorStop(0.68, 'rgba(255,255,255,0)');
    gctx.fillStyle = gg;
    gctx.fillRect(0, 0, 512, 512);
    const glintTex = new THREE.CanvasTexture(gc);
    glintTex.encoding = THREE.sRGBEncoding;
    const glintMesh = new THREE.Mesh(
      scrGeo.clone(),
      new THREE.MeshBasicMaterial({
        map: glintTex,
        transparent: true,
        opacity: 0.85,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    glintMesh.position.z = 7.45;
    group.add(glintMesh);

    // 3. Sculpted 3D Floating Beveled Obsidian-Glass Headline Bar hovering in front of phone!
    const bc = document.createElement('canvas');
    bc.width = 1024;
    bc.height = 256;
    const bctx = bc.getContext('2d');
    function paintBar() {
      const bg = bctx.createLinearGradient(0, 0, 1024, 256);
      bg.addColorStop(0, '#141714');
      bg.addColorStop(1, '#090A09');
      bctx.fillStyle = bg;
      bctx.fillRect(0, 0, 1024, 256);

      // Subtle glossy top highlight
      const hi = bctx.createLinearGradient(0, 0, 0, 90);
      hi.addColorStop(0, 'rgba(255,255,255,0.12)');
      hi.addColorStop(1, 'rgba(255,255,255,0)');
      bctx.fillStyle = hi;
      bctx.fillRect(0, 0, 1024, 90);

      // Crisp 2-line display typography integrated into the 3D glass bar
      bctx.textBaseline = 'middle';
      bctx.textAlign = 'left';
      bctx.font = '800 72px Inter, sans-serif';
      const line1A = 'No mesmo ';
      const line1B = 'chat';
      const wA = bctx.measureText(line1A).width;
      const wB = bctx.measureText(line1B).width;
      const startX1 = (1024 - (wA + wB)) * 0.5;
      bctx.fillStyle = '#FFFFFF';
      bctx.fillText(line1A, startX1, 88);
      bctx.fillStyle = '#9CFA05';
      bctx.fillText(line1B, startX1 + wA, 88);

      bctx.font = '700 66px Inter, sans-serif';
      bctx.textAlign = 'center';
      bctx.fillStyle = '#F2F5F2';
      bctx.fillText('que o seu time já usa.', 512, 174);
    }
    paintBar();
    const barTex = new THREE.CanvasTexture(bc);
    barTex.encoding = THREE.sRGBEncoding;
    barTex.anisotropy = 8;

    const bw = 136;
    const bh = 36;
    const barGeo = new THREE.ExtrudeGeometry(createRoundedRectShape(bw - 2, bh - 2, 9.5), {
      depth: 4.8,
      bevelEnabled: true,
      bevelThickness: 1.6,
      bevelSize: 1.0,
      bevelSegments: 10,
      curveSegments: 28,
    });
    barGeo.translate(0, 0, -2.4);
    barGeo.computeVertexNormals();
    normalizeExtrudeUVs(barGeo, bw, bh, 0, 0);

    const barGroup = new THREE.Group();
    const barMesh = new THREE.Mesh(barGeo, [
      new THREE.MeshPhysicalMaterial({
        map: barTex,
        emissiveMap: barTex,
        emissive: new THREE.Color('#FFFFFF'),
        emissiveIntensity: 0.35,
        roughness: 0.14,
        clearcoat: 1.0,
        clearcoatRoughness: 0.05,
      }),
      new THREE.MeshPhysicalMaterial({
        color: new THREE.Color('#9CFA05'),
        emissive: new THREE.Color('#6AC800'),
        emissiveIntensity: 0.45,
        roughness: 0.08,
        clearcoat: 1.0,
      }),
    ]);
    barGroup.add(barMesh);
    const barSh = createSoftShadowPlane(bw * 1.15, bh * 1.65, 0.65, 'dark');
    barSh.position.set(0, -6, -7);
    barGroup.add(barSh);
    barGroup.position.set(0, -62, 24);
    group.add(barGroup);

    // Phone soft drop shadow on bright green studio cyclorama
    const phoneSh = createSoftShadowPlane(188, 300, 0.36, 'dark');
    phoneSh.position.set(-14, -18, -28);
    group.add(phoneSh);

    return {
      group,
      barGroup,
      glintTex,
      screenTex,
      repaintBar() {
        paintBar();
        barTex.needsUpdate = true;
      },
    };
  }

  /* ---- 3D SCULPTED GLOSSY MORPHING MEDALLION WITH 3D EXTRUDED SYMBOLS (Act 6C) ---- */
  function createMorphingMedallion3D() {
    const group = new THREE.Group();
    const R = 34;

    // Thick beveled glossy #9CFA05 enamel-glass disc
    const discShape = new THREE.Shape();
    discShape.absarc(0, 0, R - 3.6, 0, Math.PI * 2, false);
    const discGeo = new THREE.ExtrudeGeometry(discShape, {
      depth: 8.4,
      bevelEnabled: true,
      bevelThickness: 4.0,
      bevelSize: 3.6,
      bevelSegments: 20,
      curveSegments: 72,
    });
    discGeo.translate(0, 0, -4.2);
    discGeo.computeVertexNormals();
    normalizeExtrudeUVs(discGeo, R * 2, R * 2, 0, 0);

    // Radiant pure #9CFA05 medallion face gradient (saturated vibrant lime, ZERO pastel wash!)
    const mc = document.createElement('canvas');
    mc.width = 512;
    mc.height = 512;
    const mctx = mc.getContext('2d');
    const mg = mctx.createRadialGradient(178, 140, 12, 256, 256, 265);
    mg.addColorStop(0.0, '#D4FF66');
    mg.addColorStop(0.32, '#B0FF24');
    mg.addColorStop(0.70, '#9CFA05');
    mg.addColorStop(1.0, '#6AD200');
    mctx.fillStyle = mg;
    mctx.fillRect(0, 0, 512, 512);
    const medTex = new THREE.CanvasTexture(mc);
    medTex.encoding = THREE.sRGBEncoding;

    const discFrontMat = new THREE.MeshPhysicalMaterial({
      map: medTex,
      emissiveMap: medTex,
      emissive: new THREE.Color('#9CFA05'),
      emissiveIntensity: 0.24,
      roughness: 0.14,
      metalness: 0.0,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
      reflectivity: 0.72,
      envMapIntensity: 0.65,
    });
    const discSideMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#86E800'),
      emissive: new THREE.Color('#64C600'),
      emissiveIntensity: 0.28,
      roughness: 0.08,
      clearcoat: 1.0,
      clearcoatRoughness: 0.03,
      envMapIntensity: 1.2,
    });
    group.add(new THREE.Mesh(discGeo, [discFrontMat, discSideMat]));

    // Subtle crisp metallic orbital accent arc around medallion
    const arcGeo = new THREE.TorusGeometry(R + 9.5, 0.75, 14, 96, Math.PI * 1.35);
    const arcMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#141714'),
      roughness: 0.2,
      metalness: 0.7,
      clearcoat: 1.0,
      transparent: true,
      opacity: 0.55,
    });
    const orbitArc = new THREE.Mesh(arcGeo, arcMat);
    group.add(orbitArc);

    // Expanding 3D crystal shockwave ring on checkmark ding
    const shockGeo = new THREE.TorusGeometry(R + 2, 1.3, 14, 72);
    const shockMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#9CFA05'),
      transparent: true,
      opacity: 0,
    });
    const shockRing = new THREE.Mesh(shockGeo, shockMat);
    group.add(shockRing);

    // Glossy obsidian #09090A 3D material for extruded symbols mounted on medallion face
    const symMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#09090A'),
      roughness: 0.12,
      metalness: 0.08,
      clearcoat: 1.0,
      clearcoatRoughness: 0.04,
      envMapIntensity: 1.25,
    });

    const symZ = 8.4;

    // Symbol 1: Connected 3-Node Team Network
    const symNodes = new THREE.Group();
    const nCoords = [
      [0, 10.5],
      [-10.5, -7.8],
      [10.5, -7.8],
    ];
    const nodeGeo = new THREE.CylinderGeometry(4.6, 4.6, 3.6, 32);
    nodeGeo.rotateX(Math.PI * 0.5);
    nCoords.forEach(([x, y]) => {
      const m = new THREE.Mesh(nodeGeo, symMat);
      m.position.set(x, y, symZ);
      symNodes.add(m);
    });
    function addStrut(a, b) {
      const dx = b[0] - a[0];
      const dy = b[1] - a[1];
      const d = Math.hypot(dx, dy);
      const sg = new THREE.BoxGeometry(d, 2.3, 2.4);
      const sm = new THREE.Mesh(sg, symMat);
      sm.position.set((a[0] + b[0]) * 0.5, (a[1] + b[1]) * 0.5, symZ - 0.3);
      sm.rotation.z = Math.atan2(dy, dx);
      symNodes.add(sm);
    }
    addStrut(nCoords[0], nCoords[1]);
    addStrut(nCoords[0], nCoords[2]);
    addStrut(nCoords[1], nCoords[2]);
    group.add(symNodes);

    // Symbol 2: Crisp Extruded 3D Lightning Speed Bolt
    const symBolt = new THREE.Group();
    const bs = new THREE.Shape();
    bs.moveTo(2.5, 16);
    bs.lineTo(-12.5, -1.5);
    bs.lineTo(-1.0, -1.5);
    bs.lineTo(-4.0, -16);
    bs.lineTo(12.5, 2.2);
    bs.lineTo(1.2, 2.2);
    bs.closePath();
    const boltGeo = new THREE.ExtrudeGeometry(bs, {
      depth: 2.8,
      bevelEnabled: true,
      bevelThickness: 0.9,
      bevelSize: 0.5,
      bevelSegments: 8,
    });
    boltGeo.computeVertexNormals();
    const boltMesh = new THREE.Mesh(boltGeo, symMat);
    boltMesh.position.z = symZ - 1.2;
    symBolt.add(boltMesh);
    group.add(symBolt);

    // Symbol 3: Bold Extruded 3D Resolution Checkmark
    const symCheck = new THREE.Group();
    const cs = new THREE.Shape();
    // Thick rounded checkmark polygon
    cs.moveTo(-14.5, 0.5);
    cs.lineTo(-10.8, 4.2);
    cs.lineTo(-3.2, -3.4);
    cs.lineTo(11.6, 11.4);
    cs.lineTo(15.4, 7.6);
    cs.lineTo(-3.2, -11.0);
    cs.closePath();
    const checkGeo = new THREE.ExtrudeGeometry(cs, {
      depth: 3.0,
      bevelEnabled: true,
      bevelThickness: 1.0,
      bevelSize: 0.6,
      bevelSegments: 8,
    });
    checkGeo.computeVertexNormals();
    const checkMesh = new THREE.Mesh(checkGeo, symMat);
    checkMesh.position.z = symZ - 1.2;
    symCheck.add(checkMesh);
    group.add(symCheck);

    // Soft studio shadow + luminous lime glow under medallion
    const sh = createSoftShadowPlane(96, 28, 0.34, 'dark');
    sh.position.set(0, -45, -12);
    group.add(sh);
    const gl = createSoftShadowPlane(116, 116, 0.28, 'lime');
    gl.position.set(0, 0, -16);
    group.add(gl);

    return { group, orbitArc, shockRing, shockMat, symNodes, symBolt, symCheck };
  }

  /* ---- 3D SCULPTED FROSTED-CERAMIC CLOSING URL CAPSULE PILL (Act 7) ---- */
  function createClosingCapsule3D(officialIconAssets) {
    const group = new THREE.Group();
    const W = 114;
    const H = 23.5;

    const c = document.createElement('canvas');
    c.width = 1024;
    c.height = 224;
    const ctx = c.getContext('2d');
    const tex = new THREE.CanvasTexture(c);
    tex.encoding = THREE.sRGBEncoding;
    tex.anisotropy = 8;

    const FULL_URL = 'dougbot.app';
    let lastDrawKey = '';

    function updateText(charCount, showCaret) {
      const key = charCount + '|' + (showCaret ? '1' : '0');
      if (key === lastDrawKey) return;
      lastDrawKey = key;

      const g = ctx.createLinearGradient(0, 0, 1024, 224);
      g.addColorStop(0, '#FFFFFF');
      g.addColorStop(0.55, '#F6F8FB');
      g.addColorStop(1, '#E9EEF4');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 1024, 224);

      const hi = ctx.createLinearGradient(0, 0, 0, 84);
      hi.addColorStop(0, 'rgba(255,255,255,0.95)');
      hi.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = hi;
      ctx.fillRect(0, 0, 1024, 84);

      const txt = FULL_URL.slice(0, charCount);
      ctx.fillStyle = '#09090A';
      ctx.font = '600 84px Inter, sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      const startX = 248;
      ctx.fillText(txt, startX, 116);

      if (showCaret) {
        const w = ctx.measureText(txt).width;
        ctx.fillStyle = '#9CFA05';
        ctx.fillRect(startX + w + 8, 68, 9, 92);
        ctx.strokeStyle = '#09090A';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(startX + w + 8, 68, 9, 92);
      }
      tex.needsUpdate = true;
    }
    updateText(0, true);

    const shape = createPillShape(W - 3.6, H - 3.6);
    const geo = new THREE.ExtrudeGeometry(shape, {
      depth: 5.0,
      bevelEnabled: true,
      bevelThickness: 2.2,
      bevelSize: 1.8,
      bevelSegments: 14,
      curveSegments: 48,
    });
    geo.translate(0, 0, -2.5);
    geo.computeVertexNormals();
    normalizeExtrudeUVs(geo, W, H, 0, 0);

    const fMat = new THREE.MeshPhysicalMaterial({
      map: tex,
      emissiveMap: tex,
      emissive: new THREE.Color('#FFFFFF'),
      emissiveIntensity: 0.32,
      roughness: 0.14,
      metalness: 0.0,
      clearcoat: 1.0,
      clearcoatRoughness: 0.04,
      envMapIntensity: 0.92,
    });
    const sMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#F5F7FA'),
      emissive: new THREE.Color('#FFFFFF'),
      emissiveIntensity: 0.16,
      roughness: 0.08,
      metalness: 0.04,
      clearcoat: 1.0,
      clearcoatRoughness: 0.03,
      envMapIntensity: 1.25,
    });
    group.add(new THREE.Mesh(geo, [fMat, sMat]));

    // Embed an authentic miniature 3D Official DougBot App Icon proudly seated on the left of the ceramic capsule!
    const miniIcon = officialIconAssets.spawn(false);
    miniIcon.scale.setScalar(0.162);
    miniIcon.position.set(-41.5, 0, 6.4);
    group.add(miniIcon);

    // Soft studio ground shadow underneath 3D capsule
    const sh = createSoftShadowPlane(W * 1.18, 28, 0.30, 'dark');
    sh.position.set(0, -18, -10);
    group.add(sh);

    return {
      group,
      updateText,
      forceRepaint() {
        lastDrawKey = '';
      },
    };
  }

  /* ============================================================================
   * CINEMA POST-PROCESSING SHADER PIPELINE (Octane Bloom + CA + Motion Blur + Grain)
   * ============================================================================ */
  function createCinemaPostPipeline(renderer) {
    const postScene = new THREE.Scene();
    const postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const quadGeo = new THREE.PlaneGeometry(2, 2);

    const rtOpts = {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: THREE.UnsignedByteType,
    };
    const isWebGL2 = !!renderer.capabilities.isWebGL2;
    const rtScene = new THREE.WebGLRenderTarget(
      WIDTH,
      HEIGHT,
      isWebGL2 ? Object.assign({}, rtOpts, { samples: 4 }) : rtOpts
    );
    const rtBloomA = new THREE.WebGLRenderTarget(WIDTH / 2, HEIGHT / 2, rtOpts);
    const rtBloomB = new THREE.WebGLRenderTarget(WIDTH / 2, HEIGHT / 2, rtOpts);

    // Pass 1: Threshold + Horizontal 9-tap Gaussian Bloom
    const bloomHMat = new THREE.ShaderMaterial({
      uniforms: {
        tDiffuse: { value: null },
        uTexel: { value: new THREE.Vector2(2 / WIDTH, 2 / HEIGHT) },
        uMode: { value: 0 }, // 0=light, 1=dark, 2=green
      },
      vertexShader: `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
      `,
      fragmentShader: `
        uniform sampler2D tDiffuse;
        uniform vec2 uTexel;
        uniform float uMode;
        varying vec2 vUv;

        vec3 extractGlow(vec3 c) {
          float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
          // Pure electric lime detector (#9CFA05 glow extraction)
          float lime = clamp((c.g - max(c.b, c.r * 0.65) - 0.18) * 2.4, 0.0, 1.0) * smoothstep(0.45, 0.92, c.g);
          // Specular highlight extraction (higher threshold in light studio so white backdrop doesn't bloom)
          float thresh = mix(0.955, 0.72, clamp(uMode, 0.0, 1.0));
          float hi = smoothstep(thresh, thresh + 0.14, luma);
          float limeWeight = mix(0.45, 0.85, clamp(uMode, 0.0, 1.0));
          if (uMode > 1.5) {
            // In full green studio, bloom crisp highlights only (don't wash out green backdrop)
            limeWeight = 0.08;
            hi = smoothstep(0.92, 1.02, luma);
          }
          return c * max(hi * 0.75, lime * limeWeight);
        }

        void main() {
          vec3 sum = extractGlow(texture2D(tDiffuse, vUv).rgb) * 0.227027;
          sum += extractGlow(texture2D(tDiffuse, vUv + vec2(uTexel.x * 1.5, 0.0)).rgb) * 0.1945946;
          sum += extractGlow(texture2D(tDiffuse, vUv - vec2(uTexel.x * 1.5, 0.0)).rgb) * 0.1945946;
          sum += extractGlow(texture2D(tDiffuse, vUv + vec2(uTexel.x * 3.5, 0.0)).rgb) * 0.1216216;
          sum += extractGlow(texture2D(tDiffuse, vUv - vec2(uTexel.x * 3.5, 0.0)).rgb) * 0.1216216;
          sum += extractGlow(texture2D(tDiffuse, vUv + vec2(uTexel.x * 6.0, 0.0)).rgb) * 0.054054;
          sum += extractGlow(texture2D(tDiffuse, vUv - vec2(uTexel.x * 6.0, 0.0)).rgb) * 0.054054;
          sum += extractGlow(texture2D(tDiffuse, vUv + vec2(uTexel.x * 9.0, 0.0)).rgb) * 0.016216;
          sum += extractGlow(texture2D(tDiffuse, vUv - vec2(uTexel.x * 9.0, 0.0)).rgb) * 0.016216;
          gl_FragColor = vec4(sum, 1.0);
        }
      `,
      depthTest: false,
      depthWrite: false,
    });

    // Pass 2: Vertical 9-tap Gaussian Bloom
    const bloomVMat = new THREE.ShaderMaterial({
      uniforms: {
        tDiffuse: { value: null },
        uTexel: { value: new THREE.Vector2(2 / WIDTH, 2 / HEIGHT) },
      },
      vertexShader: `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
      `,
      fragmentShader: `
        uniform sampler2D tDiffuse;
        uniform vec2 uTexel;
        varying vec2 vUv;
        void main() {
          vec3 sum = texture2D(tDiffuse, vUv).rgb * 0.227027;
          sum += texture2D(tDiffuse, vUv + vec2(0.0, uTexel.y * 1.5)).rgb * 0.1945946;
          sum += texture2D(tDiffuse, vUv - vec2(0.0, uTexel.y * 1.5)).rgb * 0.1945946;
          sum += texture2D(tDiffuse, vUv + vec2(0.0, uTexel.y * 3.5)).rgb * 0.1216216;
          sum += texture2D(tDiffuse, vUv - vec2(0.0, uTexel.y * 3.5)).rgb * 0.1216216;
          sum += texture2D(tDiffuse, vUv + vec2(0.0, uTexel.y * 6.0)).rgb * 0.054054;
          sum += texture2D(tDiffuse, vUv - vec2(0.0, uTexel.y * 6.0)).rgb * 0.054054;
          sum += texture2D(tDiffuse, vUv + vec2(0.0, uTexel.y * 9.0)).rgb * 0.016216;
          sum += texture2D(tDiffuse, vUv - vec2(0.0, uTexel.y * 9.0)).rgb * 0.016216;
          gl_FragColor = vec4(sum, 1.0);
        }
      `,
      depthTest: false,
      depthWrite: false,
    });

    // Pass 3: Final Cinema Composite (Motion Blur + Radial CA + Soft Bloom + Filmic Vignette + Grain)
    const compositeMat = new THREE.ShaderMaterial({
      uniforms: {
        tScene: { value: null },
        tBloom: { value: null },
        uBloomStrength: { value: 0.32 },
        uMotionBlur: { value: 0.0 },
        uVignette: { value: 0.16 },
        uGrain: { value: 0.014 },
        uFrame: { value: 0.0 },
        uDarkMode: { value: 0.0 },
      },
      vertexShader: `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
      `,
      fragmentShader: `
        uniform sampler2D tScene;
        uniform sampler2D tBloom;
        uniform float uBloomStrength;
        uniform float uMotionBlur;
        uniform float uVignette;
        uniform float uGrain;
        uniform float uFrame;
        uniform float uDarkMode;
        varying vec2 vUv;

        float hash12(vec2 p) {
          vec3 p3 = fract(vec3(p.xyx) * 0.1031);
          p3 += dot(p3, p3.yzx + 33.33);
          return fract((p3.x + p3.y) * p3.z);
        }

        void main() {
          vec2 dir = vUv - vec2(0.5);
          float r2 = dot(dir, dir);

          // Radial optical chromatic aberration (zero at center, gentle cinema lens dispersion at edges)
          vec2 caOffset = dir * r2 * 0.0042;
          vec3 col;

          if (uMotionBlur > 0.002) {
            // 7-tap radial shutter zoom motion blur during whip/zoom transitions
            vec3 acc = vec3(0.0);
            for (int i = -3; i <= 3; i++) {
              float fi = float(i) / 3.0;
              vec2 sUv = clamp(vUv - dir * fi * uMotionBlur * 0.14, 0.001, 0.999);
              acc.r += texture2D(tScene, clamp(sUv + caOffset, 0.001, 0.999)).r;
              acc.g += texture2D(tScene, sUv).g;
              acc.b += texture2D(tScene, clamp(sUv - caOffset, 0.001, 0.999)).b;
            }
            col = acc / 7.0;
          } else {
            col.r = texture2D(tScene, clamp(vUv + caOffset, 0.001, 0.999)).r;
            col.g = texture2D(tScene, vUv).g;
            col.b = texture2D(tScene, clamp(vUv - caOffset, 0.001, 0.999)).b;
          }

          // Soft additive Octane bloom
          vec3 bloom = texture2D(tBloom, vUv).rgb;
          col += bloom * uBloomStrength;

          // Subtle filmic S-curve micro-contrast (gentle, preserves exact #9CFA05 & dark UI clarity)
          col = mix(col, col * col * (3.0 - 2.0 * col), mix(0.06, 0.10, uDarkMode));

          // Optical cinema vignette
          float vig = 1.0 - smoothstep(0.24, 0.96, length(dir * vec2(1.0, 0.88))) * uVignette;
          col *= vig;

          // Fine deterministic cinema film grain
          float g = hash12(gl_FragCoord.xy + vec2(uFrame * 17.3, uFrame * 31.7)) - 0.5;
          col += vec3(g * uGrain);

          gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
        }
      `,
      depthTest: false,
      depthWrite: false,
    });

    const quad = new THREE.Mesh(quadGeo, compositeMat);
    postScene.add(quad);

    return {
      rtScene,
      render(scene, camera, opts) {
        renderer.setRenderTarget(rtScene);
        renderer.clear();
        renderer.render(scene, camera);

        // Bloom horizontal
        quad.material = bloomHMat;
        bloomHMat.uniforms.tDiffuse.value = rtScene.texture;
        bloomHMat.uniforms.uMode.value = opts.mode || 0;
        renderer.setRenderTarget(rtBloomA);
        renderer.render(postScene, postCam);

        // Bloom vertical
        quad.material = bloomVMat;
        bloomVMat.uniforms.tDiffuse.value = rtBloomA.texture;
        renderer.setRenderTarget(rtBloomB);
        renderer.render(postScene, postCam);

        // Composite to canvas
        quad.material = compositeMat;
        compositeMat.uniforms.tScene.value = rtScene.texture;
        compositeMat.uniforms.tBloom.value = rtBloomB.texture;
        compositeMat.uniforms.uBloomStrength.value = opts.bloomStrength;
        compositeMat.uniforms.uMotionBlur.value = opts.motionBlur || 0;
        compositeMat.uniforms.uVignette.value = opts.vignette;
        compositeMat.uniforms.uGrain.value = opts.grain;
        compositeMat.uniforms.uFrame.value = opts.frame || 0;
        compositeMat.uniforms.uDarkMode.value = opts.mode === 1 ? 1.0 : 0.0;
        renderer.setRenderTarget(null);
        renderer.render(postScene, postCam);
      },
      dispose() {
        rtScene.dispose();
        rtBloomA.dispose();
        rtBloomB.dispose();
        quadGeo.dispose();
        bloomHMat.dispose();
        bloomVMat.dispose();
        compositeMat.dispose();
      },
    };
  }

  /* ---- Full-Screen Studio Cyclorama Backdrop Shader (3 Worlds + Seamless Wipes) ---- */
  function createStudioBackdropMesh() {
    const mat = new THREE.ShaderMaterial({
      uniforms: {
        uDarkMix: { value: 0.0 },
        uGreenMix: { value: 0.0 },
        uPlungeRadius: { value: 0.0 },
        uGreenFloodRadius: { value: 0.0 },
        uLightCurtainY: { value: 0.0 },
        uTime: { value: 0.0 },
        uRingAlpha: { value: 1.0 },
      },
      vertexShader: `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = vec4(position.xy, 0.999, 1.0); }
      `,
      fragmentShader: `
        uniform float uDarkMix;
        uniform float uGreenMix;
        uniform float uPlungeRadius;
        uniform float uGreenFloodRadius;
        uniform float uLightCurtainY;
        uniform float uTime;
        uniform float uRingAlpha;
        varying vec2 vUv;

        void main() {
          vec2 p = (vUv - vec2(0.5, 0.52)) * vec2(1.0, 1.7778);
          float d = length(p);

          // 1. Light Studio Architectural Cyclorama
          vec3 lightBg = mix(vec3(0.976, 0.980, 0.988), vec3(0.875, 0.890, 0.912), smoothstep(0.0, 1.15, d));
          // Subtle overhead softbox falloff
          lightBg += vec3(0.025) * smoothstep(0.85, 0.0, length((vUv - vec2(0.5, 0.72)) * vec2(1.0, 1.4)));

          // 2. Pure Obsidian Carbon Dark Studio with crisp electric #9CFA05 edge glow (ZERO olive mud!)
          vec3 darkBg = mix(vec3(0.038, 0.042, 0.040), vec3(0.016, 0.018, 0.019), smoothstep(0.0, 1.05, d));
          float glowTR = exp(-dot((vUv - vec2(0.88, 0.80)) * vec2(1.2, 1.8), (vUv - vec2(0.88, 0.80)) * vec2(1.2, 1.8)) * 3.0);
          float glowBL = exp(-dot((vUv - vec2(0.10, 0.20)) * vec2(1.2, 1.8), (vUv - vec2(0.10, 0.20)) * vec2(1.2, 1.8)) * 3.2);
          float glowCenter = exp(-d * d * 3.2);
          darkBg += vec3(0.612, 0.980, 0.020) * (glowTR * 0.22 + glowBL * 0.18 + glowCenter * 0.10);

          // 3. Vibrant Pure #9CFA05 Brand Green Studio Cyclorama (ZERO olive!)
          vec3 greenTop = vec3(0.755, 1.0, 0.28);
          vec3 greenMid = vec3(0.612, 0.980, 0.020); // exact #9CFA05
          vec3 greenEdge = vec3(0.510, 0.895, 0.0);
          vec3 greenBg = mix(greenTop, greenMid, smoothstep(0.0, 0.58, d));
          greenBg = mix(greenBg, greenEdge, smoothstep(0.58, 1.25, d));

          // Subtle concentric studio geometry arcs
          float breath = 1.0 + sin(uTime * 0.9) * 0.025;
          float r1 = abs(d - 0.30 * breath);
          float r2 = abs(d - 0.48 * breath);
          float r3 = abs(d - 0.68 * breath);
          float ringLine = (smoothstep(0.0024, 0.0005, r1) + smoothstep(0.0024, 0.0005, r2) * 0.85 + smoothstep(0.0024, 0.0005, r3) * 0.65) * uRingAlpha;

          lightBg = mix(lightBg, vec3(0.10, 0.12, 0.16), ringLine * 0.075);
          darkBg += vec3(0.612, 0.980, 0.020) * ringLine * 0.14;
          greenBg = mix(greenBg, vec3(0.04, 0.04, 0.04), ringLine * 0.11);

          vec3 col = mix(lightBg, darkBg, uDarkMix);
          col = mix(col, greenBg, uGreenMix);

          // Explosive dark plunge disc (end of Act 3)
          if (uPlungeRadius > 0.001) {
            float m = 1.0 - smoothstep(uPlungeRadius - 0.08, uPlungeRadius, d);
            col = mix(col, darkBg, m);
          }

          // Explosive #9CFA05 brand-green flood wipe (end of Act 4)
          if (uGreenFloodRadius > 0.001) {
            float m = 1.0 - smoothstep(uGreenFloodRadius - 0.08, uGreenFloodRadius, d);
            col = mix(col, greenBg, m);
          }

          // Crisp vertical studio light curtain wipe (end of Act 5 -> Act 6)
          if (uLightCurtainY > 0.001) {
            float m = 1.0 - smoothstep(uLightCurtainY - 0.05, uLightCurtainY, vUv.y);
            col = mix(col, lightBg, m);
          }

          gl_FragColor = vec4(col, 1.0);
        }
      `,
      depthTest: false,
      depthWrite: false,
    });
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), mat);
    mesh.frustumCulled = false;
    mesh.renderOrder = -1000;
    return { mesh, mat };
  }

  /* ---- Synchronous Preloaded Image Texture Helper (NPOT-safe + ShadowRoot-safe!) ---- */
  function createSyncedImageTexture(rootEl, imgId, fallbackUrl) {
    // Draw onto a 1x1 dark placeholder canvas first, then synchronously copy the real
    // decoded <img> onto an exact CanvasTexture the instant img.complete && naturalWidth > 0!
    // Copying into a CanvasTexture with LinearFilter + generateMipmaps=false guarantees
    // 100% WebGL1/WebGL2 compatibility for NPOT screenshots (780x1688, 780x1280, etc.)
    // AND works reliably across Shadow DOM / HyperFrames template mounting!
    const c = document.createElement('canvas');
    c.width = 4;
    c.height = 4;
    const tex = new THREE.CanvasTexture(c);
    tex.encoding = THREE.sRGBEncoding;
    tex.minFilter = THREE.LinearFilter;
    tex.magFilter = THREE.LinearFilter;
    tex.generateMipmaps = false;
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;

    let synced = false;
    let fallbackImg = null;

    function bindFromImg(el) {
      if (!el || !el.complete || !el.naturalWidth || !el.naturalHeight) return false;
      c.width = el.naturalWidth;
      c.height = el.naturalHeight;
      const ctx = c.getContext('2d');
      ctx.clearRect(0, 0, c.width, c.height);
      ctx.drawImage(el, 0, 0);
      tex.needsUpdate = true;
      synced = true;
      return true;
    }

    function sync() {
      if (synced) return true;
      const el =
        (rootEl && rootEl.querySelector ? rootEl.querySelector('#' + imgId) : null) ||
        document.getElementById(imgId);
      if (bindFromImg(el)) return true;
      if (el && !el.__hooked) {
        el.__hooked = true;
        el.addEventListener('load', () => bindFromImg(el), { once: true });
      }
      if (!fallbackImg && fallbackUrl) {
        fallbackImg = new Image();
        fallbackImg.crossOrigin = 'anonymous';
        fallbackImg.onload = () => bindFromImg(fallbackImg);
        fallbackImg.src = fallbackUrl;
      } else if (fallbackImg && fallbackImg.complete && fallbackImg.naturalWidth > 0) {
        return bindFromImg(fallbackImg);
      }
      return false;
    }

    sync();
    tex.__sync = sync;
    return tex;
  }

  /* ============================================================================
   * 1. MASTER CINEMA 3D ENGINE (window.DougBotCinema3D)
   * ============================================================================ */
  window.DougBotCinema3D = function (canvas) {
    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: false,
      antialias: true,
      preserveDrawingBuffer: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(WIDTH, HEIGHT, false);
    renderer.setPixelRatio(1);
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.98;
    renderer.autoClear = false;

    const rootEl = canvas.parentNode || document;
    const syncedTextures = [];
    function regTex(imgId, url) {
      const t = createSyncedImageTexture(rootEl, imgId, url);
      syncedTextures.push(t);
      return t;
    }

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(CAM_FOV, WIDTH / HEIGHT, 1, 3000);
    camera.position.set(0, 0, CAM_Z);

    const envLight = createStudioEnvMap(renderer, 'light');
    const envDark = createStudioEnvMap(renderer, 'dark');
    scene.environment = envLight;

    const post = createCinemaPostPipeline(renderer);
    const backdrop = createStudioBackdropMesh();
    scene.add(backdrop.mesh);

    // Master Studio Lighting Rig (dynamically tuned for Light / Dark / Green worlds)
    const ambLight = new THREE.AmbientLight(0xffffff, 0.55);
    scene.add(ambLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.85);
    keyLight.position.set(-120, 220, 260);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xf2f6ff, 0.95);
    fillLight.position.set(160, 80, 180);
    scene.add(fillLight);

    const rimLime = new THREE.DirectionalLight(0x9cfa05, 1.2);
    rimLime.position.set(140, -140, 60);
    scene.add(rimLime);

    const sweepLight = new THREE.PointLight(0xffffff, 0, 420, 1.4);
    sweepLight.position.set(-180, 90, 140);
    scene.add(sweepLight);

    // Official 3D App Icon Factory
    const officialIcons = createOfficialIconAssets();

    // Font repaint registry (guarantees real Inter TTF once document.fonts is ready!)
    const fontRepainters = [];
    let fontReadyPainted = false;

    /* ---- ACT 1B & 1A 3D OBJECTS ---- */
    const act1Group = new THREE.Group();
    scene.add(act1Group);

    // Inline 3D Official Mini Icon between "do seu" and "time"
    const a1MiniIcon = officialIcons.spawn(false);
    act1Group.add(a1MiniIcon);

    // 3D Sculpted Faceted Lime Cursor for Phase 1A
    const a1Cursor = createCursor3D(true);
    act1Group.add(a1Cursor);

    // 3 Sculpted 3D Refractive Frosted-Glass Orbs (X center, + top-left, + bottom-right)
    const orbCenter = createGlassSymbolOrb3D('x', 16.5);
    const orbTL = createGlassSymbolOrb3D('+', 33);
    const orbBR = createGlassSymbolOrb3D('+', 35);
    act1Group.add(orbCenter, orbTL, orbBR);

    /* ---- ACT 2: OFFICIAL 3D LOGO REVEAL + SUBTLE 3D BEVELED GLASS SQUIRCLE GRID ---- */
    const act2Group = new THREE.Group();
    scene.add(act2Group);

    const a2HeroIcon = officialIcons.spawn(true);
    act2Group.add(a2HeroIcon);

    // 4 architectural translucent 3D glass squircles gently blooming behind the Official Icon
    const a2BgTiles = [];
    const bgTileGeo = new THREE.ExtrudeGeometry(createSquircleShape(26, 4.6, 64), {
      depth: 2.0,
      bevelEnabled: true,
      bevelThickness: 1.0,
      bevelSize: 0.8,
      bevelSegments: 8,
    });
    bgTileGeo.translate(0, 0, -1);
    const bgTileMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#FFFFFF'),
      roughness: 0.14,
      metalness: 0.0,
      transmission: 0.55,
      thickness: 6,
      transparent: true,
      opacity: 0.42,
      clearcoat: 1.0,
      clearcoatRoughness: 0.06,
    });
    const bgTileSpots = [
      [-48, 62, -62],
      [48, 52, -74],
      [-52, -16, -68],
      [46, -24, -60],
    ];
    bgTileSpots.forEach(([x, y, z]) => {
      const m = new THREE.Mesh(bgTileGeo, bgTileMat);
      m.position.set(x, y, z);
      act2Group.add(m);
      a2BgTiles.push(m);
    });

    /* ---- ACT 3: 5 SCULPTED 3D FROSTED-CERAMIC MODULE SLABS + 3D ORBITAL HUB ---- */
    const act3Group = new THREE.Group();
    scene.add(act3Group);

    const a3StackRig = new THREE.Group();
    act3Group.add(a3StackRig);

    const MODULE_DEFS = [
      { kind: 'chat', label: 'chat', t: 5.54 },
      { kind: 'agents', label: 'agentes de IA', t: 6.26 },
      { kind: 'tasks', label: 'tarefas', t: 7.32 },
      { kind: 'approvals', label: 'aprovações', t: 8.06 },
      { kind: 'routines', label: 'rotinas', t: 8.84 },
    ];

    const slabW = 136;
    const slabH = 31;
    const slabGeo = new THREE.ExtrudeGeometry(createPillShape(slabW - 3.6, slabH - 3.6), {
      depth: 5.2,
      bevelEnabled: true,
      bevelThickness: 2.2,
      bevelSize: 1.8,
      bevelSegments: 14,
      curveSegments: 40,
    });
    slabGeo.translate(0, 0, -2.6);
    slabGeo.computeVertexNormals();
    normalizeExtrudeUVs(slabGeo, slabW, slabH, 0, 0);

    const slabSideMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#F5F7FA'),
      emissive: new THREE.Color('#FFFFFF'),
      emissiveIntensity: 0.16,
      roughness: 0.08,
      metalness: 0.04,
      clearcoat: 1.0,
      clearcoatRoughness: 0.03,
      envMapIntensity: 1.25,
    });

    const a3Slabs = MODULE_DEFS.map((m, i) => {
      const tex = createModuleSlabTexture(m.kind, m.label);
      fontRepainters.push(tex.__repaint);
      const fMat = new THREE.MeshPhysicalMaterial({
        map: tex,
        emissiveMap: tex,
        emissive: new THREE.Color('#FFFFFF'),
        emissiveIntensity: 0.32,
        roughness: 0.14,
        metalness: 0.0,
        clearcoat: 1.0,
        clearcoatRoughness: 0.05,
        transparent: true,
        opacity: 1,
        envMapIntensity: 0.90,
      });
      const wrap = new THREE.Group();
      const mesh = new THREE.Mesh(slabGeo, [fMat, slabSideMat]);
      wrap.add(mesh);
      const sh = createSoftShadowPlane(slabW * 1.12, slabH * 1.55, 0.28, 'dark');
      sh.position.set(0, -5, -10);
      wrap.add(sh);
      a3StackRig.add(wrap);
      return { wrap, mesh, fMat, sh, baseY: 76 - i * 39.5, tIn: m.t };
    });

    const a3Cursor = createCursor3D(true);
    a3StackRig.add(a3Cursor);

    // Phase 3B: 3D Orbital Hub around Official 3D DougBot App Icon
    const a3OrbitGroup = new THREE.Group();
    act3Group.add(a3OrbitGroup);

    const a3HubIcon = officialIcons.spawn(true);
    a3OrbitGroup.add(a3HubIcon);

    const orbitRingMesh = new THREE.Mesh(
      new THREE.TorusGeometry(66, 0.55, 16, 120),
      new THREE.MeshPhysicalMaterial({
        color: new THREE.Color('#20262E'),
        roughness: 0.25,
        metalness: 0.5,
        transparent: true,
        opacity: 0.26,
      })
    );
    a3OrbitGroup.add(orbitRingMesh);

    const orbitInnerRing = new THREE.Mesh(
      new THREE.TorusGeometry(45, 0.45, 14, 96),
      new THREE.MeshBasicMaterial({
        color: new THREE.Color('#9CFA05'),
        transparent: true,
        opacity: 0.45,
      })
    );
    a3OrbitGroup.add(orbitInnerRing);

    const tileW = 24;
    const tileGeo = new THREE.ExtrudeGeometry(createSquircleShape(tileW * 0.5 - 1.6, 4.4, 48), {
      depth: 4.0,
      bevelEnabled: true,
      bevelThickness: 1.6,
      bevelSize: 1.4,
      bevelSegments: 10,
    });
    tileGeo.translate(0, 0, -2.0);
    tileGeo.computeVertexNormals();
    normalizeExtrudeUVs(tileGeo, tileW, tileW, 0, 0);

    const a3OrbitTiles = MODULE_DEFS.map((m, i) => {
      const tex = createIconTileTexture(m.kind, false);
      const mat = new THREE.MeshPhysicalMaterial({
        map: tex,
        emissiveMap: tex,
        emissive: new THREE.Color('#FFFFFF'),
        emissiveIntensity: 0.30,
        roughness: 0.14,
        metalness: 0.0,
        clearcoat: 1.0,
        clearcoatRoughness: 0.04,
        envMapIntensity: 0.95,
      });
      const g = new THREE.Group();
      g.add(new THREE.Mesh(tileGeo, [mat, slabSideMat]));
      const sh = createSoftShadowPlane(32, 32, 0.22, 'dark');
      sh.position.set(0, -4, -9);
      g.add(sh);
      a3OrbitGroup.add(g);
      return { group: g, angle0: Math.PI * 0.5 - (i * Math.PI * 2) / 5 };
    });

    /* ---- ACT 4: BRIGHT, CLOSE-UP 3D REAL-UI GLASS LAMINATES (Obsidian Studio) ---- */
    const act4Group = new THREE.Group();
    scene.add(act4Group);

    const texChShell = regTex('tex-ch-shell', ASSETS.uiChShell);
    const texChM1 = regTex('tex-ch-m1', ASSETS.uiChM1);
    const texChM2 = regTex('tex-ch-m2', ASSETS.uiChM2);
    const texChM3 = regTex('tex-ch-m3', ASSETS.uiChM3);
    const texChM4 = regTex('tex-ch-m4', ASSETS.uiChM4);
    const texPortalMain = regTex('tex-portal-main', ASSETS.uiPortalMain);
    const texPortalBtn = regTex('tex-portal-btn', ASSETS.uiPortalBtn);
    const texTeamMain = regTex('tex-team-main', ASSETS.uiTeamMain);
    const texTeamDoug = regTex('tex-team-doug', ASSETS.uiTeamDoug);
    const texTeamCortes = regTex('tex-team-cortes', ASSETS.uiTeamCortes);
    const texTeamMark = regTex('tex-team-mark', ASSETS.uiTeamMark);
    const texTeamRosa = regTex('tex-team-rosa', ASSETS.uiTeamRosa);
    const texTeamSony = regTex('tex-team-sony', ASSETS.uiTeamSony);

    // Beat 4A: Real # Café Aurora Channel Slab (158 x 259 units => ~84% viewport width, 100% inside safe area!)
    const chW = 158;
    const chH = chW * (1280 / 780);
    const a4ChatSlab = createRealUISlab3D(texChShell, chW, chH, 13, 0.50);
    act4Group.add(a4ChatSlab.group);

    // 4 Real Cropped Message Layers cleanly scaled (0.84x) so ZERO overlap occurs between header & input bar!
    const chScale = chW / 780;
    const msgS = chScale * 0.84;
    const chM1 = createFloatingUILayer(texChM1, 732 * msgS, 228 * msgS, 4.8, 0, 0, false);
    const chM2 = createFloatingUILayer(texChM2, 732 * msgS, 222 * msgS, 4.8, 0, 0, false);
    const chM3 = createFloatingUILayer(texChM3, 616 * msgS, 426 * msgS, 4.8, 0, 0, false);
    const chM4 = createFloatingUILayer(texChM4, 732 * msgS, 184 * msgS, 4.8, 0, 0, false);
    a4ChatSlab.group.add(chM1.group, chM2.group, chM3.group, chM4.group);

    // Beat 4B: Real Client Approval Portal Slab (132 x 274 units => ~78-82% width when close, 100% inside Reels safe area!)
    const poW = 132;
    const poH = poW * (1618 / 780);
    const a4PortalSlab = createRealUISlab3D(texPortalMain, poW, poH, 13, 0.68);
    act4Group.add(a4PortalSlab.group);

    // Real cropped glowing "Aprovar" button lifted in 3D Z-space right above its slot!
    const poScale = poW / 780;
    // In ui-portal-main (cropped y=12..1630), button is at y=1392-12=1380 .. 1500-12=1488 (center y=1434)
    const btnCenterY = poH * 0.5 - 1434 * poScale;
    const a4ApproveBtn = createFloatingUILayer(
      texPortalBtn,
      648 * poScale,
      98 * poScale,
      8.6,
      0.03,
      0.08,
      true
    );
    a4ApproveBtn.group.position.set(0, btnCenterY, 14);
    a4PortalSlab.group.add(a4ApproveBtn.group);

    const texApprovedState = createApprovedButtonTexture();
    fontRepainters.push(texApprovedState.__repaint);

    // Luminous 3D shockwave ring on button tap
    const a4TapRing = new THREE.Mesh(
      new THREE.TorusGeometry(15, 0.95, 12, 64),
      new THREE.MeshBasicMaterial({ color: '#9CFA05', transparent: true, opacity: 0 })
    );
    a4TapRing.position.set(0, btnCenterY, 18);
    a4PortalSlab.group.add(a4TapRing);

    // 3D Sculpted Cursor tapping the real Aprovar button
    const a4Cursor = createCursor3D(false);
    a4PortalSlab.group.add(a4Cursor);

    // Beat 4C: 3D Glowing Workflow Rail (4 glowing #9CFA05 numbered discs on neon glass rail)
    const a4RailGroup = new THREE.Group();
    act4Group.add(a4RailGroup);

    const railTube = new THREE.Mesh(
      new THREE.CylinderGeometry(0.9, 0.9, 250, 16),
      new THREE.MeshStandardMaterial({
        color: '#9CFA05',
        emissive: '#9CFA05',
        emissiveIntensity: 0.95,
        roughness: 0.15,
      })
    );
    railTube.rotation.z = Math.PI * 0.5;
    a4RailGroup.add(railTube);

    const railDefs = [
      ['1', 'Pedido'],
      ['2', 'Agentes'],
      ['3', 'Aprovação'],
      ['4', 'Entrega'],
    ];
    const a4RailNodes = railDefs.map(([n, lbl], idx) => {
      const node = createWorkflowNode3D(n, lbl);
      node.group.position.set(-120 + idx * 80, 0, 2);
      a4RailGroup.add(node.group);
      node.repainters.forEach(fn => fontRepainters.push(fn));
      return node.group;
    });

    // Beat 4D: Real "Seu time agora" Glass Slab + Floating Real Agent Parallax Layers!
    const tmW = 158;
    const tmH = tmW * (1310 / 780);
    const a4TeamSlab = createRealUISlab3D(texTeamMain, tmW, tmH, 13, 0.60);
    act4Group.add(a4TeamSlab.group);

    const tmScale = tmW / 780;
    // Exact Y offsets inside ui-team-main (cropped y=110..1420)
    const tmDougLayer = createFloatingUILayer(texTeamDoug, 732 * tmScale, 170 * tmScale, 6.8, 0, 0, false);
    const tmDougY = tmH * 0.5 - ((588 + 758) * 0.5 - 110) * tmScale;
    tmDougLayer.group.position.set(0, tmDougY, 12);
    a4TeamSlab.group.add(tmDougLayer.group);

    const tmRows = [
      { tex: texTeamCortes, y0: 792, y1: 912 },
      { tex: texTeamMark, y0: 916, y1: 1034 },
      { tex: texTeamRosa, y0: 1038, y1: 1156 },
      { tex: texTeamSony, y0: 1160, y1: 1278 },
    ].map(r => {
      const layer = createFloatingUILayer(r.tex, 692 * tmScale, (r.y1 - r.y0) * tmScale, 4.5, 0, 0, false);
      const cy = tmH * 0.5 - ((r.y0 + r.y1) * 0.5 - 110) * tmScale;
      layer.group.position.set(0, cy, 10);
      a4TeamSlab.group.add(layer.group);
      return { layer, cy };
    });

    const a4CounterPill = createLiveCounterPill3D();
    fontRepainters.push(() => a4CounterPill.forceRepaint());
    // Positioned cleanly floating above the top-right bezel so "Seu time agora" is 100% unobstructed!
    a4CounterPill.mesh.position.set(34, tmH * 0.5 + 14, 24);
    a4TeamSlab.group.add(a4CounterPill.mesh);

    /* ---- ACT 5: 5 3D GLASS ICON CUBES + TRUE 3D TITANIUM SMARTPHONE FLYOVER ---- */
    const act5Group = new THREE.Group();
    scene.add(act5Group);

    const a5GlassCubesGroup = new THREE.Group();
    act5Group.add(a5GlassCubesGroup);

    const glassCubeSideMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#E8FFA8'),
      roughness: 0.06,
      metalness: 0.02,
      transmission: 0.72,
      thickness: 12,
      ior: 1.5,
      transparent: true,
      opacity: 0.85,
      clearcoat: 1.0,
      clearcoatRoughness: 0.03,
      envMapIntensity: 1.5,
    });
    const cubePos = [
      [-64, 96, 22, 1.15],
      [66, 74, -24, 0.92],
      [-68, -74, -12, 1.0],
      [64, -92, 30, 1.22],
      [6, 128, -42, 0.82],
    ];
    const a5Cubes = MODULE_DEFS.map((m, i) => {
      const tex = createIconTileTexture(m.kind, true);
      const fMat = new THREE.MeshPhysicalMaterial({
        map: tex,
        roughness: 0.08,
        metalness: 0.0,
        transparent: true,
        opacity: 0.92,
        clearcoat: 1.0,
        clearcoatRoughness: 0.03,
      });
      const mesh = new THREE.Mesh(tileGeo, [fMat, glassCubeSideMat]);
      const [x, y, z, s] = cubePos[i];
      mesh.position.set(x, y, z);
      mesh.scale.setScalar(s);
      a5GlassCubesGroup.add(mesh);
      return { mesh, x, y, z, s };
    });

    // True 3D Titanium Smartphone with REAL scrolling DougBot mobile channel (starts cleanly at # Café Aurora header!)
    const texChannelFull = regTex('tex-channel-full', ASSETS.uiChannelFull);
    texChannelFull.repeat.set(1, 0.82);
    texChannelFull.offset.set(0, 0.18);
    const a5Phone = createSmartphone3D(texChannelFull);
    fontRepainters.push(() => a5Phone.repaintBar());
    act5Group.add(a5Phone.group);

    /* ---- ACT 6: OFFICIAL 3D ICON + 4 SCULPTED 3D SPHERES + 3D MORPHING MEDALLION ---- */
    const act6Group = new THREE.Group();
    scene.add(act6Group);

    const a6InlineIcon = officialIcons.spawn(true);
    act6Group.add(a6InlineIcon);

    // Beat 6B: 4 Sculpted 3D Glossy Spheres + Luminous 3D Connecting Laser Beam
    const a6DotsGroup = new THREE.Group();
    act6Group.add(a6DotsGroup);

    const dotBeamBg = new THREE.Mesh(
      new THREE.CylinderGeometry(0.6, 0.6, 114, 14),
      new THREE.MeshBasicMaterial({ color: '#1A1F26', transparent: true, opacity: 0.14 })
    );
    dotBeamBg.rotation.z = Math.PI * 0.5;
    a6DotsGroup.add(dotBeamBg);

    const dotBeamFill = new THREE.Mesh(
      new THREE.CylinderGeometry(1.15, 1.15, 114, 16),
      new THREE.MeshStandardMaterial({
        color: '#9CFA05',
        emissive: '#9CFA05',
        emissiveIntensity: 0.85,
        roughness: 0.12,
      })
    );
    dotBeamFill.rotation.z = Math.PI * 0.5;
    a6DotsGroup.add(dotBeamFill);

    const sphGeo = new THREE.SphereGeometry(7.6, 48, 48);
    const a6Spheres = [-57, -19, 19, 57].map(x => {
      const mat = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color('#09090A'),
        emissive: new THREE.Color('#000000'),
        emissiveIntensity: 0,
        roughness: 0.10,
        metalness: 0.06,
        clearcoat: 1.0,
        clearcoatRoughness: 0.03,
        envMapIntensity: 1.35,
      });
      const g = new THREE.Group();
      const mesh = new THREE.Mesh(sphGeo, mat);
      g.add(mesh);
      const sh = createSoftShadowPlane(22, 9, 0.34, 'dark');
      sh.position.set(0, -13, -6);
      g.add(sh);
      g.position.set(x, 12, 0);
      a6DotsGroup.add(g);
      return { group: g, mat, x };
    });
    dotBeamBg.position.set(0, 12, -2);
    dotBeamFill.position.set(0, 12, -1);

    // Beat 6C: Sculpted 3D Glossy #9CFA05 Morphing Medallion
    const a6Medallion = createMorphingMedallion3D();
    act6Group.add(a6Medallion.group);

    /* ---- ACT 7: BALANCED CLOSING LOCKUP (3D CERAMIC CAPSULE + MEDIUM-HERO OFFICIAL 3D ICON) ---- */
    const act7Group = new THREE.Group();
    scene.add(act7Group);

    const a7Capsule = createClosingCapsule3D(officialIcons);
    fontRepainters.push(() => a7Capsule.forceRepaint());
    act7Group.add(a7Capsule.group);

    const a7HeroIcon = officialIcons.spawn(true);
    act7Group.add(a7HeroIcon);

    /* ---- Ensure real Inter font repaints once loaded ---- */
    function checkFontRepaint() {
      if (fontReadyPainted) return;
      if (document.fonts && document.fonts.check && document.fonts.check('600 48px Inter')) {
        fontReadyPainted = true;
        fontRepainters.forEach(fn => fn());
      }
    }
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(() => {
        fontReadyPainted = false;
        checkFontRepaint();
      });
    }

    /* ============================================================================
     * DETERMINISTIC SEEKABLE FRAME DRAW(t) FOR t IN [0, 30]
     * ============================================================================ */
    function draw(t) {
      checkFontRepaint();
      for (let i = 0; i < syncedTextures.length; i++) syncedTextures[i].__sync();

      // Hide all act groups initially; enable only active time windows
      act1Group.visible = false;
      act2Group.visible = false;
      act3Group.visible = false;
      act4Group.visible = false;
      act5Group.visible = false;
      act6Group.visible = false;
      act7Group.visible = false;

      // Default camera & lighting
      camera.position.set(0, 0, CAM_Z);
      camera.rotation.set(0, 0, 0);
      camera.fov = CAM_FOV;
      camera.updateProjectionMatrix();

      // Determine lighting mode (0=light, 1=dark, 2=green)
      let mode = 0;
      let darkMix = 0;
      let greenMix = 0;
      let plungeR = 0;
      let greenFloodR = 0;
      let lightCurtainY = 0;
      let ringAlpha = 1.0;
      let motionBlur = 0;
      let bloomStrength = 0.24;
      let vignette = 0.14;

      if (t >= 10.50 && t < 10.92) {
        plungeR = easeInCubic(seg(t, 10.50, 10.92)) * 1.38;
        motionBlur = smooth(seg(t, 10.54, 10.90)) * 1.1;
      }
      if (t >= 10.88 && t < 17.56) {
        mode = 1;
        darkMix = 1.0;
        bloomStrength = 0.46;
        vignette = 0.28;
      }
      if (t >= 17.24 && t < 17.56) {
        greenFloodR = easeInCubic(seg(t, 17.24, 17.56)) * 1.42;
        motionBlur = smooth(seg(t, 17.28, 17.54)) * 0.9;
      }
      if (t >= 17.54 && t < 20.56) {
        mode = 2;
        darkMix = 0.0;
        greenMix = 1.0;
        bloomStrength = 0.22;
        vignette = 0.16;
      }
      if (t >= 20.28 && t < 20.58) {
        lightCurtainY = easeInOutCubic(seg(t, 20.28, 20.58)) * 1.15;
        motionBlur = pulse(t, 20.28, 20.43, 20.58) * 0.85;
      }

      // Transition shutter motion blur pulses in Act 1
      motionBlur = Math.max(
        motionBlur,
        pulse(t, 1.66, 1.80, 1.96) * 0.95,
        pulse(t, 3.58, 3.76, 3.94) * 1.15
      );

      // Update studio environment & lighting mood (balanced exposure so #9CFA05 stays rich & #09090A stays jet black!)
      scene.environment = mode === 1 ? envDark : envLight;
      ambLight.intensity = mode === 1 ? 0.34 : mode === 2 ? 0.44 : 0.36;
      keyLight.intensity = mode === 1 ? 1.85 : 1.28;
      keyLight.position.set(mode === 1 ? -95 : -145, 250, 145);
      fillLight.intensity = mode === 1 ? 0.58 : 0.52;
      rimLime.intensity = mode === 1 ? 1.85 : mode === 2 ? 1.05 : 0.72;
      sweepLight.intensity = 0;

      // Update studio backdrop uniforms
      backdrop.mat.uniforms.uDarkMix.value = darkMix;
      backdrop.mat.uniforms.uGreenMix.value = greenMix;
      backdrop.mat.uniforms.uPlungeRadius.value = plungeR;
      backdrop.mat.uniforms.uGreenFloodRadius.value = greenFloodR;
      backdrop.mat.uniforms.uLightCurtainY.value = lightCurtainY;
      backdrop.mat.uniforms.uTime.value = t;
      backdrop.mat.uniforms.uRingAlpha.value = ringAlpha;

      /* ---------------- ACT 1 (0.00 - 3.95s) ---------------- */
      if (t >= 0 && t < 3.95) {
        act1Group.visible = true;

        // Phase 1A inline 3D Official Mini Icon (1.20 - 1.88s) + 3D cursor (1.30 - 1.88s)
        const show1A = t >= 1.16 && t < 1.92;
        a1MiniIcon.visible = show1A;
        a1Cursor.visible = t >= 1.28 && t < 1.92;
        if (show1A) {
          const pIn = easeOutBack(seg(t, 1.22, 1.56), 1.8);
          const pOut = easeInCubic(seg(t, 1.68, 1.92));
          // Aligned inline in the blank slot between "do seu" and "time" (screen x~508, y~994)
          const pos = screenToWorld(505 - pOut * 240, 998);
          a1MiniIcon.position.set(pos.x, pos.y, pOut * 60);
          a1MiniIcon.scale.setScalar(0.148 * Math.max(0.001, pIn) * (1 - pOut * 0.98));
          a1MiniIcon.rotation.set(lerp(0.45, -0.06, pIn), lerp(-0.85, 0.14, pIn), lerp(-0.22, 0.0, pIn));
        }
        if (a1Cursor.visible) {
          const pC = easeOutCubic(seg(t, 1.32, 1.72));
          const pOut = easeInCubic(seg(t, 1.68, 1.92));
          const cPos = screenToWorld(lerp(560, 748, pC) - pOut * 260, lerp(1078, 1068, pC));
          a1Cursor.position.set(cPos.x, cPos.y, 20);
          a1Cursor.scale.setScalar(0.95 * smooth(seg(t, 1.30, 1.44)) * (1 - pOut));
          a1Cursor.rotation.set(0.18, -0.25 + pC * 0.2, 0.12);
        }

        // Phase 1B: 3 Sculpted 3D Refractive Glass Orbs ("X" center + two "+" FG corners)
        const show1B = t >= 1.80 && t < 3.95;
        orbCenter.visible = show1B;
        orbTL.visible = show1B;
        orbBR.visible = show1B;
        if (show1B) {
          const pIn = easeOutCubic(seg(t, 1.84, 2.48));
          const pDrift = seg(t, 1.84, 3.65);
          const pZoom = easeInCubic(seg(t, 3.58, 3.94));

          // Center X glass orb sitting cleanly above "não precisa ser complicado" (screen y ~ 690px)
          orbCenter.position.set(0, 52 + Math.sin(pDrift * Math.PI) * 3.5, lerp(-45, 0, pIn) + pZoom * 340);
          orbCenter.scale.setScalar(lerp(0.35, 1.05, pIn) * (1 + pZoom * 1.4));
          orbCenter.rotation.set(lerp(0.5, -0.08, pIn), lerp(-0.6, 0.22, pDrift), lerp(-0.35, 0.12, pDrift));

          // Top-left + glass orb drifting across upper corner
          orbTL.position.set(lerp(-104, -76, pDrift) - pZoom * 80, lerp(164, 148, pDrift) + pZoom * 70, 55 + pZoom * 140);
          orbTL.scale.setScalar(lerp(0.7, 1.06, pIn));
          orbTL.rotation.set(0.22, lerp(0.55, 0.18, pDrift), lerp(-0.18, 0.14, pDrift));

          // Bottom-right + glass orb drifting across lower corner
          orbBR.position.set(lerp(106, 78, pDrift) + pZoom * 80, lerp(-166, -148, pDrift) - pZoom * 70, 62 + pZoom * 140);
          orbBR.scale.setScalar(lerp(0.7, 1.08, pIn));
          orbBR.rotation.set(-0.20, lerp(-0.55, -0.16, pDrift), lerp(0.16, -0.14, pDrift));
        }
      }

      /* ---------------- ACT 2: OFFICIAL 3D APP ICON HERO REVEAL (3.70 - 5.28s) ---------------- */
      if (t >= 3.70 && t < 5.28) {
        act2Group.visible = true;
        const pIn = easeOutBack(seg(t, 3.76, 4.38), 1.35);
        const pOut = easeInOutCubic(seg(t, 4.94, 5.26));

        // Hero Official 3D App Icon positioned cleanly at screen y ~ 745px (world y = +41)
        // Wordmark "DougBot" sits at screen y = 1015px -> ZERO OVERLAP!
        a2HeroIcon.position.set(0, lerp(28, 41, pIn) + pOut * 65, lerp(-90, 0, pIn));
        a2HeroIcon.scale.setScalar(0.64 * Math.max(0.01, lerp(0.22, 1.0, pIn)) * lerp(1.0, 0.65, pOut));
        a2HeroIcon.rotation.set(
          lerp(0.28, -0.04, easeOutCubic(seg(t, 3.76, 4.55))),
          lerp(-0.62, 0.06, easeOutCubic(seg(t, 3.76, 4.65))) + Math.sin((t - 3.76) * 2.1) * 0.035,
          lerp(-0.08, 0.0, pIn)
        );

        // Background 3D translucent squircle tiles blooming delicately behind icon
        const pBg = easeOutCubic(seg(t, 3.78, 4.90));
        a2BgTiles.forEach((tile, i) => {
          const [bx, by, bz] = bgTileSpots[i];
          tile.position.set(bx * lerp(0.78, 1.06, pBg), by * lerp(0.78, 1.06, pBg) + pOut * 35, bz);
          tile.scale.setScalar(lerp(0.65, 1.0, pBg) * (1 - pOut));
          tile.rotation.y = lerp(-0.18, 0.10, pBg) * (i % 2 === 0 ? 1 : -1);
        });

        // Tasteful cinema specular studio sweep across icon bevels (never bleaches rich #9CFA05!)
        const sw = seg(t, 4.16, 4.88);
        sweepLight.color.setHex(0xe4ff9a);
        sweepLight.intensity = Math.sin(sw * Math.PI) * 2.4;
        sweepLight.position.set(lerp(-140, 140, sw), 125, 92);
      }

      /* ---------------- ACT 3: 3D CERAMIC MODULE SLABS & 3D ORBITAL HUB (5.05 - 10.94s) ---------------- */
      if (t >= 5.05 && t < 10.94) {
        act3Group.visible = true;
        const showStack = t < 9.75;
        const showOrbit = t >= 9.36;

        a3StackRig.visible = showStack;
        a3OrbitGroup.visible = showOrbit;

        if (showStack) {
          const pTrack = easeInOutCubic(seg(t, 5.20, 9.40));
          const pExit = easeInCubic(seg(t, 9.36, 9.74));

          // Angled 3D camera rig gliding smoothly upward as slabs stack diagonally (mirroring ref f010-f016!)
          a3StackRig.position.set(lerp(4, -6, pTrack), lerp(-46, 56, pTrack), lerp(0, -140, pExit));
          a3StackRig.rotation.set(
            lerp(0.18, 0.28, pTrack),
            lerp(-0.24, -0.34, pTrack),
            lerp(-0.11, -0.15, pTrack)
          );
          a3StackRig.scale.setScalar(lerp(0.96, 1.04, pTrack) * (1 - pExit * 0.55));

          // Active card index for depth emphasis
          let activeIdx = 0;
          for (let i = 0; i < a3Slabs.length; i++) {
            if (t >= a3Slabs[i].tIn) activeIdx = i;
          }

          a3Slabs.forEach((s, i) => {
            const pIn = easeOutBack(seg(t, s.tIn, s.tIn + 0.44), 1.35);
            const vis = t >= s.tIn - 0.02;
            s.wrap.visible = vis;
            if (!vis) return;
            const distFromActive = Math.max(0, activeIdx - i);
            const zDepth = -distFromActive * 10;
            s.wrap.position.set(lerp(-85, 0, pIn), s.baseY - lerp(18, 0, pIn), zDepth);
            s.wrap.scale.setScalar(lerp(0.76, 1.0, pIn) * (1 - distFromActive * 0.035));
            const alpha = clamp(pIn * (1 - pExit) * (distFromActive >= 2 ? 0.52 : 1.0), 0, 1);
            s.fMat.opacity = alpha;
            s.sh.material.opacity = 0.26 * alpha;
          });

          // 3D Sculpted Faceted Lime Cursor tracking smoothly beside the active card!
          const cursorPts = [
            [5.54, 76],
            [6.26, 36.5],
            [7.32, -3],
            [8.06, -42.5],
            [8.84, -82],
          ];
          let cy = cursorPts[0][1];
          for (let i = 0; i < cursorPts.length - 1; i++) {
            if (t >= cursorPts[i][0]) {
              const pSeg = easeInOutCubic(seg(t, cursorPts[i][0] + 0.15, cursorPts[i + 1][0] + 0.05));
              cy = lerp(cursorPts[i][1], cursorPts[i + 1][1], pSeg);
            }
          }
          const cIn = easeOutCubic(seg(t, 5.50, 5.82));
          a3Cursor.visible = t >= 5.48 && pExit < 0.95;
          a3Cursor.position.set(lerp(95, 76, cIn), cy + 5, 14);
          a3Cursor.scale.setScalar(1.35 * cIn * (1 - pExit));
          a3Cursor.rotation.set(-0.1, 0.25, 0.45);
        }

        if (showOrbit) {
          const pIn = easeOutBack(seg(t, 9.40, 9.92), 1.45);
          const pOrb = seg(t, 9.40, 10.60);
          const pPlunge = easeInCubic(seg(t, 10.50, 10.92));

          a3OrbitGroup.position.set(0, 12, pPlunge * 360);
          a3OrbitGroup.scale.setScalar(lerp(0.55, 1.0, easeOutCubic(seg(t, 9.40, 9.86))) * (1 + pPlunge * 2.4));

          // Center Official 3D App Icon as the glowing hub!
          a3HubIcon.scale.setScalar(0.50 * Math.max(0.01, pIn));
          a3HubIcon.rotation.set(
            lerp(-0.22, 0.0, easeOutCubic(seg(t, 9.40, 10.05))),
            lerp(0.55, 0.0, easeOutCubic(seg(t, 9.40, 10.05))) + Math.sin(pOrb * Math.PI * 2) * 0.08,
            0
          );

          orbitRingMesh.scale.setScalar(lerp(0.5, 1.0, easeOutCubic(seg(t, 9.42, 9.95))));
          orbitInnerRing.scale.setScalar(lerp(0.5, 1.0, easeOutCubic(seg(t, 9.44, 9.98))));
          orbitInnerRing.rotation.z = pOrb * 0.9;

          // 5 3D frosted ceramic icon tiles orbiting gracefully in 3D space!
          const rotAngle = lerp(-0.55, 0.48, easeInOutCubic(pOrb));
          a3OrbitTiles.forEach((ot, i) => {
            const pTile = easeOutBack(seg(t, 9.42 + i * 0.04, 9.90 + i * 0.04), 1.4);
            const ang = ot.angle0 + rotAngle;
            const r = lerp(34, 66, pTile);
            ot.group.position.set(Math.cos(ang) * r, Math.sin(ang) * r, Math.sin(ang * 2) * 8);
            ot.group.scale.setScalar(Math.max(0.001, pTile));
            ot.group.rotation.y = -Math.cos(ang) * 0.18;
            ot.group.rotation.x = Math.sin(ang) * 0.12;
          });
        }
      }

      /* ---------------- ACT 4: BRIGHT, CLOSE-UP 3D REAL-UI GLASS LAMINATES (10.75 - 17.60s) ---------------- */
      if (t >= 10.75 && t < 17.60) {
        act4Group.visible = true;

        // Beat 4A: Real # Café Aurora Channel Slab (10.75 - 15.15s, recedes blurred-left when Portal enters!)
        const show4A = t >= 10.76 && t < 15.15;
        a4ChatSlab.group.visible = show4A;
        if (show4A) {
          const pIn = easeOutCubic(seg(t, 10.78, 11.35));
          const pOrbit = seg(t, 11.35, 13.40);
          const pRecede = easeInOutCubic(seg(t, 13.38, 14.02));
          const pOut = easeInCubic(seg(t, 14.88, 15.14));

          a4ChatSlab.group.position.set(
            lerp(0, -68, pRecede) - pOut * 130,
            lerp(-35, 0, pIn) + lerp(0, 22, pRecede),
            lerp(-95, 22, pIn) + lerp(0, -90, pRecede)
          );
          a4ChatSlab.group.scale.setScalar(lerp(0.84, 1.0, pIn) * lerp(1.0, 0.80, pRecede) * (1 - pOut * 0.25));
          a4ChatSlab.group.rotation.set(
            lerp(0.16, 0.05, pIn),
            lerp(0.24, 0.08, pIn) + lerp(0.0, -0.12, pOrbit) + lerp(0, 0.16, pRecede),
            lerp(-0.04, -0.02, pIn)
          );
          a4ChatSlab.sheenTex.offset.x = lerp(-0.75, 0.85, seg(t, 11.05, 13.20));

          // Dim slightly when receding behind Approval Portal so foreground Portal commands focus
          a4ChatSlab.frontMat.emissiveIntensity = lerp(0.78, 0.22, pRecede);

          // 4 Real Cropped Message Layers cleanly spaced with ZERO overlap between header & input bar!
          const mSpecs = [
            { layer: chM1, tIn: 11.00, x: 0, y: chH * 0.5 - 266 * chScale, z: 9 },
            { layer: chM2, tIn: 11.58, x: 0, y: chH * 0.5 - 468 * chScale, z: 11 },
            { layer: chM3, tIn: 12.16, x: 48 * chScale, y: chH * 0.5 - 752 * chScale, z: 13 },
            { layer: chM4, tIn: 12.80, x: 0, y: chH * 0.5 - 1018 * chScale, z: 17 },
          ];
          mSpecs.forEach(ms => {
            const pM = easeOutBack(seg(t, ms.tIn, ms.tIn + 0.36), 1.35);
            ms.layer.group.visible = t >= ms.tIn - 0.02;
            ms.layer.group.position.set(ms.x, ms.y - lerp(12, 0, pM), lerp(2, ms.z, pM));
            ms.layer.group.scale.setScalar(lerp(0.88, 1.0, pM));
            ms.layer.frontMat.opacity = clamp(pM * (1 - pRecede * 0.35), 0, 1);
          });
        }

        // Beat 4B: Real Client Approval Portal Slab + Live 3D Floating Real Aprovar Button (13.38 - 15.20s)
        const show4B = t >= 13.38 && t < 15.20;
        a4PortalSlab.group.visible = show4B;
        if (show4B) {
          const pIn = easeOutCubic(seg(t, 13.40, 13.98));
          const pFloat = seg(t, 13.98, 14.92);
          const pOut = easeInCubic(seg(t, 14.92, 15.20));

          // Close-up framing inside Reels safe area: Portal spans ~78-82% of width, Aprovar cleanly inside safe bounds!
          a4PortalSlab.group.position.set(
            lerp(135, 4, pIn) - pOut * 180,
            lerp(-30, 8, pIn) + lerp(0, 10, pFloat),
            lerp(-40, 32, pIn) - pOut * 50
          );
          a4PortalSlab.group.scale.setScalar(lerp(0.86, 1.0, pIn) * (1 - pOut * 0.15));
          a4PortalSlab.group.rotation.set(
            lerp(0.14, 0.04, pIn),
            lerp(-0.38, -0.11, pIn) + lerp(0, 0.07, pFloat),
            lerp(0.05, -0.02, pIn)
          );
          a4PortalSlab.sheenTex.offset.x = lerp(-0.8, 0.9, seg(t, 13.55, 14.85));

          // Live 3D Cursor gliding in & pressing right side of real Aprovar button right at 14.20s (text 100% unobstructed!)
          const pCur = easeOutCubic(seg(t, 13.78, 14.18));
          a4Cursor.visible = t >= 13.76 && t < 14.96;
          a4Cursor.position.set(lerp(56, 26, pCur), btnCenterY + lerp(-32, 0, pCur), 26);
          a4Cursor.scale.setScalar(1.25 * smooth(seg(t, 13.76, 13.90)));
          a4Cursor.rotation.set(0.12, -0.15, 0.12);

          // Physical 3D Z-depression at 14.20s -> springs back & flips to "✓ Aprovado" at 14.28s!
          const pressDip = pulse(t, 14.16, 14.24, 14.38);
          a4ApproveBtn.group.position.set(0, btnCenterY, lerp(15, 5, pressDip));
          a4ApproveBtn.group.scale.setScalar(1 - pressDip * 0.06);

          const isApproved = t >= 14.26;
          if (a4ApproveBtn.frontMat.map !== (isApproved ? texApprovedState : texPortalBtn)) {
            a4ApproveBtn.frontMat.map = isApproved ? texApprovedState : texPortalBtn;
            a4ApproveBtn.frontMat.emissiveMap = a4ApproveBtn.frontMat.map;
            a4ApproveBtn.frontMat.needsUpdate = true;
          }

          // Expanding luminous 3D shockwave ring on tap
          const pRing = seg(t, 14.20, 14.78);
          a4TapRing.visible = pRing > 0 && pRing < 1;
          a4TapRing.scale.setScalar(lerp(0.5, 4.2, easeOutCubic(pRing)));
          a4TapRing.material.opacity = (1 - pRing) * 0.85;
        }

        // Beat 4C: 3D Glowing Workflow Rail (15.05 - 16.45s, dims softly behind Team slab)
        const show4C = t >= 15.05 && t < 16.60;
        a4RailGroup.visible = show4C;
        if (show4C) {
          const pIn = easeOutCubic(seg(t, 15.08, 15.38));
          const pSlide = seg(t, 15.08, 16.25);
          const pDim = easeInOutCubic(seg(t, 15.80, 16.25));
          // Beat 4C: Slide smoothly across all 4 glowing nodes keeping active nodes nicely framed
          a4RailGroup.position.set(lerp(82, -82, pSlide), 10, lerp(10, -110, pDim));
          a4RailGroup.scale.setScalar(lerp(0.82, 0.96, pIn) * lerp(1.0, 0.72, pDim));
          a4RailGroup.rotation.y = lerp(0.16, -0.14, pSlide);
        }

        // Beat 4D: Real "Seu time agora" Glass Slab + Floating Real Agent Parallax Layers (15.76 - 17.56s)
        const show4D = t >= 15.76 && t < 17.56;
        a4TeamSlab.group.visible = show4D;
        if (show4D) {
          const pIn = easeOutCubic(seg(t, 15.78, 16.32));
          const pHold = seg(t, 16.32, 17.32);

          a4TeamSlab.group.position.set(0, lerp(-90, -2, pIn) + lerp(0, 6, pHold), lerp(-70, 26, pIn));
          a4TeamSlab.group.scale.setScalar(lerp(0.84, 1.0, pIn) * lerp(1.0, 1.035, pHold));
          a4TeamSlab.group.rotation.set(lerp(0.20, 0.04, pIn) - pHold * 0.04, lerp(-0.14, 0.06, pHold), 0);
          a4TeamSlab.sheenTex.offset.x = lerp(-0.85, 0.85, seg(t, 16.00, 17.25));

          // Floating real "Doug coordena 11 agentes" card lifts forward
          const pDoug = easeOutBack(seg(t, 15.96, 16.36), 1.35);
          tmDougLayer.group.position.set(0, tmDougY, lerp(4, 14, pDoug));
          tmDougLayer.group.scale.setScalar(lerp(0.92, 1.015, pDoug));

          // 4 Real cropped agent rows glide forward in staggered Z-parallax!
          tmRows.forEach((r, idx) => {
            const pRow = easeOutCubic(seg(t, 16.06 + idx * 0.11, 16.44 + idx * 0.11));
            r.layer.group.position.set(lerp(-14, 0, pRow), r.cy, lerp(4, 11 + (idx % 2) * 3, pRow));
            r.layer.frontMat.opacity = pRow;
          });

          // Live rolling telemetry counter pill ("11 agentes · 4 ativos")
          const pCnt = easeOutCubic(seg(t, 15.95, 16.82));
          a4CounterPill.update(Math.round(lerp(2, 11, pCnt)), Math.round(lerp(1, 4, pCnt)));
          const pPillIn = easeOutBack(seg(t, 15.92, 16.32), 1.5);
          a4CounterPill.mesh.scale.setScalar(Math.max(0.01, pPillIn));
        }
      }

      /* ---------------- ACT 5: 3D GLASS CUBES + TRUE 3D TITANIUM SMARTPHONE (17.40 - 20.58s) ---------------- */
      if (t >= 17.40 && t < 20.58) {
        act5Group.visible = true;

        // Beat 5A: 5 Refractive 3D Crystal Glass Icon Cubes floating around "tudo isso"
        const show5A = t < 18.72;
        a5GlassCubesGroup.visible = show5A;
        if (show5A) {
          const pIn = easeOutCubic(seg(t, 17.46, 18.10));
          const pRush = easeInCubic(seg(t, 18.24, 18.68));
          a5Cubes.forEach((c, i) => {
            const dir = i % 2 === 0 ? 1 : -1;
            c.mesh.position.set(
              c.x * (1 + pRush * 0.7),
              c.y + lerp(-24, 14, pIn) + pRush * dir * 24,
              c.z + pRush * 180
            );
            c.mesh.scale.setScalar(c.s * lerp(0.4, 1.0, pIn) * (1 - pRush * 0.3));
            c.mesh.rotation.set(
              lerp(0.35 * dir, -0.15 * dir, pIn),
              lerp(-0.45 * dir, 0.25 * dir, pIn) + pRush * dir * 0.5,
              lerp(0.2 * dir, -0.1 * dir, pIn)
            );
          });
        }

        // Beat 5B: True 3D Modeled Titanium Smartphone Flyover (18.42 - 20.56s)
        const show5B = t >= 18.42 && t < 20.56;
        a5Phone.group.visible = show5B;
        if (show5B) {
          const pIn = easeOutCubic(seg(t, 18.44, 19.18));
          const pFly = seg(t, 19.18, 20.38);
          const pOut = easeInCubic(seg(t, 20.26, 20.55));

          a5Phone.group.position.set(
            lerp(65, -2, pIn) + lerp(0, 4, pFly),
            lerp(-42, 4, pIn) + lerp(0, 10, pFly) + pOut * 140,
            lerp(-70, 26, pIn) + lerp(0, 24, pFly)
          );
          a5Phone.group.scale.setScalar(lerp(0.80, 1.02, pIn) * lerp(1.0, 1.08, pFly));
          a5Phone.group.rotation.set(
            lerp(0.38, 0.16, pIn) + lerp(0, -0.07, pFly),
            lerp(-0.56, -0.24, pIn) + lerp(0, 0.14, pFly),
            lerp(0.20, 0.08, pIn) + lerp(0, -0.05, pFly)
          );

          // Real DougBot chat scrolls smoothly from # Café Aurora header down to MARK!
          texChannelFull.offset.y = lerp(0.18, 0.01, easeInOutCubic(seg(t, 18.55, 20.30)));
          a5Phone.glintTex.offset.x = lerp(-0.85, 0.95, seg(t, 18.65, 20.25));

          // Floating 3D beveled obsidian-glass headline bar pops off the phone screen
          const pBar = easeOutBack(seg(t, 18.72, 19.16), 1.35);
          a5Phone.barGroup.visible = t >= 18.70;
          a5Phone.barGroup.position.set(0, -56 - lerp(14, 0, pBar), lerp(10, 24, pBar));
          a5Phone.barGroup.scale.setScalar(Math.max(0.01, lerp(0.75, 1.0, pBar)));
        }
      }

      /* ---------------- ACT 6: OFFICIAL 3D ICON + 3D SPHERES + 3D MORPHING MEDALLION (20.40 - 24.65s) ---------------- */
      if (t >= 20.40 && t < 24.65) {
        act6Group.visible = true;

        // Beat 6A: Official 3D Icon beside "DougBot" wordmark (20.44 - 21.66s)
        const show6A = t >= 20.44 && t < 21.66;
        a6InlineIcon.visible = show6A;
        if (show6A) {
          const pIn = easeOutBack(seg(t, 20.46, 20.88), 1.45);
          const pOut = easeInCubic(seg(t, 21.40, 21.66));
          // Positioned cleanly to the left of the "DougBot" HTML wordmark (screen x~296, y~942)
          const pos = screenToWorld(296, 940);
          a6InlineIcon.position.set(pos.x, pos.y - lerp(12, 0, pIn), lerp(-40, 0, pIn));
          a6InlineIcon.scale.setScalar(0.245 * Math.max(0.001, pIn) * (1 - pOut));
          a6InlineIcon.rotation.set(lerp(0.3, -0.04, pIn), lerp(-0.65, 0.12, pIn), 0);
        }

        // Beat 6B: 4 Sculpted 3D Glossy Spheres lighting sequentially (21.56 - 22.88s)
        const show6B = t >= 21.56 && t < 22.88;
        a6DotsGroup.visible = show6B;
        if (show6B) {
          const pConv = easeInCubic(seg(t, 22.60, 22.86));
          const pBeam = easeInOutCubic(seg(t, 21.64, 22.58));
          dotBeamBg.scale.set(1, 1 - pConv, 1);
          dotBeamFill.scale.set(1, Math.max(0.001, pBeam * (1 - pConv)), 1);
          dotBeamFill.position.x = -57 * (1 - pBeam) * (1 - pConv);

          a6Spheres.forEach((sp, i) => {
            const pIn = easeOutBack(seg(t, 21.58 + i * 0.24, 21.90 + i * 0.24), 1.65);
            const pLit = smooth(seg(t, 21.66 + i * 0.24, 21.94 + i * 0.24));
            sp.group.position.set(lerp(sp.x, 0, pConv), 12, 0);
            sp.group.scale.setScalar(Math.max(0.001, pIn) * lerp(1.0, 0.35, pConv));
            // Transition smoothly from glossy pitch-black #09090A to rich vibrant #9CFA05 enamel (zero pastel wash!)
            sp.mat.color.setRGB(
              lerp(0.02, 0.42, pLit),
              lerp(0.02, 0.92, pLit),
              lerp(0.025, 0.01, pLit)
            );
            sp.mat.emissive.setRGB(0.32 * pLit, 0.78 * pLit, 0.005 * pLit);
            sp.mat.emissiveIntensity = 0.36 * pLit;
          });
        }

        // Beat 6C: Sculpted 3D Glossy #9CFA05 Morphing Medallion (22.74 - 24.64s)
        const show6C = t >= 22.74 && t < 24.64;
        a6Medallion.group.visible = show6C;
        if (show6C) {
          const pIn = easeOutBack(seg(t, 22.76, 23.18), 1.45);
          const pOut = easeInCubic(seg(t, 24.36, 24.63));
          const punch1 = pulse(t, 23.22, 23.32, 23.48);
          const punch2 = pulse(t, 23.76, 23.86, 24.08);

          a6Medallion.group.position.set(0, 14, lerp(-60, 0, easeOutCubic(seg(t, 22.76, 23.14))));
          const sc = Math.max(0.001, pIn) * (1 + punch1 * 0.07 + punch2 * 0.09) * (1 - pOut * 0.85);
          a6Medallion.group.scale.setScalar(sc);
          // Authoritative 3D medallion spring turn on each symbol morph!
          a6Medallion.group.rotation.set(
            lerp(0.24, -0.03, pIn) + Math.sin((t - 22.76) * 2.2) * 0.03,
            lerp(-0.55, 0.0, pIn) + punch1 * 0.34 - punch2 * 0.38,
            0
          );
          a6Medallion.orbitArc.rotation.z = (t - 22.76) * 1.4;

          // Symbol morph choreography: Nodes (22.74-23.26) -> Bolt (23.26-23.78) -> Checkmark (23.78-24.64)
          const pNodes = 1 - easeInCubic(seg(t, 23.18, 23.30));
          const pBoltIn = easeOutBack(seg(t, 23.26, 23.46), 1.6);
          const pBoltOut = easeInCubic(seg(t, 23.70, 23.82));
          const pBolt = pBoltIn * (1 - pBoltOut);
          const pCheck = easeOutBack(seg(t, 23.78, 24.04), 1.85);

          a6Medallion.symNodes.visible = pNodes > 0.01;
          a6Medallion.symNodes.scale.setScalar(Math.max(0.001, pNodes));
          a6Medallion.symNodes.rotation.z = (1 - pNodes) * 0.8;

          a6Medallion.symBolt.visible = t >= 23.24 && pBolt > 0.01;
          a6Medallion.symBolt.scale.setScalar(Math.max(0.001, pBolt));
          a6Medallion.symBolt.rotation.z = lerp(-0.6, 0, pBoltIn) + pBoltOut * 0.6;

          a6Medallion.symCheck.visible = t >= 23.76;
          a6Medallion.symCheck.scale.setScalar(Math.max(0.001, pCheck));
          a6Medallion.symCheck.rotation.z = lerp(-0.45, 0, easeOutCubic(seg(t, 23.78, 24.02)));

          // Expanding luminous 3D shockwave ring on Checkmark ding (23.80s)
          const pSh = seg(t, 23.78, 24.36);
          a6Medallion.shockRing.visible = pSh > 0 && pSh < 1;
          a6Medallion.shockRing.scale.setScalar(lerp(0.95, 1.85, easeOutCubic(pSh)));
          a6Medallion.shockMat.opacity = (1 - pSh) * 0.85;
        }
      }

      /* ---------------- ACT 7: BALANCED SCULPTED 3D CLOSING LOCKUP (24.45 - 30.00s) ---------------- */
      if (t >= 24.45) {
        act7Group.visible = true;

        // Phase 7A -> 7B: Sculpted 3D Ceramic/Glass URL Capsule ("dougbot.app")
        const pCapIn = easeOutBack(seg(t, 24.50, 24.96), 1.3);
        const pCapGlide = easeInOutCubic(seg(t, 26.12, 26.86));
        const charFloat = seg(t, 24.94, 26.18) * 11; // "dougbot.app" = 11 chars
        const charCount = clamp(Math.floor(charFloat + 0.001), 0, 11);
        const showCaret = t >= 24.80 && t < 26.42;
        a7Capsule.updateText(charCount, showCaret);

        // Starts centered (y = 0 -> screen y=960), glides smoothly down to screen y=1175 (world y = -41)
        a7Capsule.group.position.set(0, lerp(0, -41, pCapGlide), lerp(-50, 0, easeOutCubic(seg(t, 24.50, 24.92))));
        a7Capsule.group.scale.setScalar(Math.max(0.01, pCapIn));
        a7Capsule.group.rotation.set(
          lerp(0.22, -0.02, easeOutCubic(seg(t, 24.50, 25.00))),
          lerp(-0.18, 0.0, easeOutCubic(seg(t, 24.50, 25.10))) + Math.sin((t - 24.5) * 1.1) * 0.018,
          0
        );

        // Phase 7B: BALANCED Medium-Hero Official 3D App Icon centered cleanly above "DougBot" wordmark!
        const showHero = t >= 26.08;
        a7HeroIcon.visible = showHero;
        if (showHero) {
          const pIn = easeOutQuint(seg(t, 26.10, 26.94));
          const breath = 1 - smooth(seg(t, 28.4, 29.8));
          // Screen y ~ 725px => world y = +45; medium-hero scale 0.64 (~335x335px — NOT oversized!)
          a7HeroIcon.position.set(
            0,
            lerp(72, 45, pIn) + Math.sin((t - 26.1) * 1.7) * 1.8 * breath,
            lerp(-70, 0, pIn)
          );
          a7HeroIcon.scale.setScalar(0.64 * lerp(0.32, 1.0, pIn));
          a7HeroIcon.rotation.set(
            lerp(0.22, -0.03, pIn) + Math.cos((t - 26.1) * 1.2) * 0.02 * breath,
            lerp(-0.52, 0.0, pIn) + Math.sin((t - 26.1) * 1.3) * 0.045 * breath,
            0
          );

          // Final tasteful diagonal specular shimmer sweep (26.82 - 27.88s)
          const sw = seg(t, 26.82, 27.88);
          sweepLight.color.setHex(0xe4ff9a);
          sweepLight.intensity = Math.sin(sw * Math.PI) * 2.6;
          sweepLight.position.set(lerp(-155, 155, sw), 125, 95);
        }
      }

      // Render through full Cinema GLSL Post-Processing Pipeline!
      post.render(scene, camera, {
        mode,
        bloomStrength,
        motionBlur,
        vignette,
        grain: mode === 1 ? 0.018 : 0.013,
        frame: Math.floor(t * 30),
      });
    }

    draw(0);
    return {
      draw,
      dispose() {
        post.dispose();
        envLight.dispose();
        envDark.dispose();
        renderer.dispose();
      },
    };
  };

  /* ============================================================================
   * 2. FOREGROUND DOF 3D GLOSSY OBSIDIAN TILTED DOUG HEADS (window.DougBotFg3D)
   * Pure jet-black piano obsidian (#050506) in the official -18° tilted pose,
   * bright studio softbox speculars + razor-thin #9CFA05 back-edge rim (ZERO OLIVE!).
   * Active ONLY as soft foreground corner bokeh in Act 1A & Act 6B/6C.
   * ============================================================================ */
  window.DougBotFg3D = function (canvas) {
    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      preserveDrawingBuffer: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(WIDTH, HEIGHT, false);
    renderer.setPixelRatio(1);
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(34, WIDTH / HEIGHT, 1, 2400);
    camera.position.set(0, 0, 520);

    // Pure neutral-white & obsidian softbox env map (ZERO green wash so FG heads stay jet black!)
    const envCanvas = document.createElement('canvas');
    envCanvas.width = 512;
    envCanvas.height = 256;
    const ectx = envCanvas.getContext('2d');
    ectx.fillStyle = '#050506';
    ectx.fillRect(0, 0, 512, 256);
    const topS = ectx.createLinearGradient(0, 8, 0, 74);
    topS.addColorStop(0, 'rgba(255,255,255,0.98)');
    topS.addColorStop(1, 'rgba(255,255,255,0)');
    ectx.fillStyle = topS;
    ectx.fillRect(70, 8, 372, 66);
    const lS = ectx.createLinearGradient(20, 0, 95, 0);
    lS.addColorStop(0, 'rgba(255,255,255,0)');
    lS.addColorStop(0.5, 'rgba(255,255,255,0.75)');
    lS.addColorStop(1, 'rgba(255,255,255,0)');
    ectx.fillStyle = lS;
    ectx.fillRect(20, 40, 75, 160);
    const eTex = new THREE.CanvasTexture(envCanvas);
    eTex.mapping = THREE.EquirectangularReflectionMapping;
    eTex.encoding = THREE.sRGBEncoding;
    const pmrem = new THREE.PMREMGenerator(renderer);
    pmrem.compileEquirectangularShader();
    const envRT = pmrem.fromEquirectangular(eTex);
    eTex.dispose();
    pmrem.dispose();
    scene.environment = envRT.texture;

    const dougA = createStandaloneTiltedDougHead();
    const dougB = createStandaloneTiltedDougHead();
    scene.add(dougA, dougB);

    scene.add(new THREE.AmbientLight(0xffffff, 0.16));
    const key = new THREE.DirectionalLight(0xffffff, 2.2);
    key.position.set(-90, 170, 140);
    scene.add(key);

    // Sharp pure back-rim grazing highlight (back Z = -140 so front face stays 100% pure obsidian black!)
    const rimBack = new THREE.DirectionalLight(0x9cfa05, 1.35);
    rimBack.position.set(140, -60, -140);
    scene.add(rimBack);

    function draw(t) {
      let showA = false;
      let showB = false;

      if (t >= 0.0 && t <= 1.88) {
        const p = seg(t, 0.06, 1.84);
        const pFade = 1 - smooth(seg(t, 1.62, 1.86));
        showA = pFade > 0.01;
        showB = pFade > 0.01;

        dougA.position.set(lerp(132, 62, easeInOutCubic(p)), lerp(-144, -92, easeOutCubic(p)), 72);
        dougA.scale.setScalar(lerp(1.38, 1.82, p) * lerp(0.85, 1.0, pFade));
        dougA.rotation.set(lerp(0.20, -0.10, p), lerp(-0.58, -0.22, p), lerp(0.10, -0.06, p));

        dougB.position.set(lerp(-136, -86, easeOutCubic(p)), lerp(128, 86, easeInOutCubic(p)), 44);
        dougB.scale.setScalar(lerp(1.10, 1.42, p) * lerp(0.85, 1.0, pFade));
        dougB.rotation.set(lerp(-0.14, 0.12, p), lerp(0.55, 0.24, p), lerp(-0.12, 0.06, p));
      } else if (t >= 21.56 && t <= 24.55) {
        const pIn = easeOutCubic(seg(t, 21.58, 22.36));
        const pDrift = seg(t, 21.58, 24.52);
        const pOut = easeInOutCubic(seg(t, 24.22, 24.54));
        showA = true;
        showB = true;

        dougA.position.set(
          lerp(-156, -86, pIn) - pOut * 48,
          lerp(158, 114, pIn) + Math.sin(pDrift * Math.PI) * 10 + pOut * 55,
          55
        );
        dougA.scale.setScalar(lerp(1.26, 1.48, pDrift));
        dougA.rotation.set(0.16, lerp(0.52, 0.26, pDrift), lerp(-0.12, -0.05, pDrift));

        dougB.position.set(
          lerp(156, 88, pIn) + pOut * 48,
          lerp(-166, -118, pIn) - Math.sin(pDrift * Math.PI) * 10 - pOut * 55,
          62
        );
        dougB.scale.setScalar(lerp(1.42, 1.66, pDrift));
        dougB.rotation.set(-0.14, lerp(-0.52, -0.24, pDrift), lerp(0.10, 0.04, pDrift));
      }

      dougA.visible = showA;
      dougB.visible = showB;
      renderer.render(scene, camera);
    }

    draw(0);
    return {
      draw,
      dispose() {
        envRT.texture.dispose();
        renderer.dispose();
      },
    };
  };

  /* ============================================================================
   * 3. TOP-MOST UNIFIED CINEMA LENS FINISH (window.DougBotFilmFinish)
   * Renders ultra-fine deterministic cinema film grain + subtle optical light dust
   * across the entire 1080x1920 frame ABOVE kinetic typography so text & 3D share
   * the exact same rendered cinema lens atmosphere.
   * ============================================================================ */
  window.DougBotFilmFinish = function (canvas) {
    const ctx = canvas.getContext('2d');
    // Pre-generate 6 deterministic fine-grain tile patterns for lightning-fast 30fps draw
    const tiles = [];
    for (let k = 0; k < 6; k++) {
      const tc = document.createElement('canvas');
      tc.width = 256;
      tc.height = 256;
      const tctx = tc.getContext('2d');
      const img = tctx.createImageData(256, 256);
      const d = img.data;
      let seed = 1337 + k * 7919;
      for (let i = 0; i < d.length; i += 4) {
        seed = (seed * 1664525 + 1013904223) >>> 0;
        const v = (seed >>> 24) & 255;
        d[i] = v;
        d[i + 1] = v;
        d[i + 2] = v;
        d[i + 3] = 9; // ultra-subtle organic cinema grain
      }
      tctx.putImageData(img, 0, 0);
      tiles.push(ctx.createPattern(tc, 'repeat'));
    }

    // Subtle floating studio bokeh dust motes (deterministic orbits)
    const motes = [];
    for (let i = 0; i < 18; i++) {
      const a = i * 2.39996;
      motes.push({
        x0: ((i * 197 + 83) % 980) + 50,
        y0: ((i * 313 + 120) % 1680) + 120,
        r: 2.2 + (i % 4) * 1.4,
        vx: Math.cos(a) * 14,
        vy: -12 - (i % 5) * 4,
        ph: i * 1.1,
      });
    }

    function draw(t) {
      ctx.clearRect(0, 0, WIDTH, HEIGHT);
      const frame = Math.floor(t * 30);

      // Deterministic fine grain pass
      ctx.save();
      ctx.globalCompositeOperation = 'overlay';
      ctx.fillStyle = tiles[frame % tiles.length];
      ctx.fillRect(0, 0, WIDTH, HEIGHT);
      ctx.restore();

      // Subtle floating volumetric studio dust motes (brighter in dark studio, airy in light/green)
      const isDark = t >= 10.8 && t < 17.5;
      ctx.save();
      for (let i = 0; i < motes.length; i++) {
        const m = motes[i];
        const x = ((m.x0 + m.vx * t) % WIDTH + WIDTH) % WIDTH;
        const y = ((m.y0 + m.vy * t) % HEIGHT + HEIGHT) % HEIGHT;
        const tw = 0.45 + 0.55 * Math.sin(t * 2.4 + m.ph);
        const rad = ctx.createRadialGradient(x, y, 0, x, y, m.r * 3.4);
        if (isDark) {
          rad.addColorStop(0, 'rgba(182, 255, 64, ' + (0.26 * tw).toFixed(3) + ')');
          rad.addColorStop(1, 'rgba(156, 250, 5, 0)');
        } else {
          rad.addColorStop(0, 'rgba(255, 255, 255, ' + (0.34 * tw).toFixed(3) + ')');
          rad.addColorStop(1, 'rgba(255, 255, 255, 0)');
        }
        ctx.fillStyle = rad;
        ctx.beginPath();
        ctx.arc(x, y, m.r * 3.4, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    draw(0);
    return { draw };
  };
})();
