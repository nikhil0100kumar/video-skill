# Briefing: DougBot 9:16, refeito do zero, nível premium

Você está em `<projeto>/openmotion`, o clone de https://github.com/nexu-io/openmotion, já
instalado (`npm ci` e `npm run build:studio` feitos). O workspace do OpenMotion é
`<projeto>/openmotion-workspace` (use o mesmo `MOTION_DATA_DIR`).

O vídeo TEM de ser feito com o OpenMotion deste clone, pelo fluxo nativo dele (MCP/HyperFrames, `Motion.md`, as skills
`openmotion`, `openmotion-director`, `openmotion-production`, `openmotion-media`, export nativo + `verifyExport`).
Nada de Remotion, Blender ou ffmpeg montando o filme por fora.

## Do zero
Crie um projeto NOVO. Não copie o projeto anterior (`86b93b04-…`, horizontal de 15 s); pode lê-lo só para
aprender o que já funcionou (o Three.js da cabeça, o material preto glossy, a voz), mas a direção, o roteiro, os
planos e a composição são novos. A meta é ficar dez vezes mais premium que aquele: nível de filme de lançamento de
produto da Apple, Linear, Arc ou Vercel.

## REFERÊNCIA (o mais importante deste briefing)
O vídeo de referência está em `<projeto>/ref/ref.mp4` (reel vertical 1440x2560,
29 s, do sistema hoteleiro "uOS"). Quadros a 2 fps em `<projeto>/ref/frames/` e a
transcrição com tempos em `ref/stt.json`. Assista aos quadros TODOS antes de planejar. Recrie a LINGUAGEM dele para
o DougBot (estrutura, ritmo, estética, tipos de movimento), não o conteúdo nem a marca dele: nada do uOS, laranja,
hotel ou sininho. A cor de destaque nossa é o verde #9CFA05 com preto #0A0A0A.

O que a referência faz, ato por ato:
1. 0–3 s, abertura clara: fundo cinza-claro quase branco com vinheta suave e anéis finos concêntricos. Texto
   pequeno e elegante entrando palavra a palavra ("gerenciar um… hotel… não precisa ser complicado"), a palavra-chave
   na cor da marca, e um rabisco feito à mão (traço de pincel/caneta) se desenhando por baixo. Objetos 3D realistas da
   marca (um sininho de recepção, um prédio de hotel em 3D) passam desfocados em primeiro plano nas bordas do quadro.
   Ícones de "X" e "+" grandes e vidrados entram e saem desfocados.
2. 3–4 s, logo: a logo aparece no centro com um brilho que varre, sobre formas de puzzle quase invisíveis.
3. 4–10 s, módulos: cartões brancos tipo vidro fosco, cantos bem arredondados, sombra suave, ícone de traço fino
   na cor da marca + uma palavra ("reservas", "recepção", "financeiro", "compras", "operação"), entram um por um no
   ritmo da fala, empilhados em diagonal, a câmera inclina e sobe por eles com profundidade de campo; um cursor
   triangular na cor da marca acompanha. Depois os ícones se soltam e orbitam a logo, que fica num quadrado 3D
   brilhante no centro, ligados por um anel fino.
4. 10–17 s, ato escuro: corte para fundo preto com brilho quente nas bordas. Cartões de UI de verdade (uma tabela
   "Mais controle", um cartão grande "35% oportunidades de economia" na cor da marca) inclinados em 3D, girando,
   com reflexo que corre na superfície; linha do tempo com passos numerados (1 Necessidade, 2 Cotação, 3 Decisão…)
   passando como trilho; cartão de vidro escuro com números (R$ 720 mil, 46,4%) contando.
5. 17–20 s, ato colorido: fundo cheio na cor da marca, ícones vidrados flutuando em profundidade, "tudo isso"
   escrito com um círculo feito à mão em volta, depois um tablet/tela do produto inclinado em 3D, a câmera passando
   bem perto da interface (frase de destaque grande dentro da tela).
6. 20–24 s, prova: volta ao claro; logo com rabisco embaixo; pontos ligados por linha se acendendo (progresso);
   botões 3D redondos e brilhantes na cor da marca (engrenagem → relógio → check) se transformando um no outro.
7. 24–29 s, fechamento: pílula com o endereço do site digitando, logo final centralizada acima dela, brilho final.

Princípios a copiar: três ambientes de luz (claro → escuro → cor da marca → claro), muito espaço vazio,
tipografia pequena e fina com uma palavra destacada por vez, rabiscos à mão como acento, materiais 3D vidrados e
brilhantes, tudo em leve perspectiva e sempre se mexendo, desfoque forte de primeiro plano, transições por
movimento (whip, zoom through, um objeto que atravessa o quadro), música animada com cortes na batida.

Como traduzir para o DougBot:
- Abertura clara com o texto "Seu time… não precisa trabalhar sozinho" (ou similar), rabisco verde por baixo,
  a cabeça 3D do Doug e ícones vidrados passando desfocados nas bordas.
- Logo do Doug em 3D com brilho que varre.
- Módulos em cartões de vidro com ícone verde de traço fino: "chat", "agentes", "tarefas", "aprovações",
  "drive", "rotinas", depois orbitando a cabeça do Doug.
- Ato escuro com a UI real do DougBot (prints em `assets/ui/`): mensagens do canal, cartão de aprovação com o
  botão verde "Aprovar", "Seu time agora" com os agentes, Início com "Esperando você", contadores subindo.
- Ato verde (#9CFA05 cheio, texto preto) com "tudo isso" circulado à mão e o celular com o DougBot inclinado em 3D.
- Fechamento: pílula "dougbot.app" digitando e a logo final.

## Formato
- Vertical 9:16, 1080x1920, 30 fps (60 se o render aguentar), MP4 H.264 + AAC.
- 30 segundos (±0,2 s), a mesma duração da referência: siga os tempos dos atos dela quase um para um.
- Pense no celular: elementos grandes, texto legível na tela pequena, nada importante nas faixas de 220 px de
  cima e de baixo (área segura de Reels/TikTok).

## O que mostrar: a interface de verdade
As telas reais do DougBot estão em `<projeto>/assets/ui/` (dados fictícios do
"Estúdio Farol", podem aparecer). Olhe cada uma antes de planejar:
- Celular (780x1688, perfeitas para 9:16): `pt-phone-channel.png` (canal com pessoas e agentes conversando),
  `pt-phone-doug.png` (conversa com o Doug, resumo do dia), `pt-phone-home.png` (Início: "Boa tarde, Ana",
  esperando você, trabalhando agora), `pt-phone-team.png` ("Seu time agora", 11 agentes),
  `pt-client-portal.png` (cliente aprova a peça com o botão verde "Aprovar").
- Web (1600x1000): `pt-channel.png`, `pt-doug.png`, `pt-home.png`, `pt-team.png`, `pt-portal.png`,
  `pt-portal-overview.png`, `pt-design-review.png`, `pt-video-review.png`, `pt-whatsapp.png`, `w-agente.png`.

Não ponha os prints como imagens chapadas paradas. Faça a interface viver:
- Recorte os elementos das telas (mensagens do chat, cartões de agente, o botão "Aprovar", a lista do time, os
  cartões do portal, avatares dos agentes) e anime cada um separado: mensagens entrando uma a uma como num chat de
  verdade, um agente "digitando", um cartão de aprovação aparecendo e o botão sendo tocado, a lista do time
  preenchendo, contadores subindo.
- Os elementos vêm dos prints reais (recortados em alta resolução, ampliados com cuidado), nunca redesenhados
  como caixas HTML/CSS (ver "NADA COM CARA DE HTML" no fim). A UI tem de ser reconhecível como o
  DougBot real; não invente telas de outro produto.
- Coloque as telas em 3D: o celular/a tela inclinados no espaço, camadas da interface separadas em profundidade
  (parallax), câmera 3D passando entre elas.

## Linguagem de câmera e montagem
- Cortes de cena: de 6 a 9 planos, cortes no ritmo da fala e da música, com transições premium (match cut, whip
  pan com motion blur, zoom through num elemento da UI, máscara pelo topete da logo). Sem cortes secos aleatórios.
- Câmera 3D com ângulos variados: plongée, contra-plongée, close extremo num botão, plano holandês leve, órbita,
  dolly, rack focus entre camadas.
- Profundidade de campo real em todos os planos: primeiro plano e fundo desfocados, foco puxado para o que importa.
- Motion blur nos movimentos rápidos, easing de filme (nada linear), micro-detalhes (reflexos que correm na tela,
  poeira de luz, brilho verde).
- Logo do Doug em 3D: abre ou fecha o filme (ou os dois). A marca é a cabeça do bot preta brilhante (#0A0A0A),
  topete que faz uma onda curvando no alto à esquerda, dois olhos brancos em pílula, sem boca, sobre/com luz verde
  #9CFA05. Vetores em `<projeto>/assets/` (`doug-mono.svg`, `doug-front.svg`,
  `icon.png` para conferir). Não mude o desenho: nada de boca, óculos ou sorriso.

## Lettering premium
- Tipografia cinética grande, 1 a 3 palavras por vez, sincronizada palavra a palavra com a narração (timestamps
  da ElevenLabs): entra com máscara, tracking que fecha, peso que muda, desfoque que some, destaque verde
  #9CFA05 na palavra-chave.
- Uma família sans moderna e de qualidade (Inter Display, Geist ou similar com licença livre), hierarquia clara,
  espaçamento óptico cuidado. O nome escrito é sempre "DougBot"; não crie logotipo novo.

## Narração: ElevenLabs Eleven v4, pronúncia "Dougui"
- Modelo `eleven_v4`, chave em `ELEVENLABS_API_KEY` (nunca imprima nem grave em arquivo).
- Português do Brasil. Pode manter a voz "Adam Borges" (`ZqE9vIHPcrC35dZv0Svu`) ou escolher outra melhor.
- PRONÚNCIA: o nome se fala "Dougui", "DouguiBot". Escreva no TEXTO enviado à API "DouguiBot" (e "Dougui" quando
  for só o Doug), mantendo "DougBot" na tela. Depois de gerar, confira a pronúncia transcrevendo o áudio com a
  própria ElevenLabs (`POST https://api.elevenlabs.io/v1/speech-to-text`, `model_id: "scribe_v1"`): o nome tem de
  sair como "Dougui"/"DouguiBot", nunca "Dog", "Dug" ou "Doug" em inglês. Se sair errado, ajuste a grafia
  ("Dúgui Bót", "Dôgui Bot") e gere de novo até acertar.
- Roteiro sugerido, na estrutura e no ritmo da referência (~26 s falados, com respiros; ajuste à montagem):
  "Fazer o trabalho do seu time não precisa ser complicado. Com o DouguiBot, você conecta chat, agentes de IA,
  tarefas, aprovações e rotinas em um único lugar. Seus agentes pegam o trabalho, entregam, e pedem sua aprovação
  antes de agir. Vários, em paralelo. Tudo isso no mesmo chat que o seu time já usa. DouguiBot: seu time
  conectado, seu trabalho resolvido. Acesse dougbot ponto app."
  Os tempos de cada frase devem cair nos atos da referência (abertura, logo, módulos, ato escuro, ato verde,
  prova, fechamento).
- Já existem testes de voz de uma rodada anterior em `out/audio-9x16/` (incluindo transcrições de pronúncia
  `*-stt.json`): leia-os para não repetir tentativas que já falharam ou para reaproveitar a grafia que acertou.
- TRILHA E SFX: NÃO use as músicas nem os efeitos que vêm no repositório do OpenMotion ou nos modelos dele (o
  dono achou fracos). Gere tudo pelo MCP `elevenlabs` que está ligado a você:
  - Trilha: `create_composition_plan` e depois `compose_music`, 30 s exatos, instrumental, música de lançamento de
    produto tech moderna e animada (pulso eletrônico limpo, baixo marcante, percussão crocante, sintetizadores
    brilhantes), com as mudanças de seção caindo nos cortes de ato (claro → escuro mais grave e tenso → verde
    eufórico → resolução final). Pode usar `video_to_music` sobre um render de rascunho para casar com a imagem.
    Gere 2 ou 3 opções e escolha a melhor ouvindo a estrutura (picos de energia com `ffmpeg` ebur128/astats).
  - SFX: `text_to_sound_effects` para cada evento: whoosh dos whip pans, swoosh de cartão entrando, pop suave de
    mensagem chegando, clique do botão "Aprovar", tique de UI nos ícones, riser antes do ato escuro, impacto grave
    no corte para o escuro, brilho/shimmer da logo, digitação da pílula "dougbot.app", "ding" do check final.
    Prompts específicos e premium (ex.: "soft glassy UI pop, short, clean, modern app", "airy cinematic whoosh
    with subtle sub bass"), durações curtas e certeiras.
  - Os arquivos saem em `out/elevenlabs/`; importe-os no projeto pelo OpenMotion (`openmotion_import_assets`) e
    mixe por lá: voz sempre clara (trilha ~-18 dB sob a voz, com ducking), SFX discretos, final em ~-14 LUFS sem
    clipping.

## Entrega
- MP4 final em `<projeto>/out/dougbot-9x16.mp4`.
- `ffprobe`: 1080x1920, 30 s, vídeo e áudio.
- Extraia um quadro a cada 1 s para `<projeto>/out/frames-9x16/` e olhe TODOS:
  UI nítida e reconhecível, texto legível e dentro da área segura, logo fiel, nada cortado, nenhum quadro vazio ou
  preto fora do início/fim, nada sobreposto feio. Corrija e renderize de novo até estar perfeito; faça pelo menos
  duas rodadas de revisão crítica, como um diretor de arte exigente.
- Escreva `<projeto>/out/REPORT-9x16.md`: projeto e caminhos, lista de planos com
  tempos, voz, texto final da narração, resultado da transcrição de pronúncia e limitações.

## CORREÇÃO OBRIGATÓRIA (rodada 2): logo oficial e problemas da 1ª passagem
Continue no projeto que você já criou (`8e3970ae-f846-4ba3-bd3f-3867b8589061`): mantenha a estrutura, a narração e
o áudio da ElevenLabs que já estão bons, e corrija o que segue antes de renderizar.

1. LOGO OFICIAL. A logo oficial do DougBot é o ícone do app como ele aparece no celular:
   `assets/LOGO-OFICIAL-referencia.jpg` (print do celular do dono) e o mesmo desenho em vetor
   `assets/doug-official-icon.svg` / `doug-official-icon.png` (camadas: `doug-official-back.svg` = o fundo verde,
   `doug-official-front.svg` = a cabeça, `doug-official-mono.svg` = silhueta). É um quadrado de cantos bem
   arredondados (squircle) VERDE (#9CFA05 com degradê mais claro, #E2FF98/#CEFF63, no alto à esquerda), com a cabeça
   preta brilhante (#09090A) GRANDE, inclinada, ESPIANDO do canto inferior direito: o topete em onda no alto, os
   dois olhos brancos em pílula inclinados embaixo, a cabeça cortada pela borda do quadrado.
   - Todo momento de logo (a revelação da logo, a logo com os módulos em órbita, a logo do fechamento acima da
     pílula "dougbot.app") usa ESSE ícone, em 3D: a placa verde como um ícone de app de vidro espesso com
     reflexo e borda brilhante, e a cabeça preta extrudada saindo dela, recortada pela placa. Respeite a
     composição exata: mesma inclinação, mesmo corte, mesma posição dos olhos.
   - A cabeça de frente, centralizada, sozinha (a que você usou) NÃO é a logo. Os arquivos dela foram movidos para
     `assets/_NAO-USAR-pose-de-frente/`; não use. A cabeça 3D só aparece fora da placa como objeto desfocado
     passando no primeiro plano, e mesmo assim na pose inclinada.
   - Confira lado a lado: um quadro da logo do vídeo ao lado de `LOGO-OFICIAL-referencia.jpg` tem de ser
     reconhecidamente o mesmo ícone.
2. Cores: verde #9CFA05 e preto #09090A/#0A0A0A em todo lugar; nada de verde-oliva nem verde lavado.
3. Aos ~5 s o texto "DougBot" fica escondido atrás da logo: nunca sobreponha texto e logo.
4. Cartões de módulo: "agentes de IA" quebra em duas linhas; os cartões precisam caber a palavra numa linha só.
5. Ato escuro (11–18 s): está escuro demais e pequeno. As telas da UI têm de ocupar boa parte da largura, mais
   claras (luz de recorte, brilho na tela), e o texto da interface legível num celular; aproxime a câmera.
6. Fechamento: logo grande demais e a frase embaixo minúscula. Equilibre: ícone médio, pílula e frase legíveis.
Depois renderize, extraia os 30 quadros, olhe todos e faça a revisão crítica de novo antes de entregar.

## NADA COM CARA DE HTML (exigência do dono, vale para tudo)
O dono não quer NENHUM elemento com cara de elemento HTML. Na 1ª passagem os cartões de módulo, as pílulas, os
botões redondos e os textos pareciam divs com borda, sombra de CSS e fonte de navegador: isso está proibido.
Tudo tem de parecer renderizado, como um filme de produto feito em Cinema 4D/Octane ou Blender:
- Objetos são objetos 3D de verdade (Three.js com `MeshPhysicalMaterial`: vidro com transmissão, espessura,
  refração e bisel; plástico/esmalte glossy; clearcoat), iluminados por luz de estúdio (HDRI/environment map,
  softboxes, luz de recorte verde), com sombras de contato suaves e reflexos que correm na superfície. Nada de
  `box-shadow`, `border` de 1 px, `border-radius` chapado, gradiente linear de CSS ou glassmorphism de
  `backdrop-filter`.
- Os cartões de módulo, a pílula "dougbot.app", os botões redondos (engrenagem/check), os ícones flutuantes e a
  placa do ícone da logo são peças 3D com bisel arredondado e material (vidro fosco espesso, cerâmica branca,
  esmalte verde), não retângulos planos.
- As telas da interface (prints em `assets/ui/`) aparecem como imagem real dentro de um aparelho ou de uma lâmina
  de vidro 3D: celular modelado em 3D com moldura metálica e reflexo na tela, ou painel de vidro com espessura,
  luz passando pela borda e reflexo. Animar os elementos dela é feito recortando partes do print e movendo-as
  como lâminas em profundidade, não recriando a interface com HTML.
- Pós-produção de cinema em todo o quadro: profundidade de campo real (bokeh), motion blur nos movimentos,
  bloom suave nos brilhos, aberração cromática leve nas bordas, vinheta, grão de filme fino, color grading
  consistente. Nada de bordas perfeitamente nítidas de navegador.
- Tipografia: renderizada com cuidado de motion design (kerning óptico, pesos de uma família display de
  qualidade, animação por máscara/blur/tracking), integrada à luz da cena (leve brilho, levemente afetada pela
  profundidade de campo quando está atrás). Nunca a fonte padrão do navegador, nunca texto que pareça um
  `<p>` sobre um fundo.
- Teste de cada quadro na revisão: "se alguém pausar aqui, parece uma página web ou um filme renderizado?". Se
  parecer página web, refaça aquele plano.
