# Estrutura de 7 atos (30 s, 9:16) — a que funcionou

Tirada de um reel de lançamento de software (sistema hoteleiro) e recriada para o DougBot. Os tempos abaixo são
os do filme final. Para 15 s, junte 1+2, corte o 4 pela metade e pule o 6.

| Ato | Tempo | Luz | O que acontece | Transição de saída |
|---|---|---|---|---|
| 1 Abertura | 0,00–3,95 | Claro (quase branco, vinheta, anéis finos) | Frase-problema palavra a palavra, palavra-chave na cor da marca, rabisco de pincel se desenhando por baixo, mini-ícone 3D inline, objetos da marca passando desfocados nos cantos, orbes de vidro "×" e "+" | Whip/zoom-through com motion blur |
| 2 Logo | 3,72–5,30 | Claro | Ícone oficial 3D com varredura especular, grade quase invisível de placas de vidro atrás, nome embaixo **sem sobrepor** | Corte na batida |
| 3 Módulos | 5,05–10,95 | Claro | 5 peças 3D de cerâmica (ícone fino na cor da marca + 1 palavra, 1 linha) entrando uma por palavra falada, empilhadas em diagonal, câmera inclinando e subindo, cursor 3D acompanhando; depois viram ladrilhos orbitando a logo, ligados por anel fino | Mergulho de câmera com motion blur radial + riser + impacto grave |
| 4 UI no escuro | 10,75–17,60 | Escuro com brilho da marca nas bordas | UI real em lâminas de vidro grandes (80–86% da largura): mensagens chegando em parallax, cartão de aprovação e botão tocado pelo cursor 3D (onda + "✓ Aprovado"), trilho de passos numerados, lista do time preenchendo com contador | Inundação radial da cor da marca |
| 5 Cor da marca | 17,40–20,60 | Cor da marca cheia, texto preto | Cubos de vidro com ícones flutuando, "tudo isso" com círculo à mão, depois celular 3D passando bem perto com a UI rolando | Cortina/wipe vertical para o claro |
| 6 Prova | 20,40–24,65 | Claro | Logo + nome + rabisco; esferas acendendo ao longo de um feixe (progresso); medalhão 3D se transformando (nós → raio → check) | Deslize |
| 7 Fechamento | 24,45–30,00 | Claro | Pílula 3D com o endereço digitando, ícone médio acima, nome e frase final legíveis; shimmer final; segura até 30 s | Fim limpo |

Princípios que vieram da referência:
- Três ambientes de luz (claro → escuro → cor → claro): cada troca é um "evento" que segura a atenção.
- Muito espaço vazio; tipografia pequena e fina com UMA palavra destacada por vez.
- Rabiscos à mão como acento (pincel, círculo): humanizam o 3D.
- Tudo sempre em leve perspectiva e sempre se mexendo (nada parado mais de ~0,4 s).
- Desfoque forte de primeiro plano em quase todo plano.
- Transições por movimento (whip, zoom-through, objeto atravessando, inundação de cor), nunca corte seco
  aleatório; cortes na batida da música.

Sincronia: monte uma tabela "ato → trecho da narração com tempo" a partir dos timestamps da ElevenLabs
(desloque pelo `data-start` da voz, ex.: +0,22 s). Cada entrada de palavra/peça cai até 80 ms antes da sílaba.
