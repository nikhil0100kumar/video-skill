# Revisão de diretor (faça você mesmo, quadro a quadro)

O relatório do Gemini sempre diz que está tudo perfeito. Só a sua revisão dos quadros conta.

## Técnico
- [ ] `ffprobe`: resolução e fps certos, duração ±0,2 s, um stream de vídeo H.264 yuv420p e um de áudio AAC.
- [ ] `verifyExport` do OpenMotion passou e o lint do projeto está sem erro.
- [ ] Loudness (`ebur128`): perto de -14 LUFS, true peak < -1 dBFS, voz clara sobre a trilha.

## Quadro a quadro (1 por segundo + os instantes de transição)
- [ ] Nenhum quadro vazio, branco ou preto fora do início e do fim (olhe também 0,2 s antes e depois de cada
      corte de ato: é onde aparecem buracos, ex.: um "branco" de 0,3 s entre a logo e os módulos).
- [ ] Logo idêntica à oficial (lado a lado com o print): forma, pose, corte, cores, olhos.
- [ ] Cores exatas da marca; nada lavado, oliva ou acinzentado; pretos realmente pretos.
- [ ] Texto e logo nunca se sobrepõem; nenhum objeto passa por cima de um cartão ou de um texto que está sendo lido.
- [ ] Rótulos em uma linha (nada de "agentes de / IA" quebrado).
- [ ] UI real nítida, grande (80–86% da largura no vertical) e legível num celular; texturas carregadas (sem
      lâmina preta).
- [ ] Texto importante dentro da área segura (fora das faixas de ~220–240 px de cima e de baixo no 9:16).
- [ ] Fechamento equilibrado: ícone médio, nome e frase final legíveis.
- [ ] Teste "pausou: parece página web ou filme renderizado?". Bordas de 1 px, sombra de CSS, caixa chapada,
      fonte de navegador = refazer o plano.

## Movimento e som (assista inteiro, com som, no celular)
- [ ] Nada parado mais de ~0,4 s; easing de filme; motion blur só nas transições rápidas.
- [ ] Cada transição tem SFX e cai na batida; cada palavra-chave cai na fala.
- [ ] Pronúncia do nome da marca aprovada por ouvido (anote os instantes para o dono conferir).

## Como pedir correção
Acrescente ao fim do `BRIEF.md` uma seção "CORREÇÃO OBRIGATÓRIA (rodada N)": continue no mesmo projeto (id),
mantenha o que está bom, liste cada problema com o tempo e como deve ficar, e peça nova extração de quadros e
revisão antes de entregar. Rode `scripts/run-gemini.sh` de novo.
