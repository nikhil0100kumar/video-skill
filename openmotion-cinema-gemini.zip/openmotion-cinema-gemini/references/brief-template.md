# Briefing: <PRODUTO> <formato>, nível premium

<!-- Modelo do briefing que o Gemini 4 Neon executa. Preencha os <…>. As seções marcadas com (copie inteira)
     foram as que mais pesaram no resultado; não resuma. -->

Você está em `<CAMINHO>/openmotion`, o clone de https://github.com/nexu-io/openmotion, já instalado (`npm ci` e
`npm run build:studio`). O workspace do OpenMotion é `<CAMINHO>/openmotion-workspace` (use o mesmo `MOTION_DATA_DIR`).

O vídeo TEM de ser feito com o OpenMotion deste clone, pelo fluxo nativo dele (MCP/HyperFrames, `Motion.md`, as
skills `openmotion`, `openmotion-director`, `openmotion-production`, `openmotion-media`, export nativo +
`verifyExport`). Nada de Remotion, Blender ou ffmpeg montando o filme por fora.

## Do zero
Crie um projeto NOVO. A meta: nível de filme de lançamento de produto da Apple, Linear, Arc ou Vercel.

## REFERÊNCIA (o mais importante deste briefing)
Vídeo em `<CAMINHO>/ref/ref.mp4`, quadros a 2 fps em `ref/frames/`, transcrição com tempos em `ref/stt.json`.
Assista aos quadros TODOS antes de planejar. Recrie a LINGUAGEM (estrutura, ritmo, estética, tipos de movimento),
não o conteúdo nem a marca. Cores nossas: <HEX DESTAQUE> com <HEX PRETO>.

O que a referência faz, ato por ato:
1. <0–3 s: …>
2. <…>
(…)

Princípios a copiar: <três ambientes de luz, espaço vazio, uma palavra destacada por vez, rabiscos à mão, materiais
vidrados, tudo em perspectiva e se mexendo, desfoque forte de primeiro plano, transições por movimento, cortes na
batida>.

Como traduzir para <PRODUTO>: <ato a ato, com os elementos reais do produto>.

## Formato
- <9:16 1080x1920 | 16:9 1920x1080>, 30 fps, MP4 H.264 + AAC, <30> s (±0,2 s).
- Celular primeiro: elementos grandes, texto legível na tela pequena, nada importante nas faixas de 220 px de cima e
  de baixo (área segura de Reels/TikTok).

## O que mostrar: a interface de verdade
Prints reais em `<CAMINHO>/assets/ui/` (dados fictícios). Liste cada um com o que mostra: <…>.
Faça a interface viver: recorte os elementos das telas (mensagens, cartões, botões, linhas de lista, avatares) e
anime cada um separado (mensagens chegando, alguém digitando, botão sendo tocado, lista preenchendo, contadores
subindo). Os elementos vêm dos prints reais, nunca redesenhados como caixas HTML/CSS. Telas em 3D: celular ou
lâmina inclinados, camadas separadas em profundidade (parallax), câmera passando entre elas.

## Linguagem de câmera e montagem
- 6 a 9 planos, cortes no ritmo da fala e da música, transições premium (match cut, whip pan com motion blur, zoom
  through num elemento da UI, máscara pela forma da logo). Sem cortes secos aleatórios.
- Ângulos variados: plongée, contra-plongée, close extremo num botão, holandês leve, órbita, dolly, rack focus.
- Profundidade de campo real em todos os planos.
- Motion blur nos movimentos rápidos, easing de filme (nada linear), micro-detalhes (reflexos correndo, poeira de
  luz, brilho da marca).
- Logo em 3D abre ou fecha o filme (ou os dois). LOGO OFICIAL: `<assets/LOGO-OFICIAL-referencia.jpg>` + vetores
  `<…>`. Descreva-a em palavras (forma, pose, corte, cores). Não mude o desenho. Versões erradas estão em
  `assets/_NAO-USAR-…/`: não use.

## Lettering premium
Tipografia cinética, 1 a 3 palavras por vez, sincronizada palavra a palavra com os timestamps da narração: máscara,
tracking que fecha, peso que muda, desfoque que some, destaque <HEX> na palavra-chave. Família display de
qualidade com licença livre (Inter Display, Geist). O nome escrito é sempre "<NOME>"; não crie logotipo novo.

## Narração: ElevenLabs Eleven v4
- Já gerada e conferida em `<CAMINHO>/out/audio/narration.mp3` + `narration.json` (timestamps). Use-a; não gere
  outra. <OU: regras de geração, voz, grafia fonética e conferência por STT>.
- Texto: "<…>". Tempos de cada frase caem nos atos.

## TRILHA E SFX (copie inteira)
NÃO use as músicas nem os efeitos que vêm no repositório do OpenMotion ou nos modelos dele. Gere tudo pelo MCP
`elevenlabs` que está ligado a você:
- Trilha: `create_composition_plan` e depois `compose_music`, <30> s exatos, instrumental, <estilo>, com as
  mudanças de seção caindo nos cortes de ato (claro → escuro mais grave e tenso → cor eufórico → resolução). Pode
  usar `video_to_music` sobre um rascunho. Gere 2 ou 3 e escolha medindo a estrutura (ffmpeg ebur128/astats).
- SFX: `text_to_sound_effects` para cada evento: whoosh dos whip pans, swoosh de cartão, pop de mensagem, clique
  do botão, tique de UI, riser antes do ato escuro, impacto grave no corte, shimmer da logo, digitação da URL,
  ding do check final. Prompts específicos e curtos.
- Importe tudo com `openmotion_import_assets` e mixe no OpenMotion: voz sempre clara (trilha ~-18 dB sob a voz,
  com ducking), SFX discretos, final em ~-14 LUFS sem clipping.

## Entrega
- MP4 final em `<CAMINHO>/out/<nome>.mp4`; `ffprobe` confere resolução, duração, vídeo e áudio.
- Extraia um quadro a cada 1 s para `out/frames/` e olhe TODOS: UI nítida e reconhecível, texto legível dentro da
  área segura, logo fiel (lado a lado com a oficial), nada cortado, nenhum quadro vazio ou preto fora do
  início/fim, nada sobreposto. Corrija e renderize de novo; faça pelo menos duas rodadas de revisão crítica como
  um diretor de arte exigente.
- Escreva `out/REPORT.md`: projeto e caminhos, lista de planos com tempos, voz, texto da narração, resultado da
  transcrição e limitações.

## NADA COM CARA DE HTML (copie inteira; vale para tudo)
Nenhum elemento pode ter cara de elemento HTML. Cartões, pílulas, botões e textos que parecem divs com borda,
sombra de CSS e fonte de navegador estão proibidos. Tudo tem de parecer renderizado, como um filme de produto
feito em Cinema 4D/Octane ou Blender:
- Objetos são objetos 3D de verdade (Three.js com `MeshPhysicalMaterial`: vidro com transmissão, espessura,
  refração e bisel; plástico/esmalte glossy; clearcoat), iluminados por luz de estúdio (HDRI/environment map,
  softboxes, luz de recorte na cor da marca), com sombras de contato suaves e reflexos que correm na superfície.
  Nada de `box-shadow`, `border` de 1 px, `border-radius` chapado, gradiente linear de CSS ou glassmorphism de
  `backdrop-filter`.
- Cartões, pílulas, botões redondos, ícones flutuantes e a placa da logo são peças 3D com bisel arredondado e
  material (vidro fosco espesso, cerâmica branca, esmalte), não retângulos planos.
- As telas da interface aparecem como imagem real dentro de um aparelho ou de uma lâmina de vidro 3D (celular
  modelado com moldura metálica e reflexo na tela, ou painel de vidro com espessura, luz pela borda e reflexo).
  Animar os elementos = recortar partes do print e movê-las como lâminas em profundidade, não recriar a interface
  em HTML.
- Pós-produção de cinema em todo o quadro: profundidade de campo (bokeh), motion blur, bloom suave, aberração
  cromática leve nas bordas, vinheta, grão de filme fino, color grading consistente.
- Tipografia com cuidado de motion design (kerning óptico, pesos de uma família display, animação por
  máscara/blur/tracking), integrada à luz da cena. Nunca a fonte padrão do navegador, nunca um `<p>` sobre um fundo.
- Teste de cada quadro: "se alguém pausar aqui, parece uma página web ou um filme renderizado?". Se parecer
  página web, refaça aquele plano.

<!-- Rodadas seguintes: acrescente aqui, sem apagar nada acima:
## CORREÇÃO OBRIGATÓRIA (rodada 2)
Continue no projeto que você já criou (`<id>`): mantenha a estrutura, a narração e o áudio que já estão bons, e
corrija o que segue antes de renderizar.
1. <problema, com tempo e como deve ficar>
…
Depois renderize, extraia os quadros, olhe todos e faça a revisão crítica de novo antes de entregar. -->
