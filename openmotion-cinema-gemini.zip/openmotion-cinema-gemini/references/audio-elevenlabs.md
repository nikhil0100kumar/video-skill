# Som com ElevenLabs: narração v4, trilha e SFX pelo MCP

## Narração (API direta)

```bash
K=$(vault get global ELEVENLABS_API_KEY)     # ou export ELEVENLABS_API_KEY; nunca imprima
curl -s -X POST "https://api.elevenlabs.io/v1/text-to-speech/$VOICE/with-timestamps" \
  -H "xi-api-key: $K" -H 'content-type: application/json' \
  -d "$(jq -n --arg t "$TEXTO" '{text:$t, model_id:"eleven_v4", language_code:"pt"}')" > narration.json
jq -r .audio_base64 narration.json | base64 -d > narration.mp3
# narration.json → .alignment.characters / character_start_times_seconds / character_end_times_seconds
```
- Voz usada no DougBot: "Adam Borges" (`ZqE9vIHPcrC35dZv0Svu`), pt-BR, masculina, calorosa. Liste as vozes da
  conta com `GET /v1/voices` e teste 2–3 com uma frase só antes de gerar o texto inteiro.
- ~26 s falados para um filme de 30 s (respiros nos cortes de ato, fim em ~26,7 s e música segurando até 30 s).
- **Pronúncia de marca**: a grafia vai só para a API. "DougBot" → "DouguiBot"; o endereço → "douguibot ponto
  app"; "IA" → "I.A." (senão vira "ia"). Gere variações curtas (`p1_dougui_bot`, `p2_dogui_bot`, …) e escolha
  ouvindo.
- **STT não prova pronúncia**: `POST /v1/speech-to-text` com `model_id=scribe_v1` confirma idioma, palavras e
  tempos, mas normaliza o nome para a grafia conhecida ("Dougbot"). Quem aprova o nome é um humano ouvindo os
  instantes em que ele aparece.
- Palavras → tempos: junte os caracteres de `alignment` em palavras e gere a tabela de sincronia (some o
  `data-start` da voz no filme).

## MCP no agy (trilha e SFX)

`scripts/setup-elevenlabs-mcp.sh` cria um venv com `elevenlabs-mcp`, um wrapper e registra no agy:
```sh
ELEVENLABS_API_KEY=<do cofre> ELEVENLABS_MCP_BASE_PATH=<projeto>/out/elevenlabs \
ELEVENLABS_MODEL_ID=eleven_v4 ELEVENLABS_MCP_OUTPUT_MODE=files exec .../bin/elevenlabs-mcp
```
`OUTPUT_MODE=files` faz cada geração virar arquivo em `out/elevenlabs/` (o Gemini importa no OpenMotion).

### Trilha
1. `create_composition_plan` com o pedido e as seções com duração em ms batendo nos atos:
   "Modern tech product launch, instrumental, 120 BPM, clean electronic pulse, punchy bass, crisp percussion,
   bright synths. 0–10.7 s light and upbeat; 10.7–17.4 s darker, deeper bass, tension; 17.4–20.5 s euphoric
   drop; 20.5–30 s resolving, confident ending with a clean final hit at 27 s and short tail."
2. `compose_music` com o plano, 30 000 ms, instrumental.
3. Gere 2–3 e meça: `ffmpeg -i m.mp3 -af ebur128 -f null -` e `astats` por janela de 0,5 s; escolha a que tem
   os degraus de energia nos cortes.

### SFX (`text_to_sound_effects`, durações curtas)
| Evento | Prompt | Duração |
|---|---|---|
| Whip pan / transição | airy cinematic whoosh with subtle sub bass, clean, fast | 0,8 s |
| Cartão/peça entrando | soft glassy swoosh, short, modern UI | 0,6 s |
| Mensagem chegando | soft glassy UI pop, short, clean, modern app | 0,5 s |
| Botão tocado | crisp premium button click with gentle confirmation chime | 0,7 s |
| Progresso | delicate digital tick, tiny, clean | 0,4 s |
| Antes do escuro | short tension riser, airy, cinematic | 1,4 s |
| Corte para o escuro | deep sub bass impact, cinematic, clean tail | 1,2 s |
| Logo | crystal shimmer sparkle, elegant, short | 1,4 s |
| URL digitando | soft premium keyboard typing, 10 keystrokes | 1,4 s |
| Check final | bright clean success ding, premium app | 1,0 s |

Reaproveite o mesmo arquivo em vários instantes (5 swooshes, 3 pops) para o som ficar coerente.

## Mix no OpenMotion (atributos dos clips de áudio)

```html
<audio class="clip" src="assets/imported/<voz>.mp3" data-start="0.22" data-duration="26.48" data-track-index="4"
  data-volume="1.08"
  data-fx-chain='{"version":1,"nodes":[{"type":"highpass","params":{"frequency":80}},
    {"type":"peaking","params":{"frequency":3200,"gain":1.8,"q":1.0}},{"type":"limiter","params":{"limit":-1}}]}'></audio>

<audio class="clip" src="assets/imported/<trilha>.mp3" data-start="0" data-duration="30" data-track-index="5"
  data-fade-in="0.18" data-fade-out="0.85"
  data-automation='{"version":1,"lanes":[{"target":"volume","points":[
    {"t":0,"v":0.38},{"t":0.25,"v":0.19},{"t":3.50,"v":0.19},{"t":3.75,"v":0.31},{"t":4.10,"v":0.20},
    {"t":10.55,"v":0.20},{"t":10.82,"v":0.28},{"t":11.20,"v":0.21},{"t":17.30,"v":0.21},{"t":17.52,"v":0.34},
    {"t":17.85,"v":0.21},{"t":26.65,"v":0.20},{"t":26.95,"v":0.44},{"t":29.10,"v":0.40},{"t":30,"v":0.05}]}]}'></audio>

<audio class="clip" src="assets/imported/<whoosh>.mp3" data-start="1.72" data-duration="0.80" data-track-index="6"
  data-volume="0.22" data-fade-out="0.15"></audio>
```
- Ducking: trilha ~0,19–0,21 sob a voz, sobe para 0,28–0,34 nos cortes de ato (sem voz) e para ~0,44 no
  final quando a voz acaba.
- SFX entre 0,17 e 0,30 de volume; impactos e o clique mais altos, tiques mais baixos. Alterne `track-index`
  6/7/8 para sons que se sobrepõem.
- Medição: `ffmpeg -i filme.mp4 -af ebur128=peak=true -f null -`. Alvo -14 LUFS e true peak abaixo de -1 dBFS.
  O DougBot saiu com -11,3 LUFS / -2,6 dBFS (as plataformas abaixam sozinhas; para ficar no alvo, reduza o
  master 2–3 dB).
