# Motor 3D de cinema dentro do OpenMotion (HyperFrames + Three.js)

Trechos do motor do filme DougBot (`examples/doug3d-engine.example.js` tem o arquivo inteiro). Three.js r147
(`three.min.js` importado como asset do projeto) + GSAP, tudo carregado no `index.html`.

## 1. Arquitetura de camadas (index.html)

```
z 5   layer-3d-hero        0–30 s   canvas WebGL mestre: fundo ciclorama, todos os objetos 3D, pós GLSL
z 10+ act1…act7            por ato  tipografia cinética, rabiscos SVG (só texto e traço; nada de caixas)
z 32  layer-3d-fg          0–30 s   canvas WebGL transparente: objetos da marca desfocados no primeiro plano
z 40  layer-cinema-finish  0–30 s   canvas 2D: grão + poeira de luz por cima de TUDO (texto incluso)
      <audio class="clip"> voz, trilha, SFX (mix nativo)
```

Cada camada é um clip HyperFrames: `<div class="clip" data-composition-src="compositions/x.html"
data-start data-duration data-track-index data-width data-height>`.

## 2. Determinismo: GSAP pausado chamando draw(t)

```html
<template>
  <div id="root" data-composition-id="layer-3d-hero" data-width="1080" data-height="1920" data-layout-ignore>
    <img id="tex-ui-chat" class="tex-preload" src="assets/imported/<uuid>.png" alt="" data-layout-ignore />
    <canvas id="hero3d-canvas" width="1080" height="1920"></canvas>
  </div>
  <script>
    (function () {
      const engine = window.MeuCinema3D(document.getElementById('hero3d-canvas'));
      const state = { t: 0 };
      const tl = gsap.timeline({ paused: true });
      tl.fromTo(state, { t: 0 }, { t: 30, duration: 30, ease: 'none', onUpdate() { engine.draw(state.t); } }, 0);
      window.__timelines = window.__timelines || {};
      window.__timelines['layer-3d-hero'] = tl;
    })();
  </script>
</template>
```
- O renderer usa `preserveDrawingBuffer: true`, `setPixelRatio(1)`, tamanho fixo do quadro.
- Toda animação é função pura de `t` (`seg(t,a,b)`, `easeOutCubic`, `pulse`): nada de rAF, relógio ou
  `Math.random()` sem semente. Os `<img>` de pré-carga (`opacity:0.001`, 2 px) garantem que o render baixe os prints.

```js
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const lerp = (a, b, t) => a + (b - a) * t;
const seg = (t, a, b) => clamp((t - a) / (b - a), 0, 1);          // 0→1 dentro da janela [a,b]
const pulse = (t, a, peak, b) => (t < peak ? seg(t, a, peak) : 1 - seg(t, peak, b));
```

## 3. Renderer e câmera

```js
const renderer = new THREE.WebGLRenderer({ canvas, alpha: false, antialias: true, preserveDrawingBuffer: true });
renderer.setSize(1080, 1920, false); renderer.setPixelRatio(1);
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.98;
renderer.autoClear = false;
// FOV 34, câmera em z=600: 1 unidade ≈ 5,23 px no plano z=0 → dá para posicionar em pixels:
const PX_PER_UNIT = 1920 / (2 * 600 * Math.tan((34 * Math.PI) / 360));
const screenToWorld = (sx, sy) => ({ x: (sx - 540) / PX_PER_UNIT, y: (960 - sy) / PX_PER_UNIT });
```

## 4. Luz de estúdio: HDRI pintado + black-carding

```js
function studioEnv(renderer, mode) {              // mode 'light' | 'dark'
  const c = document.createElement('canvas'); c.width = 1024; c.height = 512;
  const g = c.getContext('2d');
  // fundo: claro em cima/embaixo, ESCURO no meio (horizonte atrás da câmera)
  // softbox branco em cima (realça topete/bisel), tiras verticais brancas nas laterais (bordas arredondadas)
  // BLACK-CARD: retângulo quase preto bem atrás da câmera → pretos piano continuam pretos, cor da marca saturada
  g.fillStyle = 'rgba(6,7,9,0.94)'; g.fillRect(250, 165, 524, 175);
  // faixa fina da cor da marca embaixo (rebatimento do chão) — no modo escuro, tubo neon lateral da marca
  const tex = new THREE.CanvasTexture(c);
  tex.mapping = THREE.EquirectangularReflectionMapping; tex.encoding = THREE.sRGBEncoding;
  const pm = new THREE.PMREMGenerator(renderer); pm.compileEquirectangularShader();
  const env = pm.fromEquirectangular(tex).texture; tex.dispose(); pm.dispose();
  return env;                                      // scene.environment = env
}
```
Sem o black-card a frente plana dos objetos reflete o fundo claro: preto vira cinza e o verde vira oliva/lavado.
Objetos pretos isolados (primeiro plano) ganham um HDRI próprio sem nenhuma cor da marca, e a luz de recorte
colorida fica ATRÁS (z negativo), só raspando a borda.

## 5. Logo: squircle de iOS + figura recortada

```js
function squircle(half, n = 4.6, segs = 128) {      // superelipse |x|^n + |y|^n = 1
  const s = new THREE.Shape();
  for (let i = 0; i <= segs; i++) {
    const a = (i / segs) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
    const x = Math.sign(ca) * Math.abs(ca) ** (2 / n) * half, y = Math.sign(sa) * Math.abs(sa) ** (2 / n) * half;
    i ? s.lineTo(x, y) : s.moveTo(x, y);
  }
  return s;
}
const plate = new THREE.ExtrudeGeometry(squircle(46.6), { depth: 8, bevelEnabled: true, bevelThickness: 3,
  bevelSize: 2.4, bevelSegments: 12, curveSegments: 64 });
```
- A placa recebe uma textura de degradê da marca (claro no alto à esquerda) + clearcoat 1.0.
- A figura (cabeça) é o path SVG convertido para o espaço do ícone (escala + rotação da pose), recortado pela
  superelipse (bisseção no ponto onde o contorno sai da placa e caminho pela borda), extrudado com bisel e
  material preto `#09090A` roughness ~0.12, clearcoat 1. Olhos: pílulas brancas levemente emissivas.
- Conferência obrigatória: render da logo ao lado do print oficial; mesma inclinação, corte e posição dos olhos.

## 6. Texturas de prints (resolve "lâmina preta")

```js
function syncedImageTexture(rootEl, imgId) {
  const c = document.createElement('canvas'); c.width = c.height = 4;
  const tex = new THREE.CanvasTexture(c);
  Object.assign(tex, { encoding: THREE.sRGBEncoding, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
    generateMipmaps: false, wrapS: THREE.ClampToEdgeWrapping, wrapT: THREE.ClampToEdgeWrapping });
  let ok = false;
  tex.__sync = () => {
    if (ok) return true;
    const el = rootEl.querySelector('#' + imgId) || document.getElementById(imgId);
    if (!el || !el.complete || !el.naturalWidth) return false;
    c.width = el.naturalWidth; c.height = el.naturalHeight;
    c.getContext('2d').drawImage(el, 0, 0); tex.needsUpdate = true; return (ok = true);
  };
  tex.__sync(); return tex;           // e em todo draw(t): texturas.forEach(t => t.__sync())
}
```
Prints têm tamanho não potência de 2 (780×1688) e carregam assíncronos dentro do template: copiar para um canvas
com LinearFilter e sem mipmaps funciona em WebGL1/2 e no render headless.

## 7. UI real numa lâmina de vidro 3D

```js
function uiSlab(tex, w, h, r, edge = 0.48) {
  const geo = new THREE.ExtrudeGeometry(roundedRect(w - 2.4, h - 2.4, r - 1.2),
    { depth: 6.2, bevelEnabled: true, bevelThickness: 2.4, bevelSize: 1.4, bevelSegments: 12, curveSegments: 32 });
  normalizeUVs(geo, w, h);                                   // UV 0–1 na face da frente
  const front = new THREE.MeshPhysicalMaterial({ map: tex, emissiveMap: tex, emissive: 0xffffff,
    emissiveIntensity: 0.56, roughness: 0.18, clearcoat: 0.9, clearcoatRoughness: 0.08, envMapIntensity: 0.72 });
  const side = new THREE.MeshPhysicalMaterial({ color: '#242D20', emissive: '#9CFA05', emissiveIntensity: edge,
    roughness: 0.08, metalness: 0.35, clearcoat: 1, clearcoatRoughness: 0.03, envMapIntensity: 1.5 });
  const g = new THREE.Group(); g.add(new THREE.Mesh(geo, [front, side]));
  // + aro fino da cor da marca (ShapeGeometry com furo) em z da face
  // + plano de brilho especular (gradiente diagonal em canvas, AdditiveBlending) cuja UV desliza com t
  // + aura aditiva da cor da marca atrás (z -18) para o ato escuro não ficar "sujo"
  return g;
}
```
- Emissivo = a própria textura: a UI fica legível no ato escuro sem lavar o resto da cena.
- Recortes do print (mensagem, botão, linha de agente) viram lâminas finas na frente (z +8 a +30), entrando em
  sequência com a fala = parallax de verdade. O "toque" no botão: cursor 3D desce, lâmina afunda 2 unidades, onda
  de luz, troca a textura por "✓ Aprovado" desenhada em canvas.
- Tamanho no 9:16: 80–86% da largura do quadro. Menos que isso o texto da UI some no celular.

## 8. Pós-produção GLSL (3 passes)

1. Bloom H (meia resolução): extrai só realces e a cor da marca. Limiar alto no estúdio claro (0,955) para o
   fundo branco não florescer, baixo no escuro (0,72); no mundo "cor cheia" quase nada de verde, só realces.
2. Bloom V (gaussiano 9 taps).
3. Composição:
```glsl
vec2 dir = vUv - 0.5; float r2 = dot(dir, dir);
vec2 ca = dir * r2 * 0.0042;                        // aberração cromática radial, zero no centro
if (uMotionBlur > 0.002) {                          // motion blur radial de obturador, só em transições
  vec3 acc = vec3(0.);
  for (int i = -3; i <= 3; i++) { vec2 s = clamp(vUv - dir * float(i)/3. * uMotionBlur * 0.14, .001, .999);
    acc += vec3(texture2D(tScene, s + ca).r, texture2D(tScene, s).g, texture2D(tScene, s - ca).b); }
  col = acc / 7.;
} else col = vec3(texture2D(tScene, vUv + ca).r, texture2D(tScene, vUv).g, texture2D(tScene, vUv - ca).b);
col += texture2D(tBloom, vUv).rgb * uBloomStrength;                 // ~0.32
col = mix(col, col*col*(3.-2.*col), mix(.06, .10, uDarkMode));      // curva S leve
col *= 1. - smoothstep(.24, .96, length(dir * vec2(1., .88))) * uVignette;   // vinheta 0.14–0.28
col += (hash12(gl_FragCoord.xy + uFrame * vec2(17.3, 31.7)) - .5) * uGrain;  // grão 0.013–0.018 por quadro
```
O render da cena vai para um `WebGLRenderTarget` com `samples: 4` (MSAA no WebGL2).
`uMotionBlur` sobe só nas janelas de transição: `smooth(seg(t, 10.54, 10.90)) * 1.1` (mergulho),
`pulse(t, 20.28, 20.43, 20.58) * 0.85` (cortina) etc.

## 9. Fundo ciclorama com 3 mundos

Um plano em tela cheia com shader que mistura: estúdio claro (cinza quase branco, vinheta, anéis concêntricos
finos), estúdio escuro (preto com brilho da marca nas bordas) e cor da marca cheia. Uniforms de transição:
`uDarkMix`, `uGreenMix`, `uPlungeRadius` (mergulho circular para o escuro), `uGreenFloodRadius` (inundação radial
da cor), `uLightCurtainY` (cortina de volta ao claro). Cada transição dura 0,25–0,45 s e coincide com o pico de
`uMotionBlur` e com um SFX.

## 10. Profundidade de campo

- Primeiro plano: canvas WebGL transparente separado (z acima do texto) com 1–2 objetos da marca grandes,
  entrando pelos cantos, e `filter: blur(10px)` no canvas. Ligado só nos atos certos.
- Fundo: objetos de cenário (orbes, grade de placas) com opacidade baixa e blur no próprio material/sprite.
- Rack focus: anime o blur de uma camada de 0 → 10 px enquanto outra vai de 10 → 0.

## 11. Acabamento de lente por cima de tudo

Canvas 2D no topo: 6 ladrilhos 256×256 de grão gerados com LCG semeado (`seed = seed*1664525+1013904223`),
alfa 9/255, `globalCompositeOperation = 'overlay'`, um ladrilho por quadro (`frame % 6`). Mais ~18 "poeiras" de luz
com órbitas determinísticas (brancas no claro, da cor da marca no escuro). Isso coloca texto e 3D na mesma lente.

## 12. Tipografia por ato (composições act*.html)

Só texto e traço SVG, animados com GSAP na timeline do ato:
```js
tl.fromTo('#palavra', { opacity: 0, y: 24, filter: 'blur(10px)', letterSpacing: '0.04em' },
  { opacity: 1, y: 0, filter: 'blur(0px)', letterSpacing: '-0.045em', duration: 0.32, ease: 'power3.out' }, 0.18);
tl.fromTo('#rabisco path', { attr: { 'stroke-dashoffset': 2300 } },
  { attr: { 'stroke-dashoffset': 0 }, duration: 0.54, ease: 'power2.out' }, 0.22);
tl.to('#wrap', { scale: 2.05, rotation: -18, opacity: 0, filter: 'blur(14px)', duration: 0.42, ease: 'power3.in' }, 0.84);
```
Peso 700–800, tracking negativo (-0.045em) no display, `text-shadow` só como brilho muito leve. Nada de caixa
atrás do texto. Peças com texto que são "objetos" (cartões de módulo, pílula da URL) têm o texto desenhado em
canvas e aplicado como textura na face da peça 3D.
